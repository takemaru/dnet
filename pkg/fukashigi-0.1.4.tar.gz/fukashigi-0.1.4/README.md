Fukashigi - a conbinatorial problem solver
===

What's Fukashigi
---

Getting started
---

References
---

"Art of 10^64 -Understanding Vastness-" Time with class! Let's count!
http://www.youtube.com/watch?v=Q4gTV4r0zRs

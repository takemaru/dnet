#pragma once

#include <ZBDD.h>

void output(ZBDD f);

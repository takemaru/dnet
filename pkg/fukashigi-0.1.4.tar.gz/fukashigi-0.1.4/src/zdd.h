#pragma once

#include <bddc.h>
#include <ZBDD.h>

#ifdef B_64
#define ID_FMT "%lld"
#else
#define ID_FMT "%d"
#endif

#define DIAGRAM_FMT ID_FMT ": (~%d?" ID_FMT ":" ID_FMT ")"

class Config;
extern Config config;

inline ZBDD bot() {
    return ZBDD(0);
}

inline ZBDD top() {
    return ZBDD(1);
}

inline bool is_bot(ZBDD f) {
    return f == ZBDD(0);
}

inline bool is_top(ZBDD f) {
    return f == ZBDD(1);
}

inline bool is_terminal(ZBDD f) {
    return f.Top() == 0;
}

inline bddvar var(ZBDD f) {
    return is_terminal(f) ? config.num_vars + 1 : f.Top();
}

inline bddword node_id(ZBDD f) {
    assert(is_terminal(f) || (f.GetID() != 0 && f.GetID() != 1));
    return is_terminal(f) ? (is_top(f) ? 1 : 0) : f.GetID();
}

inline ZBDD node(bddvar v) {
    assert(0 < v && v <= config.num_vars);
    return ZBDD(1).Change(v);
}

inline ZBDD lo(ZBDD f) {
    return f.OffSet(f.Top());
}

inline ZBDD hi(ZBDD f) {
    return f.OnSet0(f.Top());
}

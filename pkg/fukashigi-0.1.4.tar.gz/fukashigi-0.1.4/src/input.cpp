#include <cassert>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <istream>
#include <string>
#include <unordered_map>
#include <vector>

#include <ZBDD.h>

#include <MateSForest.h>
#include <MateSTree.h>
#include <MateRForest.h>
#include <MateSTPath.h>
#include <MateDSTPath.h>
#include <MateSTEDPath.h>
#include <MateComponent.h>
#include <MateKcut.h>
#include <MateRcut.h>

#include "init.h"
#include "input.h"
#include "util.h"
#include "zdd.h"

extern Config config;

ZBDD create_zdd_by_bitmap(const string& bitmap) {
    vector<ZBDD> nodes(config.num_vars + 2);
    nodes[0] = bot(), nodes[1] = top();
    for (bddvar v = config.num_vars; v > 0; v--) {
        char b = bitmap[v - 1];
        bddvar i = config.num_vars - v + 2;
        nodes[i] = b == '0' ? nodes[i - 1] + node(v) * nodes[0]
                 : b == '1' ? nodes[0]     + node(v) * nodes[i - 1]
                 :            nodes[i - 1] + node(v) * nodes[i - 1];
    }
    return nodes[config.num_vars + 1];
}

// DIMACS CNF format (http://www.satlib.org/Benchmarks/SAT/satformat.ps)
ZBDD input_cnf(string fname) {
    ifstream fin(fname);
    assert(fin.good());
    string line;
    getline(fin, line);
    vector<string> e = split(line);
    assert(e[0] == "p" && e[1] == "cnf");
    error_if(atoi(e[2].c_str()) != (int) config.num_vars, "invalid number of variables in " + fname);
    int m = atoi(e[3].c_str());
    ZBDD f;
    int l = 0;
    while (getline(fin, line)) {
        vector<string> e = split(line);
        e.pop_back(); // remove a zero at the tail end
        line = string(config.num_vars, '*');
        ZBDD g = bot();
        for (const auto& i: e) {
            int v = atoi(i.c_str());
            line[abs(v) - 1] = v > 0 ? '1' : '0';
            g += create_zdd_by_bitmap(line);
            line[abs(v) - 1] = '*';
        }
        f = l == 0 ? g : f & g;
        l++;
    }
    error_if(l != m, "too many or too few clauses given in " + fname);
    return f;
}

ZBDD input_enum(string fname) {
    ifstream fin(fname);
    assert(fin.good());
    string line;
    ZBDD f = bot();
    while (getline(fin, line)) {
        ZBDD g = top();
        for (const auto& v: split(line))
            g *= node(atoi(v.c_str()));
        f += g;
    }
    return f;
}

ZBDD input_bitmap(string fname) {
    ifstream fin(fname);
    assert(fin.good());
    string line;
    ZBDD f = bot();
    while (getline(fin, line)) {
        error_if(line.size() != config.num_vars, "too many or too few bits in " + fname);
        f += create_zdd_by_bitmap(line);
    }
    return f;
}

ZBDD convert(PseudoZDD* zdd) {
    vector<intx>* level_list = zdd->GetLevelFirstList();
    vector<intx>* lo_list = zdd->GetLoNodeList();
    vector<intx>* hi_list = zdd->GetHiNodeList();
    vector<ZBDD> nodes(zdd->GetNumberOfNodes() + 2);
    nodes[0] = bot(), nodes[1] = top();
    ZBDD root;
    bddvar min_v = BDD_MaxVar;
    for (bddvar v = config.num_vars; v > 0; v--) {
        for (intx n = (*level_list)[v - 1]; n < (*level_list)[v]; n++) {
            bddword l = (*lo_list)[n];
            bddword h = (*hi_list)[n];
            nodes[n] = nodes[l] + node(v) * nodes[h];
            if (v < min_v)
                root = nodes[n], min_v = v;
        }
    }
    return root;
}

ZBDD input_subgraph(string fname) {
    int enum_kind = 0;
    int start_vertex = 1; // start vertex number for (directed / undirected) s-t path
    int end_vertex = -1;  // end vertex number for (directed / undirected) s-t path
    int max_cut_num = 99999999; // enumerate at most 'max_cut_num' cuts for k-cut or r-cut
    bool is_le = false; // for enumeration of components
    bool is_me = false; // for enumeration of components

    RootManager root_mgr;

    enum {
        SFOREST, // spanning forest
        STREE,   // spanning tree
        STPATH,  // s-t path or cycle
        DSTPATH, // directed s-t path or cycle
        STEDPATH, // s-t edge-disjoint path
        RFOREST, // rooted (spanning) forest
        COMP,    // component
        KCUT,    // k-cut
        RCUT,    // rooted k-cut
    };

    ifstream fin(fname);
    assert(fin.good());

    char line[8 * config.num_vars];
    fin.getline(line, sizeof(line));
    string kind = strtok(line, ", ");
    if      (kind == "sforest" ) enum_kind = SFOREST;
    else if (kind == "stree"   ) enum_kind = STREE;
    else if (kind == "stpath"  ) enum_kind = STPATH;
    else if (kind == "dstpath" ) enum_kind = DSTPATH;
    else if (kind == "stedpath") enum_kind = STEDPATH;
    else if (kind == "rforest" ) enum_kind = RFOREST;
    else if (kind == "comp"    ) enum_kind = COMP;
    else if (kind == "kcut"    ) enum_kind = KCUT;
    else if (kind == "rcut"    ) enum_kind = RCUT;

    if (kind == "stpath" || kind == "dstpath" || kind == "stedpath") {
        start_vertex = atoi(strtok(NULL, ", "));
        end_vertex = atoi(strtok(NULL, ", "));
        // TODO: support cycle and hamilton one (and to any vertices)
    }
    else if (kind == "rforest" || kind == "rcut") {
        char* p;
        while ((p = strtok(NULL, ", ")) != NULL)
            root_mgr.Add(atoi(p));
    }
    else if (kind == "kcut") {
        string op = strtok(NULL, ", ");
        if (op == "<=") is_le = true;
        if (op == ">=") is_me = true;
        max_cut_num = atoi(strtok(NULL, ", "));
    }

    Graph* graph = new Graph();
    graph->LoadC(fin);

    if (enum_kind == STPATH || enum_kind == DSTPATH || enum_kind == STEDPATH)
        if (end_vertex < 0)
            end_vertex = graph->GetVertexSize();

    State* state = NULL;

    switch (enum_kind) {
    case SFOREST:
        state = new StateSForest(graph);
        break;
    case STREE:
        state = new StateSTree(graph);
        break;
    case STPATH:
    case DSTPATH:
        if (enum_kind == STPATH) {
            state = new StateSTPath(graph);
        } else {
            state = new StateDSTPath(graph);
        }
        static_cast<StateSTPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTPath*>(state)->SetHamilton(false);
        static_cast<StateSTPath*>(state)->SetCycle(false);
        break;
    case STEDPATH:
        state = new StateSTEDPath(graph);
        static_cast<StateSTEDPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTEDPath*>(state)->SetHamilton(false);
        static_cast<StateSTEDPath*>(state)->SetCycle(false);
        break;
    case RFOREST:
        state = new StateRForest(graph);
        static_cast<StateRForest*>(state)->SetRootManager(&root_mgr);
        break;
    case COMP:
        state = new StateComponent(graph, max_cut_num, is_le, is_me);
        break;
    case KCUT:
        state = new StateKcut(graph, max_cut_num);
        break;
    case RCUT:
        state = new StateRcut(graph, max_cut_num);
        static_cast<StateRcut*>(state)->SetRootManager(&root_mgr);
        break;
    }

    ZDDNode::Initialize(state);

    PseudoZDD* zdd = new PseudoZDD;
    zdd->Construct(state);
    zdd->Reduce();

    ZBDD f = convert(zdd);

    delete zdd;
    ZDDNode::Finalize();
    if (state != NULL) delete state;
    delete graph;

    return f;
}

ZBDD input_diagram(string fname) {
    ifstream fin(fname);
    assert(fin.good());
    string line;

    size_t num_nodes = 0;
    getline(fin, line);
    int r = sscanf(line.c_str(), "#nodes: %ld", &num_nodes);
    error_if(r != 1, "invalid format in " + fname);
    error_if(num_nodes == 0, "too few nodes in " + fname);

    bddword root = BDD_MaxNode;
    getline(fin, line);
    r = sscanf(line.c_str(), "root: " ID_FMT, &root);
    error_if(r != 1, "invalid format in " + fname);
    error_if(BDD_MaxNode < root, "invalid root node in " + fname);

    unordered_map<bddword, ZBDD> nodes;
    nodes[0] = bot(), nodes[1] = top();

    bddword n, l, h;
    bddvar v;
    while (getline(fin, line)) {
        r = sscanf(line.c_str(), DIAGRAM_FMT, &n, &v, &l, &h);
        error_if(r != 4, "invalid format in " + fname);
        if (n < 2) continue;
        error_if(v == 0 || v > config.num_vars, "too large variable number in " + fname);
        error_if(nodes.find(l) == nodes.end() || nodes.find(h) == nodes.end(), "child node not found in " + fname);
        nodes[n] = nodes.at(l) + node(v) * nodes.at(h);
    }
    error_if(nodes.size() != num_nodes, "too many or too few nodes in " + fname);
    error_if(nodes.find(root) == nodes.end(), "root node not found in " + fname);

    return nodes.at(root);
}

inline bool is_cnf(const string& s) {
    return s.find("p cnf") == 0;
}

inline bool is_diagram(const string& s) {
    return s.find("#nodes:") == 0;
}

inline bool is_subgraph(const string& s) {
    return isalpha(s[0]);
}

inline bool is_bitmap(const string& s) {
    return s[0] == '0' || s.find('*') != string::npos;
}

inline bool _is_enum(const string& s) {
    return strpbrk(s.c_str(), " 23456789") != NULL;
}

ZBDD input(string fname) {
    ifstream fin(fname.c_str());
    error_if(! fin.good(), "cannot open " + fname);
    string line;
    getline(fin, line); // fail-bit is set by an empty file
    fin.close();
    return is_cnf(line)      ? input_cnf(fname)
         : is_diagram(line)  ? input_diagram(fname)
         : is_subgraph(line) ? input_subgraph(fname)
         : is_bitmap(line)   ? input_bitmap(fname)
         :                    input_enum(fname);
}

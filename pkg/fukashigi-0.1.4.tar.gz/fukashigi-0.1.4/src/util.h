#pragma once

#include <cstring>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

#define error_if(e, m) {                                                \
        if ((e)) {                                                      \
            stringstream ss;                                            \
            (ss << m);                                                  \
            fprintf(stderr, "Error: %s:%u: %s: %s, assertion `%s' failed.\n", \
                   __FILE__, __LINE__, __PRETTY_FUNCTION__, ss.str().c_str(), (#e)); \
            exit(1);                                                    \
        }                                                               \
    }

template <class T>
inline string join(const vector<T>& v, string sep = " ") {
    stringstream ss;
    for (int i = 0; i < (int) v.size(); i++) {
        ss << v[i];
        if (i < (int) v.size() - 1) ss << sep;
    }
    return ss.str();
}

//template <class T>
inline vector<string> split(const string& str, const string sep = " ") {
    char buf[str.size() + 1];
    strcpy(buf, str.c_str());
    vector<string> v;
    char* p = strtok(buf, sep.c_str());
    while (p != NULL) {
        v.push_back(p);
        p = strtok(NULL, sep.c_str());
    }
    return v;
}

inline bool is_digit(string s) {
    return s.find_first_not_of("0123456789") == string::npos;
}

#include <algorithm>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <set>
#include <sstream>
#include <unordered_map>
#include <vector>

#ifdef HAVE_LIBGMPXX
#include <gmpxx.h>
#endif

#include "init.h"
#include "output.h"
#include "util.h"

extern Config config;

class Node {
public:
    bddword n;
    bddvar v;
    bddword l, h;

    Node() : n(0), v(0), l(0), h(0) {
    }

    Node(string s) : v(config.num_vars + 1) {
        if (s == "bot")
            this->n = this->l = this->h = 0;
        else
            this->n = this->l = this->h = 1;
    }

    Node(bddword _n, bddvar _v, bddword _l, bddword _h)
        : n(_n), v(_v), l(_l), h(_h) {
    }

    bool operator<(const Node& n) const {
        return this->v != n.v ? this->v > n.v : this->n < n.n;
    }
};

/*
 * Class ZDD sorts the nodes including terminals in descending order of the
 * variables and in ascending order of the nodes.  It also renumbers the nodes
 * serially.
 */
class ZDD {
public:
    ZBDD f;
    vector<Node> nodes;
    bddword root;

    ZDD(ZBDD _f) : f(_f) {
        this->nodes = { Node("bot"), Node("top") };

        if (is_bot(this->f)) {
            this->root = 0;
            return;
        }
        else if (is_top(this->f)) {
            this->root = 1;
            return;
        }

        set<bddword> ids = { 0, 1 };
        this->copy(this->nodes, ids, f);
        sort(nodes.begin(), nodes.end());
        bddword j = 0;
        unordered_map<bddword, bddword> r;
        for (const auto& n: nodes)
            r[n.n] = j++;
        for (auto& n: nodes)
            n.n = r[n.n], n.l = r[n.l], n.h = r[n.h];

        this->root = r[node_id(f)];
    }

    void copy(vector<Node>& nodes, set<bddword>& ids, const ZBDD f) const {
        if (ids.find(node_id(f)) != ids.end()) return;
        ZBDD l = lo(f);
        ZBDD h = hi(f);
        Node n(node_id(f), var(f), node_id(l), node_id(h));
        nodes.push_back(n);
        ids.insert(n.n);
        this->copy(nodes, ids, l);
        this->copy(nodes, ids, h);
    }
};

// Algorithm B modified for ZDD
void algorithm_b(ZDD& z, vector<int>& x) {
    bddvar n = config.num_vars;
    bddword s = z.nodes.size();
    const vector<Node>& ns = z.nodes;
    const vector<int>& w = config.weights;

    assert(! is_bot(z.f));
    for (bddvar j = 0; j <= n; j++) x[j] = 0;
    if (is_top(z.f)) return;

    vector<int> t(s);
    vector<int> ms = { INT_MIN, 0 };
    ms.resize(s);
    for (bddword k = 0; k < s; k++) t[k] = 0;
    for (bddword k = 2; k < s; k++) {
        bddvar v = ns[k].v;
        bddword l = ns[k].l;
        bddword h = ns[k].h;
        if (l != 0)
            ms[k] = ms[l];
        if (h != 0) {
            int m = ms[h] + w[v];
            if (l == 0 || m > ms[k]) {
                ms[k] = m;
                t[k] = 1;
            }
        }
    }

    bddword k = s - 1;
    while (k > 1) {
        bddvar v = ns[k].v;
        x[v] = t[k];
        k = t[k] == 0 ? ns[k].l : ns[k].h;
    }
}

// Algorithm C modified for ZDD
double algorithm_c(ZBDD f) {
    static unordered_map<bddword, double> counts;
    if (is_terminal(f))
        return is_top(f) ? 1 : 0;
    else if (counts.find(node_id(f)) != counts.end())
        return counts[node_id(f)];
    else
        return counts[node_id(f)] = algorithm_c(hi(f)) + algorithm_c(lo(f));
}

#ifdef HAVE_LIBGMPXX
// Algorithm C modified for ZDD with GNU Multiple Precision library
mpz_class algorithm_c_with_gmp(ZBDD f) {
    static unordered_map<bddword, mpz_class> counts;
    if (is_terminal(f))
        return is_top(f) ? 1 : 0;
    else if (counts.find(node_id(f)) != counts.end())
        return counts[node_id(f)];
    else
        return counts[node_id(f)] = algorithm_c_with_gmp(hi(f)) + algorithm_c_with_gmp(lo(f));
}
#endif

ZBDD choose_randomly(ZBDD f, vector<bddvar>& stack, int& idum) {
    if (is_terminal(f)) {
        if (is_top(f)) {
            ZBDD g = top();
            for (int i = 0; i <= (int) stack.size() - 1; i++)
                g *= node(stack[i]);
            return g;
        }
        assert(false);
    }

    double ch = algorithm_c(hi(f));
    double cl = algorithm_c(lo(f));

    if (ran3(idum) > cl / (ch + cl)) {
        stack.push_back(var(f));
        return choose_randomly(hi(f), stack, idum);
    }
    else {
        return choose_randomly(lo(f), stack, idum);
    }
}

ZBDD choose_randomly(ZBDD f) {
    ZBDD g = bot();
    int idum = -1;
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        vector<bddvar> stack;
        ZBDD h = choose_randomly(f, stack, idum);
        f -= h;
        g += h;
    }
    return g;
}

ZBDD choose_top_k(ZBDD f) {
    ZBDD g = bot();
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        ZDD z(f);
        vector<int> x(config.num_vars + 1);
        algorithm_b(z, x);
        ZBDD h = top();
        for (bddvar j = 1; j <= config.num_vars; j++)
            if (x[j]) h *= node(j);
        f -= h;
        g += h;
    }
    return g;
}

void to_bitmap(ZBDD f, char bitmap[]) {
    if (is_terminal(f)) {
        if (is_top(f))
            cout << bitmap << endl;
        return;
    }
    bddvar v = var(f);
    ZBDD l = lo(f);
    ZBDD h = hi(f);
    if (l == h) {
        bitmap[v - 1] = '*';
        to_bitmap(l, bitmap);
        bitmap[v - 1] = '0';
    }
    else {
        bitmap[v - 1] = '1';
        to_bitmap(h, bitmap);
        bitmap[v - 1] = '0';
        to_bitmap(l, bitmap);
    }
}

void to_bitmap(ZBDD f) {
    char bitmap[config.num_vars + 1];
    for (bddvar v = 0; v < config.num_vars; v++)
        bitmap[v] = '0';
    bitmap[config.num_vars] = '\0';
    to_bitmap(f, bitmap);
}

void to_cardinality(ZBDD f) {
#ifdef HAVE_LIBGMPXX
    cout << algorithm_c_with_gmp(f) << endl;
#else
    cout << algorithm_c(z) << endl;
#endif
}

void to_diagram(ZBDD f) {
    ZDD z(f);
    assert(z.nodes.size() > 0);
    printf("#nodes: %ld\n", z.nodes.size());
    printf("root: " ID_FMT "\n", z.root);
    for (const auto& n: z.nodes)
        printf(DIAGRAM_FMT "\n", n.n, n.v, n.l, n.h);
}

void to_enum(ZBDD f, vector<bddvar>& stack) {
    if (is_terminal(f)) {
        if (is_top(f))
            cout << join(stack) << endl;
        return;
    }
    stack.push_back(var(f));
    to_enum(hi(f), stack);
    stack.pop_back();
    to_enum(lo(f), stack);
}

void to_enum(ZBDD f) {
    vector<bddvar> stack;
    to_enum(f, stack);
}

void to_enum_by_top_k(ZBDD f) {
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        ZDD z(f);
        vector<int> x(config.num_vars + 1);
        algorithm_b(z, x);
        vector<bddvar> e;
        ZBDD h = top();
        for (bddvar j = 1; j <= config.num_vars; j++)
            if (x[j]) {
                e.push_back(j);
                h *= node(j);
            }

        cout << join(e) << endl;
        f -= h;
    }
}

void output(ZBDD f) {
    if (config.weights.size() > 0 && config.output_type == 'e') {
        to_enum_by_top_k(f);
    }
    else {
        f = config.weights.size() > 0 ? choose_top_k(f)
          : config.output_size    > 0 ? choose_randomly(f)
          :                             f;
        if (config.output_type == 'b')
            to_bitmap(f);
        else if (config.output_type == 'c')
            to_cardinality(f);
        else if (config.output_type == 'd')
            to_diagram(f);
        else
            to_enum(f);
    }
}

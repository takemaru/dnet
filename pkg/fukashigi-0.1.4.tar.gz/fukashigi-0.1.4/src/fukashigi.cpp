#include <ZBDD.h>

#include "init.h"
#include "operation.h"
#include "output.h"

Config config;

int main(int argc, char** argv) {
    config = Config(argc, argv);
    ZBDD f = calc();
    output(f);
    return 0;
}

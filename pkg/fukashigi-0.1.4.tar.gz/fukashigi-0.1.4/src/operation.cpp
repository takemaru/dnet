#include <cassert>
#include <cstdlib>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <ZBDD.h>

#include "init.h"
#include "input.h"
#include "operation.h"
#include "util.h"
#include "zdd.h"

extern Config config;

ZBDD complement(ZBDD f) {
    vector<ZBDD> nodes(config.num_vars + 2);
    nodes[0] = bot(), nodes[1] = top();
    for (bddvar v = config.num_vars; v > 0; v--) {
        bddvar i = config.num_vars - v + 2;
        nodes[i] = nodes[i - 1] + node(v) * nodes[i - 1];
    }
    return nodes[config.num_vars + 1] - f;
}

void init_stacks(ZBDD f, vector<vector<ZBDD> >& stacks, unordered_set<bddword>& visited) {
    if (! is_terminal(f) && visited.find(node_id(f)) == visited.end()) {
        stacks[var(f)].push_back(f);
        visited.insert(node_id(f));
        init_stacks(lo(f), stacks, visited);
        init_stacks(hi(f), stacks, visited);
    }
}

ZBDD minimal(ZBDD f) {
    if (is_terminal(f)) return f;
    vector<vector<ZBDD> > stacks(config.num_vars + 1);
    unordered_set<bddword> visited;
    init_stacks(f, stacks, visited);
    unordered_map<bddword, ZBDD> cache = { {node_id(bot()), bot()}, {node_id(top()), top()} };
    for (bddvar v = config.num_vars; v > 0; v--) {
        while (! stacks[v].empty()) {
            ZBDD n = stacks[v].back();
            stacks[v].pop_back();
            cache[node_id(n)]
                = cache.at(node_id(lo(n)))
                + (cache.at(node_id(hi(n))) - cache.at(node_id(lo(n)))).Change(v);
        }
    }
    return cache.at(node_id(f));
}

ZBDD maximal(ZBDD f) {
    if (is_terminal(f)) return f;
    vector<vector<ZBDD> > stacks(config.num_vars + 1);
    unordered_set<bddword> visited;
    init_stacks(f, stacks, visited);
    unordered_map<bddword, ZBDD> cache = { {node_id(bot()), bot()}, {node_id(top()), top()} };
    for (bddvar v = config.num_vars; v > 0; v--) {
        while (! stacks[v].empty()) {
            ZBDD n = stacks[v].back();
            stacks[v].pop_back();
            cache[node_id(n)]
                = cache.at(node_id(lo(n))) - cache.at(node_id(lo(n))).Permit(cache.at(node_id(hi(n))))
                + cache.at(node_id(hi(n))).Change(v);
        }
    }
    return cache.at(node_id(f));
}

ZBDD hitting_sets(ZBDD f) { // a.k.a cross elements
    if (is_bot(f)) return top();
    if (is_top(f)) return bot();
    vector<vector<ZBDD> > stacks(config.num_vars + 1);
    unordered_set<bddword> visited;
    init_stacks(f, stacks, visited);
    unordered_map<bddword, ZBDD> cache = { {node_id(bot()), bot()}, {node_id(top()), bot()} };
    for (bddvar v = config.num_vars; v > 0; v--) {
        while (! stacks[v].empty()) {
            ZBDD n = stacks[v].back();
            stacks[v].pop_back();
            ZBDD l = cache.at(node_id(lo(n)));
            if (lo(n) != bot()) {
                for (bddvar j = var(lo(n)) - 1; j > v; j--)
                    l += l.Change(j);
            }
            ZBDD h = cache.at(node_id(hi(n)));
            if (hi(n) != bot()) {
                for (bddvar j = var(hi(n)) - 1; j > v; j--)
                    h += h.Change(j);
            }
            if (lo(n) == bot()) {
                ZBDD g = top();
                for (bddvar j = config.num_vars; j > v; j--)
                    g += g.Change(j);
                g = g.Change(var(n));
                cache[node_id(n)] = h + g;
            }
            else {
                cache[node_id(n)] = (h & l) + l.Change(v);
            }
        }
    }
    ZBDD g = cache.at(node_id(f));
    for (bddvar j = var(f) - 1; j > 0; j--)
        g += g.Change(j);
    return g;
}

ZBDD set_size(ZBDD f, string op) {
    return f.PermitSym(atoi(op.c_str()));
}

ZBDD symdiff(ZBDD f, ZBDD g) {
    return (f - g) + (g - f);
}

ZBDD subsets(ZBDD f, ZBDD g) {
    return f.Permit(g);
}

ZBDD supersets(ZBDD f, ZBDD g) {
    return f.Restrict(g);
}

pair<bddword, bddword> make_key(ZBDD f, ZBDD g) {
    return make_pair(node_id(f), node_id(g));
}

ZBDD zuniq(bddvar v, ZBDD l, ZBDD h) {
    return l + node(v) * h;
}

struct bdd_pair_hash {
    size_t operator()(const pair<bddword, bddword>& o) const {
        return (o.first << 4*sizeof(o.first)) ^ o.second;
  }
};

struct bdd_pair_eq {
    bool operator()(const pair<bddword,bddword>& a, const pair<bddword,bddword>& b) const {
        return a.first == b.first && a.second == b.second;
    }
};

ZBDD non_subsets(ZBDD f, ZBDD g) {
    static unordered_map< pair<bddword, bddword>, ZBDD, bdd_pair_hash, bdd_pair_eq> cache;
    if (g == bot())
        return f;
    else if (f == bot() || f == top() || f == g)
        return bot();
    pair<bddword, bddword> k = make_key(f, g);
    auto i = cache.find(k);
    if (i != cache.end())
        return i->second;
    ZBDD rl;
    ZBDD rh;
    if (var(f) < var(g)) {
        rl = non_subsets(lo(f), g);
        rh = hi(f);
    }
    else {
        rl = non_subsets(lo(f), hi(g)) & non_subsets(lo(f), lo(g));
        rh = non_subsets(hi(f), hi(g));
    }
    return cache[k] = zuniq(var(f), rl, rh);
}

ZBDD non_supersets(ZBDD f, ZBDD g) {
    static unordered_map< pair<bddword, bddword>, ZBDD, bdd_pair_hash, bdd_pair_eq> cache;
    if (g == bot())
        return f;
    else if (f == bot() || g == top() || f == g)
        return bot();
    else if (var(f) > var(g))
        return non_supersets(f, lo(g));
    pair<bddword, bddword> k = make_key(f, g);
    auto i = cache.find(k);
    if (i != cache.end())
        return i->second;
    ZBDD rl;
    ZBDD rh;
    if (var(f) < var(g)) {
        rl = non_supersets(lo(f), g);
        rh = non_supersets(hi(f), g);
    }
    else {
        rl = non_supersets(lo(f), lo(g));
        rh = non_supersets(hi(f), hi(g)) & non_supersets(hi(f), lo(g));
    }
    return cache[k] = zuniq(var(f), rl, rh);
}

inline bool is_unitary_operator(string s) {
    return s == "~" || s == "(minimal)" || s == "(maximal)" || s == "#" || is_digit(s);
}

inline bool is_binary_operator(string s) {
    return s == "&" || s == "+" || s == "|" || s == "*" || s == "^" || 
           s == "-" || s == "\\" || s == "/" || s == "%" ||
           s == "(subsets)" || s == "(supersets)" || s == "(nonsubsets)" || s == "(nonsupersets)";
}

ZBDD unitary_operation(string op, ZBDD f) {
    return op == "~"         ? complement(f)
         : op == "(minimal)" ? minimal(f)
         : op == "(maximal)" ? maximal(f)
         : op == "#"         ? hitting_sets(f)
         :                     set_size(f, op);
}

ZBDD binary_operation(string op, ZBDD f, ZBDD g) {
    return op == "&"               ? f & g
         : op == "+" || op == "|"  ? f + g
         : op == "*"               ? f * g
         : op == "^"               ? symdiff(f, g)
         : op == "-" || op == "\\" ? f - g
         : op == "/"               ? f / g
         : op == "%"               ? f % g
         : op == "(subsets)"       ? subsets(f, g)
         : op == "(supersets)"     ? supersets(f, g)
         : op == "(nonsubsets)"    ? non_subsets(f, g)
         :                           non_supersets(f, g);
}

ZBDD calc() {
    ZBDD f;
    string b_op = "";
    for (int i = 0; i < (int) config.args.size(); i++) {
        if (is_binary_operator(config.args[i]))
            b_op = config.args[i++];
        error_if(is_binary_operator(config.args[i]), "invalid argument " + config.args[i]);
        int j = i;
        while (j < (int) config.args.size() && ! is_binary_operator(config.args[j]))
            j++;
        int k = i;
        i = --j;
        error_if(is_unitary_operator(config.args[j]), "invalid argument " + config.args[j]);
        ZBDD g = input(config.args[j]);
        while (k < j)
            g = unitary_operation(config.args[--j], g);
        f = b_op != "" ? binary_operation(b_op, f, g) : g;
    }
    return f;
}

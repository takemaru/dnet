#include <cassert>
#include <cstdlib>
#include <map>
#include <string>

#include <ZBDD.h>

#include "init.h"
#include "input.h"
#include "operation.h"
#include "util.h"

extern Config config;

inline bool is_unitary_operator(string s) {
    return s == "~" || s == "#" || s == "<" || s == ">" || is_digit(s);
}

inline bool is_binary_operator(string s) {
    return s == "&" || s == "+" || s == "|" || s == "-" || s == "\\" || s == "/" || s == "%";
}

ZBDD _not(ZBDD f) {
    ZBDD nodes[config.num_vars + 2];
    nodes[0] = bot();
    nodes[1] = top();
    for (bddvar v = config.num_vars; v > 0; v--) {
        bddvar i = config.num_vars - v + 2;
        nodes[i] = nodes[i - 1] + node(v) * nodes[i - 1];
    }
    return nodes[config.num_vars + 1] - f;
}

ZBDD minimal(ZBDD f) {
    assert(! "minimal not supported");
}

ZBDD maximal(ZBDD f) {
    assert(! "maximal not supported");
}

inline int v(ZBDD f) { // gets the top varible
    return is_terminal(f) ? BDD_MaxVar : var(f);
}

pair<bddword, bddword> key(ZBDD f, ZBDD g) {
    return make_pair(f.GetID(), g.GetID());
}

ZBDD zuniq(bddvar v, ZBDD l, ZBDD h) {
    return l + node(v) * h;
}

ZBDD zuniq(bddvar v, pair<bddword, bddword> k) {
    return zuniq(v, ZBDD_ID(k.first), ZBDD_ID(k.second));
}

map< pair<bddword, bddword>, ZBDD> nonsup_cache;

ZBDD nonsup(ZBDD f, ZBDD g) {
    bddvar fv = v(f);
    bddvar gv = v(g);

    if (g == bot()) {
        return f;
    }
    else if (f == bot() || g == top() || f == g) {
        return bot();
    }
    else if (fv > gv) {
        return nonsup(f, lo(g));
    }

    auto i = nonsup_cache.find(key(f, g));
    if (i != nonsup_cache.end()) {
        return i->second;
    }
    else if (fv < gv) {
        pair<bddword, bddword> k = key(nonsup(lo(f), g), nonsup(hi(f), g));
        return nonsup_cache[k] = zuniq(fv, k);
    }
    else if (fv == gv) {
        pair<bddword, bddword> k
            = key(nonsup(lo(f), lo(g)), nonsup(hi(f), hi(g)) & nonsup(hi(f), lo(g)));
        return nonsup_cache[k] = zuniq(fv, k);
    }

    assert(false);
    return ZBDD(-1);
}

map<bddword, ZBDD> minhit_cache;

// XXX Knuth's MINHIT, which will be replaced by Toda's algorithm
ZBDD hit(ZBDD f) {
    if (f == bot()) {
        return top();
    }
    else if (f == top()) {
        return bot();
    }

    auto i = minhit_cache.find(f.GetID());
    if (i != minhit_cache.end()) {
        return i->second;
    }
    else {
        return minhit_cache[f.GetID()]
            = zuniq(v(f), hit(lo(f) + hi(f)), nonsup(hit(lo(f)), hit(lo(f) + hi(f))));
    }
}

ZBDD set_size(ZBDD f, string op) {
    return f.PermitSym(atoi(op.c_str()));
}

ZBDD unitary_operation(string op, ZBDD f) {
    return op == "~" ? _not(f)
         : op == "<" ? minimal(f)
         : op == ">" ? maximal(f)
         : op == "#" ? hit(f)
         :             set_size(f, op);
}

ZBDD binary_operation(string op, ZBDD f, ZBDD g) {
    if (op == "&")
        return f & g;
    else if (op == "+" || op == "|")
        return f + g;
    else if (op == "-" || op == "\\")
        return f - g;
    else if (op == "/")
        return f / g;
    else if (op == "%")
        return f % g;
    else
        assert((op + " not supported").size() == 0);
    return ZBDD(-1);
}

ZBDD calc() {
    ZBDD f;
    string b_op = "";
    for (int i = 0; i < (int) config.args.size(); i++) {
        if (is_binary_operator(config.args[i]))
            b_op = config.args[i++];
        assert(! is_binary_operator(config.args[i]));
        int j = i;
        while (j < (int) config.args.size() && ! is_binary_operator(config.args[j]))
            j++;
        int k = i;
        i = --j;
        assert(! is_unitary_operator(config.args[j]));
        ZBDD g = input(config.args[j]);
        while (k < j)
            g = unitary_operation(config.args[--j], g);
        f = b_op != "" ? binary_operation(b_op, f, g) : g;
    }
    return f;
}

#pragma once

class ZBDD;

ZBDD calc();

#pragma once

class ZBDD;

ZBDD input(string fname);

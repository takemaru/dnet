#include <cassert>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include <unistd.h>
#include <ZBDD.h>

#include "init.h"
#include "util.h"

Config::Config() {}

Config::Config(int argc, char** argv) {
    int ch;
    string weight_file;
    while ((ch = getopt(argc, argv, "n:s:t:w:")) != -1) {
        if (ch == 'n')
            this->num_vars = atoi(optarg);
        else if (ch == 't')
            this->output_type = tolower(optarg[0]);
        else if (ch == 's')
            this->output_size = atoi(optarg);
        else if (ch == 'w')
            weight_file = optarg;
        else {
            cerr << "usage: " << argv[0] << " -n number_of_variables " <<
                "-t output_type [-s output_size] [-w weight_file] sets_or_operand ..." << endl;
            exit(64);
        }
    }
    assert(0 < this->num_vars && this->num_vars < (bddvar) BDD_MaxVar);
    assert(string("bcde").find_first_of(this->output_type) != string::npos);

    argc -= optind;
    argv += optind;
    for (int i = 0; i < argc; i++)
        this->args.push_back(argv[i]);
    assert(this->args.size() > 0);

    if (weight_file.size() > 0) {
        this->weights.push_back(0);
        char buf[8 * this->num_vars];
        ifstream fin(weight_file.c_str());
        while (fin.getline(buf, sizeof(buf))) {
            char* p = strtok(buf, ", ");
            while (p != NULL) {
                this->weights.push_back(atoi(p));
                p = strtok(NULL, ", ");
            }
        }
        assert(this->weights.size() == this->num_vars + 1);
    }

#ifdef B_64
    BDD_Init(1000000, 8000000000ll);
#else
    BDD_Init(1000000, 800000000);
#endif
    for (bddvar i = 0; i < this->num_vars; i++)
        ZBDD(1).Change(BDD_NewVarOfLev(1));
}

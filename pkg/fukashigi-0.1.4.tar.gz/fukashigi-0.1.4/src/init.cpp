#include <cassert>
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include <unistd.h>
#include <ZBDD.h>

#include "init.h"
#include "util.h"

Config::Config() {}

Config::Config(int argc, char** argv) {
    int ch;
    string weight_file = "";
    while ((ch = getopt(argc, argv, "n:s:t:w:")) != -1) {
        if (ch == 'n')
            this->num_vars = atoi(optarg);
        else if (ch == 't')
            this->output_type = tolower(optarg[0]);
        else if (ch == 's')
            this->output_size = atoi(optarg);
        else if (ch == 'w')
            weight_file = optarg;
        else {
            cout << "Usage: " << argv[0] << " -n number_of_variables " <<
                "-t output_type [-s output_size] [-w weight_file] sets_or_operand ..." << endl;
            exit(0);
        }
    }
    error_if((bddvar) BDD_MaxVar < this->num_vars, "variables must be equal to or less than " << BDD_MaxVar);
    error_if(string("bcde").find_first_of(this->output_type) == string::npos, "output type must be [bcde]");

    argc -= optind;
    argv += optind;
    for (int i = 0; i < argc; i++)
        this->args.push_back(argv[i]);
    error_if(this->args.size() == 0, "no set given");

    if (weight_file != "") {
        this->weights.push_back(0);
        ifstream fin(weight_file.c_str());
        string line;
        while (getline(fin, line)) {
            for (const auto& i: split(line))
                this->weights.push_back(atoi(i.c_str()));
        }
        error_if(this->weights.size() != this->num_vars + 1, "too many or too few weight values given");
    }

#ifdef B_64
    BDD_Init(1000000, 8000000000ll);
#else
    BDD_Init(1000000, 800000000);
#endif
    for (bddvar i = 0; i < this->num_vars; i++)
        ZBDD(1).Change(BDD_NewVarOfLev(1));
}

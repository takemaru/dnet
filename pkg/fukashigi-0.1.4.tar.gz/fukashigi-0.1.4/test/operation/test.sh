#!/bin/sh

../src/fukashigi -n 4 -t diagram '~' operation/a.diagram > _ || exit
diff -bu operation/not_a.diagram _ || exit
../src/fukashigi -n 4 -t diagram '#' operation/b.diagram > _ || exit
diff -bu operation/hit_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram 2 operation/a.diagram > _ || exit
diff -bu operation/size_a.diagram _ || exit

# TODO: <, >

../src/fukashigi -n 4 -t diagram operation/a.diagram '&' operation/b.diagram > _ || exit
diff -bu operation/a_and_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '|' operation/b.diagram > _ || exit
diff -bu operation/a_or_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '-' operation/b.diagram > _ || exit
diff -bu operation/a_minus_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '/' operation/d.diagram > _ || exit
diff -bu operation/a_div_d.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '%' operation/d.diagram > _ || exit
diff -bu operation/a_mod_d.diagram _ || exit

../src/fukashigi -n 4 -t diagram operation/a.diagram '&' '~' operation/b.diagram '/' operation/d.diagram > _ || exit
diff -bu operation/a_and_not_b_div_d.diagram _ || exit

rm -f _

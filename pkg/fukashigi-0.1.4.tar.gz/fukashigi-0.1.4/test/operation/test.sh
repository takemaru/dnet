#!/bin/sh

../src/fukashigi -n 4 -t diagram '~' operation/a.diagram > _ || exit
diff -bu operation/not_a.diagram _ || exit
../src/fukashigi -n 5 -t diagram '(minimal)' operation/e.diagram > _ || exit
diff -bu operation/minimal_e.diagram _ || exit
../src/fukashigi -n 5 -t diagram '(maximal)' operation/e.diagram > _ || exit
diff -bu operation/maximal_e.diagram _ || exit
../src/fukashigi -n 4 -t diagram '#' operation/b.diagram > _ || exit
diff -bu operation/hit_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram 2 operation/a.diagram > _ || exit
diff -bu operation/size_a.diagram _ || exit

../src/fukashigi -n 4 -t diagram operation/a.diagram '&' operation/b.diagram > _ || exit
diff -bu operation/a_and_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '|' operation/b.diagram > _ || exit
diff -bu operation/a_or_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '-' operation/b.diagram > _ || exit
diff -bu operation/a_sub_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '*' operation/b.diagram > _ || exit
diff -bu operation/a_mul_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '^' operation/b.diagram > _ || exit
diff -bu operation/a_symdiff_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '/' operation/d.diagram > _ || exit
diff -bu operation/a_div_d.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '%' operation/d.diagram > _ || exit
diff -bu operation/a_mod_d.diagram _ || exit

../src/fukashigi -n 4 -t diagram operation/a.diagram '(subsets)' operation/b.diagram > _ || exit
diff -bu operation/a_subsets_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '(supersets)' operation/b.diagram > _ || exit
diff -bu operation/a_supersets_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '(nonsubsets)' operation/b.diagram > _ || exit
diff -bu operation/a_nonsubsets_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '(nonsupersets)' operation/b.diagram > _ || exit
diff -bu operation/a_nonsupersets_b.diagram _ || exit

../src/fukashigi -n 4 -t diagram operation/a.diagram '&' '~' operation/b.diagram '/' operation/d.diagram > _ || exit
diff -bu operation/a_and_not_b_div_d.diagram _ || exit

rm -f _

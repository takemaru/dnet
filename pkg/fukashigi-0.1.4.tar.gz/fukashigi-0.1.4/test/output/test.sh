#!/bin/sh

../src/fukashigi -n 4 -t bitmap output/a.diagram > _ || exit
diff -bu output/a.bitmap _ || exit
../src/fukashigi -n 4 -t card output/a.diagram > _ || exit
diff -bu output/a.card _ || exit
../src/fukashigi -n 4 -t diagram output/a.enum > _ || exit
diff -bu output/a.diagram _ || exit
../src/fukashigi -n 4 -t enum output/a.diagram > _ || exit
diff -bu output/a.enum _ || exit

../src/fukashigi -n 4 -t bitmap -s 3 output/a.diagram > _ || exit
diff -bu output/size_a.bitmap _ || exit
../src/fukashigi -n 4 -t card -s 3 output/a.diagram > _ || exit
diff -bu output/size_a.card _ || exit
../src/fukashigi -n 4 -t diagram -s 3 output/a.diagram > _ || exit
diff -bu output/size_a.diagram _ || exit
../src/fukashigi -n 4 -t enum -s 3 output/a.diagram > _ || exit
diff -bu output/size_a.enum _ || exit

# TODO: with option "-w" without "-s"

../src/fukashigi -n 4 -t bitmap -s 3 -w output/weights output/a.diagram > _ || exit
diff -bu output/size_weight_a.bitmap _ || exit
../src/fukashigi -n 4 -t card -s 3 -w output/weights output/a.diagram > _ || exit
diff -bu output/size_weight_a.card _ || exit
../src/fukashigi -n 4 -t diagram -s 3 -w output/weights output/a.diagram > _ || exit
diff -bu output/size_weight_a.diagram _ || exit
../src/fukashigi -n 4 -t enum -s 3 -w output/weights output/a.diagram > _ || exit
diff -bu output/size_weight_a.enum _ || exit

../src/fukashigi -n 4 -t card output/bot.diagram > _ || exit
diff -bu output/bot.card _ || exit
../src/fukashigi -n 4 -t card output/top.diagram > _ || exit
diff -bu output/top.card _ || exit

../src/fukashigi -n 468 -t card output/large-a.diagram > _ || exit
diff -bu output/large-a.card _ || exit

rm -f _

#!/bin/sh

../src/fukashigi -n 468 -t card output/large-a.diagram > _ || exit
diff -bu output/large-a.card _ || exit

rm -f _

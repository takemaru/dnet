#!/bin/sh

../src/fukashigi -n 4 -t diagram input/a.bitmap > _ || exit
diff -bu input/a.diagram _ || exit
../src/fukashigi -n 4 -t enum input/a.diagram > _ || exit
diff -bu input/a.enum _ || exit
../src/fukashigi -n 4 -t diagram input/a.enum > _ || exit
diff -bu input/a.diagram _ || exit
../src/fukashigi -n 4 -t diagram input/b.subgraph > _ || exit
diff -bu input/b.diagram _ || exit
../src/fukashigi -n 4 -t diagram input/c.cnf > _ || exit
diff -bu input/c.diagram _ || exit

../src/fukashigi -n 4 -t diagram input/bot.enum > _ || exit
diff -bu input/bot.diagram _ || exit
../src/fukashigi -n 4 -t enum input/bot.diagram > _ || exit
diff -bu input/bot.enum _ || exit
../src/fukashigi -n 4 -t diagram input/top.enum > _ || exit
diff -bu input/top.diagram _ || exit
../src/fukashigi -n 4 -t enum input/top.diagram > _ || exit
diff -bu input/top.enum _ || exit

rm -f _

#include "fukashigi.h"

#include "MateSForest.h"
#include "MateSTree.h"
#include "MateRForest.h"
#include "MateSTPath.h"
#include "MateDSTPath.h"
#include "MateSTEDPath.h"
#include "MateComponent.h"
#include "MateKcut.h"
#include "MateRcut.h"

BDD bdd_read_bitmaps(char* fname) {
    ifstream fin(fname);
    char* buf = new char[2 * n_vars];
    BDD f;
    while (fin.getline(buf, sizeof(buf))) {
        assert(strlen(buf) == 2 * n_vars - 1);
        BDD g(1);
        for (int v = n_vars; v > 0; v--) {
            char c = buf[2 * (v - 1)];
            if (c == '0') g &= ~ BDDvar(bdd_v(v));
            if (c == '1') g &=   BDDvar(bdd_v(v));
        }
        f |= g;
    }
    return f;
}

BDD bdd_read_subgraphs(char* fname) {
    assert(! "not supported");
}

BDD bdd_read_diagram(char* fname) {
    FILE* fp = fopen(fname, "r");
    return BDD_Import(fp);
}

BDD bdd_read(char* fname) {
    ifstream fin(fname);
    char buf[8];
    fin.getline(buf, sizeof(buf));
    return buf[1] == ' ' ? bdd_read_bitmaps(fname)
         : buf[0] != '_' ? bdd_read_subgraphs(fname)
         :                 bdd_read_diagram(fname);
}

ZBDD zdd_read_enum(char* fname) {
    ifstream fin(fname);
    char* buf = new char[8 * n_vars];
    ZBDD f = ZBDD(0); // \bot
    while (fin.getline(buf, 8 * n_vars)) { // don't use sizeof operator for pointers
        ZBDD g = ZBDD(1); // \top
        char* p = strtok(buf, ", ");
        while (p != NULL) {
            int v = atoi(p);
            g *= ZBDD(1).Change(v + BDDV_SysVarTop);
            p = strtok(NULL, ", ");
        }
        f += g;
    }
    return f;
}

ZBDD zdd_read_bitmaps(char* fname) {
    ifstream fin(fname);
    char* buf = new char[2 * n_vars];
    ZBDD f = ZBDD(0); // \bot
    while (fin.getline(buf, 2 * n_vars)) { // don't use sizeof operator for pointers
        assert(strlen(buf) == 2 * n_vars - 1);
        ZBDD* nodes = new ZBDD[n_vars + 2];
        nodes[0] = ZBDD(0);
        nodes[1] = ZBDD(1);
        for (int v = n_vars; v > 0; v--) {
            char c = buf[2 * (v - 1)];
            int i = n_vars - v + 2;
            nodes[i] = c == '0' ? nodes[i - 1] + vars[v] * nodes[0]
                     : c == '1' ? nodes[0]     + vars[v] * nodes[i - 1]
                     :            nodes[i - 1] + vars[v] * nodes[i - 1];
        }
        f += nodes[n_vars + 1];
    }
    return f;
}

ZBDD convert(PseudoZDD* zdd) {
    vector<intx>* level_list = zdd->GetLevelFirstList();
    vector<intx>* lo_list = zdd->GetLoNodeList();
    vector<intx>* hi_list = zdd->GetHiNodeList();
    ZBDD* nodes = new ZBDD[zdd->GetNumberOfNodes() + 2];
    nodes[0] = ZBDD(0);
    nodes[1] = ZBDD(1);
    for (int v = n_vars; v > 0; v--) {
        for (intx n = (*level_list)[v - 1]; n < (*level_list)[v]; n++) {
            int l = (*lo_list)[n];
            int h = (*hi_list)[n];
            nodes[n] = nodes[l] + vars[v] * nodes[h];
        }
    }
    return nodes[2]; // XXX root node is always nodes[2]?
}

ZBDD zdd_read_subgraphs(char* fname) {
    int enum_kind = 0;
    int start_vertex = 1; // start vertex number for (directed / undirected) s-t path
    int end_vertex = -1;  // end vertex number for (directed / undirected) s-t path
    int max_cut_num = 99999999; // enumerate at most 'max_cut_num' cuts for k-cut or r-cut
    bool is_le = false; // for enumeration of components
    bool is_me = false; // for enumeration of components

    RootManager root_mgr;

    enum {
        SFOREST, // spanning forest
        STREE,   // spanning tree
        STPATH,  // s-t path or cycle
        DSTPATH, // directed s-t path or cycle
        STEDPATH, // s-t edge-disjoint path
        RFOREST, // rooted (spanning) forest
        COMP,    // component
        KCUT,    // k-cut
        RCUT,    // rooted k-cut
    };

    ifstream fin(fname);
    char buf[1024];
    fin.getline(buf, sizeof(buf));
    string kind = strtok(buf, ", ");
    if      (kind == "sforest" ) enum_kind = SFOREST;
    else if (kind == "stree"   ) enum_kind = STREE;
    else if (kind == "stpath"  ) enum_kind = STPATH;
    else if (kind == "dstpath" ) enum_kind = DSTPATH;
    else if (kind == "stedpath") enum_kind = STEDPATH;
    else if (kind == "rforest" ) enum_kind = RFOREST;
    else if (kind == "comp"    ) enum_kind = COMP;
    else if (kind == "kcut"    ) enum_kind = KCUT;
    else if (kind == "rcut"    ) enum_kind = RCUT;

    if (kind == "stpath" || kind == "dstpath" || kind == "stedpath") {
        start_vertex = atoi(strtok(NULL, ", "));
        end_vertex = atoi(strtok(NULL, ", "));
        // TODO: support cycle and hamilton one (and to any vertices)
    }
    else if (kind == "rforest" || kind == "rcut") {
        char* p;
        while ((p = strtok(NULL, ", ")) != NULL)
            root_mgr.Add(atoi(p));
    }
    else if (kind == "kcut") {
        string op = strtok(NULL, ", ");
        if (op == "<=") is_le = true;
        if (op == ">=") is_me = true;
        max_cut_num = atoi(strtok(NULL, ", "));
    }

    Graph* graph = new Graph();
    graph->LoadC(fin);

    if (enum_kind == STPATH || enum_kind == DSTPATH || enum_kind == STEDPATH)
        if (end_vertex < 0)
            end_vertex = graph->GetVertexSize();

    State* state = NULL;

    switch (enum_kind) {
    case SFOREST:
        state = new StateSForest(graph);
        break;
    case STREE:
        state = new StateSTree(graph);
        break;
    case STPATH:
    case DSTPATH:
        if (enum_kind == STPATH) {
            state = new StateSTPath(graph);
        } else {
            state = new StateDSTPath(graph);
        }
        static_cast<StateSTPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTPath*>(state)->SetHamilton(false);
        static_cast<StateSTPath*>(state)->SetCycle(false);
        break;
    case STEDPATH:
        state = new StateSTEDPath(graph);
        static_cast<StateSTEDPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTEDPath*>(state)->SetHamilton(false);
        static_cast<StateSTEDPath*>(state)->SetCycle(false);
        break;
    case RFOREST:
        state = new StateRForest(graph);
        static_cast<StateRForest*>(state)->SetRootManager(&root_mgr);
        break;
    case COMP:
        state = new StateComponent(graph, max_cut_num, is_le, is_me);
        break;
    case KCUT:
        state = new StateKcut(graph, max_cut_num);
        break;
    case RCUT:
        state = new StateRcut(graph, max_cut_num);
        static_cast<StateRcut*>(state)->SetRootManager(&root_mgr);
        break;
    }

    ZDDNode::Initialize(state);

    PseudoZDD* zdd = new PseudoZDD;
    zdd->Construct(state);
    zdd->Reduce();

    ZBDD f = convert(zdd);

    delete zdd;
    ZDDNode::Finalize();
    if (state != NULL) delete state;
    delete graph;

    return f;
}

ZBDD zdd_read_diagram(char* fname) {
    ifstream fin(fname);
    char buf[32];
    fin.getline(buf, sizeof(buf));
    int n, v, l, h;
    sscanf(buf, "%d: (~%d?%d:%d)", &n, &v, &l, &h);
    ZBDD* nodes = new ZBDD[n + 1];
    nodes[0] = ZBDD(0);
    nodes[1] = ZBDD(1);
    nodes[n] = nodes[l] + vars[v] * nodes[h];
    while (fin.getline(buf, sizeof(buf))) {
        sscanf(buf, "%d: (~%d?%d:%d)", &n, &v, &l, &h);
        nodes[n] = nodes[l] + vars[v] * nodes[h];
    }
    return nodes[2];
}

ZBDD zdd_read(char* fname) {
    ifstream fin(fname);
    char buf[8];
    fin.getline(buf, sizeof(buf));
    return isalpha(buf[0])                                          ? zdd_read_subgraphs(fname)
         : strchr(buf, ':') != NULL                                 ? zdd_read_diagram(fname)
         : strstr(buf, " 0 ") != NULL || strstr(buf, " * ") != NULL ? zdd_read_bitmaps(fname)
         :                                                            zdd_read_enum(fname);
}

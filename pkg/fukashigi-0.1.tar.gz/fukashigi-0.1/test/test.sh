#!/bin/sh

../src/fukashigi -b -n 4 -t diagram  a.bitmaps '&' '~' b.bdd > _ && \
diff -bu b1.bdd _ && \

../src/fukashigi -n 4 -t card  a.bitmaps > _ && \
diff -bu z1.card _ && \
../src/fukashigi -n 4 -t enum  a.bitmaps '&' b.zdd '|' c.subgraphs > _ && \
diff -bu z2.enum _ && \
../src/fukashigi -n 4 -t diagram  a.zdd '|' b.bitmaps '-' c.subgraphs > _ && \
diff -bu z3.zdd _ && \
../src/fukashigi -n 4 -t diagram  b.zdd '&' '#' c.subgraphs > _ && \
diff -bu z4.zdd _ && \

rm -f _

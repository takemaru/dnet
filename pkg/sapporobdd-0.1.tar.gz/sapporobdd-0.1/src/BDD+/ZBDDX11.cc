/****************************************
 * ZBDD+ Manipulator (SAPPORO-1.21)     *
 * (Graphic methods)                    *
 * (C) Shin-ichi MINATO (Feb. 18, 2009) *
 ****************************************/

#include "ZBDD.h"

extern "C"
{
	extern void bddgraph(...);
	extern void bddvgraph(...);
//	extern void bddgraph0(...);
//	extern void bddvgraph0(...);
}

void ZBDD::XPrint()
{
	bddgraph(_zbdd);
}

void ZBDDV::XPrint()
{
	int len = Last() + 1;
	bddword* bddv = new bddword[len];
	for(int i=0; i<len; i++) bddv[i] = GetZBDD(i).GetID(); 
	bddvgraph(bddv, len);
	delete[] bddv;
}

/*
void ZBDD::XPrint0()
{
	bddgraph0(_zbdd);
}

void ZBDDV::XPrint0()
{
	int len = Last() + 1;
	bddword* bddv = new bddword[len];
	for(int i=0; i<len; i++) bddv[i] = GetZBDD(i).GetID(); 
	bddvgraph0(bddv, len);
	delete[] bddv;
}
*/

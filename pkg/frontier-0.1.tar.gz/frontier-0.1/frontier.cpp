#include <cstdio>
#include <ctime>
#include <string>
#include <fstream>
#include "MateSForest.h"
#include "MateSTree.h"
#include "MateRForest.h"
#include "MateSTPath.h"
#include "MateDSTPath.h"
#include "MateSTEDPath.h"
#include "MateComponent.h"
#include "MateKcut.h"
#include "MateRcut.h"
#include "MateSetPartition.h"
#include "MateSetCover.h"
#include "MateSetPacking.h"
#include "Automaton.h"

//#include <mcheck.h>

using namespace std;

int main(int argc, char** argv)
{
    int enum_kind = 0;
    bool is_print_graph = false; // print the input graph
    bool is_print_graphC = false; // print the input graph
    string print_graph_filename = "";
    bool is_print_graphviz = false; // print the input graph for graphviz
    string print_graphviz_filename = "";
    bool is_breadth_first = false; // rename vertex numbers by the breadth-first search if true
    bool use_edge_list = false; // use the input format of edge list if true
    int start_vertex = 1; // start vertex number for (directed / undirected) s-t path
    int end_vertex = -1;  // end vertex number for (directed / undirected) s-t path
    bool is_hamilton = false; // use all vertices for an s-t path or a cycle
    bool is_cycle = false;    // if this option is true and enum_kind == STPATH or DSTPATH, enumerate cycles
    bool is_any_path = false; // enumerate paths from start_vertex to any vertex
    int max_cut_num = 99999999; // enumerate at most 'max_cut_num' cuts for k-cut or r-cut
    bool is_le = false; // for enumeration of components
    bool is_me = false; // for enumeration of components
    bool is_reduce = false; // reduce the ZDD
    bool is_print_pzdd = true; // print the (pseudo) ZDD
    bool is_print_zdd_graphviz = false; // print the (pseudo) ZDD for graphviz
    bool is_print_zero = false; // print zero-terminal if true
    string print_zdd_graphviz_filename = "";
    bool is_print_zdd_sbdd = false; // print the (pseudo) ZDD for SapporoBDD
    string print_zdd_sbdd_filename = "";
    bool is_compute_solution = true; // compute and print the number of solutions of the constructed ZDD
    bool is_enum = false; // enumerate and output all solutions
    string enum_filename = "";
    bool is_sample = false; // sample solutions randomly
    string sample_filename = "";
    int sample_num = 100; // the number of solutions to sample
    bool is_hex = false; // hexadecimal ZDD node ID
    bool is_use_automaton = false; // construct the automaton from the ZDD
    bool is_print_am = false; // print the constructed automaton

    RootManager root_mgr;

    enum {
        SFOREST, // spanning forest
        STREE,   // spanning tree
        STPATH,  // s-t path or cycle
        DSTPATH, // directed s-t path or cycle
        STEDPATH, // s-t edge-disjoint path
        RFOREST, // rooted (spanning) forest
        COMP,    // component
        KCUT,    // k-cut
        RCUT,    // rooted k-cut
        SETPT,   // set partition on a hypergraph
        SETC,    // set cover 
        SETPK,   // set packing
    };

    //mtrace(); // for debug

    srand(static_cast<unsigned int>(time(NULL)));

    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg == "-t") {
            if (i + 1 < argc) {
                string kind = argv[i + 1];
                if (kind == "sforest") {
                    enum_kind = SFOREST;
                } else if (kind == "stree") {
                    enum_kind = STREE;
                } else if (kind == "stpath") {
                    enum_kind = STPATH;
                } else if (kind == "dstpath") {
                    enum_kind = DSTPATH;
                } else if (kind == "stedpath") {
                    enum_kind = STEDPATH;
                } else if (kind == "rforest") {
                    enum_kind = RFOREST;
                } else if (kind == "comp") {
                    enum_kind = COMP;
                } else if (kind == "kcut") {
                    enum_kind = KCUT;
                } else if (kind == "rcut") {
                    enum_kind = RCUT;
                } else if (kind == "setpt") {
                    enum_kind = SETPT;
                } else if (kind == "setc") {
                    enum_kind = SETC;
                } else if (kind == "setpk") {
                    enum_kind = SETPK;
                } else {
                    cerr << "Error: unknown enum_type: " << kind << "." << endl;
                    exit(1);
                }
            }
            ++i;
        } else if (arg == "--print-graph") {
            is_print_graph = true;
            if (i + 1 < argc) {
                print_graph_filename = argv[i + 1];
                ++i;
            }
        } else if (arg == "--print-graph-el") {
            is_print_graphC = true;
            if (i + 1 < argc) {
                print_graph_filename = argv[i + 1];
                ++i;
            }
        } else if (arg == "--print-graphviz") {
            is_print_graphviz = true;
            if (i + 1 < argc) {
                print_graphviz_filename = argv[i + 1];
                ++i;
            }
        } else if (arg == "-b") {
            is_breadth_first = true;
        } else if (arg == "-c") {
            use_edge_list = true;
        } else if (arg == "-s") {
            if (i + 1 < argc) {
                start_vertex = atoi(argv[i + 1]);
            }
            ++i;
        } else if (arg == "-e") {
            if (i + 1 < argc) {
                end_vertex = atoi(argv[i + 1]);
            }
            ++i;
        } else if (arg == "-h") {
            is_hamilton = true;
        } else if (arg == "--cycle") {
            is_cycle = true;
        } else if (arg == "--any") {
            is_any_path = true;
        } else if (arg == "-k") {
            max_cut_num = atoi(argv[i + 1]);
            ++i;
        } else if (arg == "--le") {
            is_le = true;
        } else if (arg == "--me") {
            is_me = true;
        } else if (arg == "-f") {
            // -f オプションの後は "-f 1 3 7 9" のように整数が並ぶので、それをパースする。
            while (i + 1 < argc && argv[i + 1][0] != '-') {
                root_mgr.Add(atoi(argv[i + 1]));
                ++i;
            }
            if (root_mgr.GetSize() == 0) {
                cerr << "Error: need integer(s) after -f." << endl;
                exit(1);
            }
        } else if (arg == "-r") {
            is_reduce = true;
        } else if (arg == "--no-print-zdd") {
            is_print_pzdd = false;
        } else if (arg == "--print-zdd-graphviz") {
            is_print_zdd_graphviz = true;
            if (i + 1 < argc) {
                print_zdd_graphviz_filename = argv[i + 1];
                ++i;
            }
            // parse if the next argument is an integer
            if (i + 1 < argc && argv[i + 1][0] == '0') {
                is_print_zero = true;
                ++i;
            }
        } else if (arg == "--print-zdd-sbdd") {
            is_reduce = true;
            is_print_zdd_sbdd = true;
            if (i + 1 < argc) {
                print_zdd_sbdd_filename = argv[i + 1];
                ++i;
            }
        } else if (arg == "--no-solution") {
            is_compute_solution = false;
        } else if (arg == "--enum") {
            is_enum = true;
            if (i + 1 < argc) {
                enum_filename = argv[i + 1];
                ++i;
            }
        } else if (arg == "--sample") {
            is_sample = true;
            if (i + 1 < argc) {
                sample_filename = argv[i + 1];
                ++i;
            }
            // parse if the next argument is an integer
            if (i + 1 < argc && '0' <= argv[i + 1][0] && argv[i + 1][0] <= '9') {
                sample_num = atoi(argv[i + 1]);
                ++i;
            }
        } else if (arg == "--hex") {
            is_hex = true;
        } else if (arg == "--am") {
            is_use_automaton = true;
        } else if (arg == "--print-am") {
            is_print_am = true;
        } else {
            cerr << "Error: unknown option: " << arg << "." << endl;
            exit(1);
        }
    }

    Graph* graph = NULL;
    HyperGraph* hgraph = NULL;

    switch (enum_kind) {
    case SFOREST:
    case STREE:
    case STPATH:
    case STEDPATH:
    case RFOREST:
    case COMP:
    case KCUT:
    case RCUT:
        graph = new Graph();
        // 標準入力からグラフを読み込む
        if (use_edge_list) {
            graph->LoadC(cin); // 辺リスト形式
        } else {
            graph->Load(cin); // 隣接リスト形式
        }
        break;
    case DSTPATH:
        graph = new Graph();
        // 標準入力からグラフを読み込む
        if (use_edge_list) {
            graph->LoadC(cin); // 辺リスト形式
        } else {
            graph->LoadDirected(cin); // 隣接リスト形式、有向グラフ
        }
        break;
    case SETPT:
    case SETC:
    case SETPK:
        hgraph = new HyperGraph();
        // 標準入力からグラフを読み込む
        if (use_edge_list) {
            hgraph->LoadC(cin); // 辺リスト形式
        } else {
            hgraph->Load(cin); // 隣接リスト形式
        }
        break;
    }
    cerr << "# of vertices: " << graph->GetVertexSize() << ", # of edges: " << graph->GetEdgeList()->size() << endl;

    if (is_breadth_first) {
        if (graph != NULL) {
            graph->RearrangeByBreadthFirst(start_vertex);
        }
    }

    if (enum_kind == STPATH || enum_kind == DSTPATH || enum_kind == STEDPATH) {
        if (end_vertex < 0) { // 終端に指定が無ければ
            end_vertex = graph->GetVertexSize(); // 終端を最後にする
        }
        if (is_any_path) {
            graph->AddDummyVertex(); // ダミーの頂点を加える
            end_vertex = graph->GetVertexSize();
        }
    }

    if (is_print_graph) {
        if (print_graph_filename == "") {
            cerr << "Please input a filename for print_graph." << endl;
            exit(1);
        } else if (print_graph_filename == "-") {
            graph->Print(cout);
            return 0;
        } else {
            ofstream ofs(print_graph_filename.c_str());
            graph->Print(ofs);
            return 0;
        }
    } else if (is_print_graphC) {
        if (print_graph_filename == "") {
            cerr << "Please input a filename for print_graphC." << endl;
            exit(1);
        } else if (print_graph_filename == "-") {
            graph->PrintC(cout);
            return 0;
        } else {
            ofstream ofs(print_graph_filename.c_str());
            graph->PrintC(ofs);
            return 0;
        }
    }

    if (is_print_graphviz) {
        if (print_graphviz_filename == "") {
            cerr << "Please input a filename for print_graphviz." << endl;
            exit(1);
        } else if (print_graphviz_filename == "-") {
            graph->PrintForGraphviz(cout);
            return 0;
        } else {
            ofstream ofs(print_graphviz_filename.c_str());
            graph->PrintForGraphviz(ofs);
            return 0;
        }
    }

    State* state = NULL;

    switch (enum_kind) {
    case SFOREST:
        state = new StateSForest(graph);
        break;
    case STREE:
        state = new StateSTree(graph);
        break;
    case STPATH:
    case DSTPATH:
        if (enum_kind == STPATH) {
            state = new StateSTPath(graph);
        } else {
            state = new StateDSTPath(graph);
        }
        static_cast<StateSTPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTPath*>(state)->SetHamilton(is_hamilton);
        static_cast<StateSTPath*>(state)->SetCycle(is_cycle);
        break;
    case STEDPATH:
        state = new StateSTEDPath(graph);
        static_cast<StateSTEDPath*>(state)->SetStartAndEndVertex(start_vertex, end_vertex);
        static_cast<StateSTEDPath*>(state)->SetHamilton(is_hamilton);
        static_cast<StateSTEDPath*>(state)->SetCycle(is_cycle);
        break;
    case RFOREST:
        state = new StateRForest(graph);
        static_cast<StateRForest*>(state)->SetRootManager(&root_mgr);
        break;
    case COMP:
        state = new StateComponent(graph, max_cut_num, is_le, is_me);
        break;
    case KCUT:
        state = new StateKcut(graph, max_cut_num);
        break;
    case RCUT:
        state = new StateRcut(graph, max_cut_num);
        static_cast<StateRcut*>(state)->SetRootManager(&root_mgr);
        break;
    case SETPT:
        state = new StateSetPartition(hgraph);
        break;
    case SETC:
        state = new StateSetCover(hgraph);
        break;
    case SETPK:
        state = new StateSetPacking(hgraph);
        break;
    }

    ZDDNode::Initialize(state); // ZDDノードの初期化

    PseudoZDD* zdd = new PseudoZDD;
    zdd->Construct(state); // アルゴリズム開始

    intx number_of_nodes = zdd->GetNumberOfNodes();

    if (is_reduce) {
        zdd->Reduce(); // ZDDの既約化
    }

    if (is_print_pzdd) {
        zdd->OutputZDD(stdout, is_hex); // ZDDを標準出力に出力する
    }

    if (is_print_zdd_graphviz) {
        if (print_zdd_graphviz_filename == "") {
            cerr << "Please input a filename for print_zdd_graphviz." << endl;
            exit(1);
        } else if (print_zdd_graphviz_filename == "-") {
            zdd->OutputZDDForGraphviz(cout, is_print_zero);
        } else {
            ofstream ofs(print_zdd_graphviz_filename.c_str());
            zdd->OutputZDDForGraphviz(ofs, is_print_zero);
        }
    } 

    if (is_print_zdd_sbdd) {
        if (print_zdd_sbdd_filename == "") {
            cerr << "Please input a filename for print_zdd_sbdd." << endl;
            exit(1);
        } else if (print_zdd_sbdd_filename == "-") {
            zdd->OutputZDDForSapporoBDD(cout);
        } else {
            ofstream ofs(print_zdd_sbdd_filename.c_str());
            zdd->OutputZDDForSapporoBDD(ofs);
        }
    }

    cerr << "# of nodes of ZDD = " << number_of_nodes << endl;

    if (is_reduce) {
        cerr << "# of nodes of reduced ZDD = " << zdd->GetNumberOfNodes() << endl;
    }

    if (is_compute_solution || is_sample) {
        BigInteger num = zdd->ComputeNumberOfSolutions();
        if (is_compute_solution) {
            cerr << "# of solutions = " << num << endl;
        }
    }

    if (is_enum) {
        if (enum_filename == "") {
            cerr << "Please input a filename for enum." << endl;
            exit(1);
        } else if (enum_filename == "-") {
            zdd->OutputAllSolutions(stdout); // 全解を標準出力に出力する
        } else {
            FILE* fout = fopen(enum_filename.c_str(), "w");
            if (fout == NULL) {
                cerr << "file open error!" << endl;
                exit(1);
            }
            zdd->OutputAllSolutions(fout); // 全解を標準出力に出力する
            fclose(fout);
        }
    }

    if (is_sample) {
        if (sample_filename == "") {
            cerr << "Please input a filename for sample." << endl;
            exit(1);
        } else if (sample_filename == "-") {
            zdd->OutputSamplingSolutions(stdout, sample_num); // random sampling
        } else {
            FILE* fout = fopen(sample_filename.c_str(), "w");
            if (fout == NULL) {
                cerr << "file open error!" << endl;
                exit(1);
            }
            zdd->OutputSamplingSolutions(fout, sample_num); // random sampling
            fclose(fout);
        }
    }

    if (is_use_automaton) { // オートマトン化に関する処理
        AutomatonManager am_mgr(zdd);
        Automaton* am = am_mgr.MakeAutomaton3(); // ZDDをオートマトンに変換
        cerr << "# of states = " << am_mgr.GetNumberOfStates() << endl;

        if (is_print_am) {
            am->PrintForGraphviz(); // Graphviz 用出力
        }
    }

    delete zdd; // 後処理
    ZDDNode::Finalize();

    if (state != NULL) {
        delete state;
    }

    if (hgraph != NULL) {
        delete hgraph;
    }
    if (graph != NULL) {
        delete graph;
    }
    //muntrace(); // for debug

    return 0;
}

#include "MateSForest.h"

using namespace std;

//*************************************************************************************************
// StateSForest
StateSForest::StateSForest(Graph* graph) : State(graph)
{
    // nothing
}

Mate* StateSForest::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSForest(NULL);
    } else {
        return new MateSForest(this);
    }
}

//*************************************************************************************************
// MateSForest
MateSForest::MateSForest(State* state)
{
    if (state != NULL) {
        mate_ = new mate_t[state->NUMBER_OF_VERTICES + 1];
    } else {
        mate_ = NULL;
    }
}

MateSForest::~MateSForest()
{
    if (mate_ != NULL) {
        delete[] mate_;
    }
}

// mate を初期化する（初期ZDDノード専用）
void MateSForest::Initialize(State* state)
{
    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = i;
    }
}

// 引数で与えた mate を自身にコピーする
void MateSForest::Copy(Mate* mate, State* state)
{
    MateSForest* m = static_cast<MateSForest*>(mate);

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = m->mate_[i];
    }
}

// mate が「等価」かどうか判定する
bool MateSForest::Equals(Mate* mate, State* state)
{
    MateSForest* m = static_cast<MateSForest*>(mate);

    // フロンティアに含まれる各頂点についてmate値が同じかどうか判定
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        mate_t v = *itor;
        if (mate_[v] != m->mate_[v]) {
            return false;
        }
        ++itor;
    }
    return true;
}

// ハッシュ値を取得
uintx MateSForest::GetHashValue(State* state)
{
    uintx hash_value = 0;
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        hash_value = hash_value * 15284356289ll + mate_[*itor];
        ++itor;
    }
    return hash_value;
}

void MateSForest::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理のときのみ更新
        int c1 = mate_[edge.src];
        int c2 = mate_[edge.dest];

        int cmax = (c1 < c2 ? c2 : c1);
        int cmin = (c1 < c2 ? c1 : c2);

        for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
            if (mate_[i] == cmin) {
                mate_[i] = cmax;
            }
        }
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSForest::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        return -1;
    } else {
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] == mate_[edge.dest]) { // generated circle!
            return 0;
        } else {
            return -1;
        }
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateSForest::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        return 1;
    } else {
        return -1;
    }
}

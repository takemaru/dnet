#include "MateSTEDPath.h"
#include <cstring>

using namespace std;

//*************************************************************************************************
// StateSTEDPath
StateSTEDPath::StateSTEDPath(Graph* graph) : State(graph)
{
    // nothing
}

Mate* StateSTEDPath::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSTEDPath(NULL);
    } else {
        return new MateSTEDPath(this);
    }
}

int StateSTEDPath::GetStartVertex()
{
    return start_vertex_;
}

int StateSTEDPath::GetEndVertex()
{
    return end_vertex_;
}

void StateSTEDPath::SetStartAndEndVertex(int start_vertex, int end_vertex)
{
    start_vertex_ = start_vertex;
    end_vertex_ = end_vertex;
}

bool StateSTEDPath::IsHamilton()
{
    return is_hamilton_;
}

void StateSTEDPath::SetHamilton(bool is_hamilton)
{
    is_hamilton_ = is_hamilton;
}

bool StateSTEDPath::IsCycle()
{
    return is_cycle_;
}

void StateSTEDPath::SetCycle(bool is_cycle)
{
    is_cycle_ = is_cycle;
}

//*************************************************************************************************
// MateSTEDPath
MateSTEDPath::MateSTEDPath(State* state)
{
    if (state != NULL) {
        mate_degree_ = new mate_t[state->NUMBER_OF_VERTICES + 1];
        mate_connection_ = new mate_t[state->NUMBER_OF_VERTICES + 1];
    } else {
        mate_degree_ = NULL;
        mate_connection_ = NULL;
    }
}

MateSTEDPath::~MateSTEDPath()
{
    if (mate_degree_ != NULL) {
        delete[] mate_degree_;
    }
    if (mate_connection_ != NULL) {
        delete[] mate_connection_;
    }
}

// mate を初期化する（初期ZDDノード専用）
void MateSTEDPath::Initialize(State* state)
{
    StateSTEDPath* st = static_cast<StateSTEDPath*>(state);
    int sv = st->GetStartVertex();
    int ev = st->GetEndVertex();

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_degree_[i] = 0;
        mate_connection_[i] = i;
    }
    if (!st->IsCycle()) { // パス列挙の場合
        mate_degree_[sv] = 1;
        mate_degree_[ev] = 1;
        mate_connection_[sv] = -1;
        mate_connection_[ev] = -1;
    }
}

// 引数で与えた mate を自身にコピーする
void MateSTEDPath::Copy(Mate* mate, State* state)
{
    MateSTEDPath* m = static_cast<MateSTEDPath*>(mate);

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_degree_[i] = m->mate_degree_[i];
        mate_connection_[i] = m->mate_connection_[i];
    }
}

// mate が「等価」かどうか判定する
bool MateSTEDPath::Equals(Mate* mate, State* state)
{
    MateSTEDPath* m = static_cast<MateSTEDPath*>(mate);

    // フロンティアに含まれる各頂点についてmate値が同じかどうか判定
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        mate_t v = *itor;
        if (mate_degree_[v] != m->mate_degree_[v]) {
            return false;
        }
        if (mate_connection_[v] != m->mate_connection_[v]) {
            return false;
        }
        ++itor;
    }
    return true;
}

// ハッシュ値を取得
uintx MateSTEDPath::GetHashValue(State* state)
{
    uintx hash_value = 0;
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        hash_value = hash_value * 15284356289ll + mate_degree_[*itor];
        hash_value = hash_value * 23106216131ll + mate_connection_[*itor];
        ++itor;
    }
    return hash_value;
}

void MateSTEDPath::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理のときのみ更新
        ++mate_degree_[edge.src];
        ++mate_degree_[edge.dest];

        int c1 = mate_connection_[edge.src];
        int c2 = mate_connection_[edge.dest];

        int cmax = (c1 < c2 ? c2 : c1);
        int cmin = (c1 < c2 ? c1 : c2);

        for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
            if (mate_connection_[i] == cmax) {
                mate_connection_[i] = cmin;
            }
        }
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSTEDPath::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        return -1;
    } else {
        Edge edge = state->GetCurrentEdge();

        /*        if (mate_[edge.src] == 0 || mate_[edge.dest] == 0) { // 分岐が発生した
            return 0;
        } else if (mate_[edge.src] == edge.dest) { // サイクルが完成した
            StateSTEDPath* st = static_cast<StateSTEDPath*>(state);            
            // フロンティアに属する残りの頂点についてチェック
            set<int>::iterator itor = state->GetFrontierIterator();
            while (itor != state->GetFrontierEnd()) {
                mate_t v = *itor;
                // 張った枝の始点と終点はチェックから除外
                if (v != edge.src && v != edge.dest) {
                    if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                        if (mate_[v] != 0) {
                            return 0;
                        }
                    } else {
                        // パスの途中でなく、孤立した点でもない場合、
                        // 不完全なパスができることになるので、0を返す
                        if (mate_[v] != 0 && mate_[v] != v) {
                            return 0;
                        }
                    }
                }
                ++itor;
            }
            if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                if (st->IsExistUnprocessedVertex()) {
                    return 0;
                }
            }
            return 1;
        } else {
            return -1;
            }*/
        return -1;
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateSTEDPath::CheckTerminateAfter(State* state)
{
    StateSTEDPath* st = static_cast<StateSTEDPath*>(state);

    set<int>::iterator itor = state->GetLeavingIterator();
    while (itor != state->GetLeavingEnd()) {
        mate_t v = *itor;
        //if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
        //    if (mate_[v] != 0) {
        //        return 0;
        //    }
        //} else {
        //if (mate_[v] != 0 && mate_[v] != v) {
        //        return 0;
        //    }
        //}
        if (mate_degree_[v] % 2 != 0) {
            //cout << "odd: " << v << ", " << mate_degree_[v] << endl;
            return 0;
        }

        if (mate_degree_[v] >= 1 && mate_connection_[v] >= 1) {
            bool is_exist = false;
            set<int>::iterator itor_f = state->GetFrontierIterator();
            while (itor_f != state->GetFrontierEnd()) {
                if (mate_connection_[v] == mate_connection_[*itor_f]) {
                    is_exist = true;
                    break;
                }
                ++itor_f;
            }
            if (!is_exist) {
                return 0;
            }
        }

        //if (mate_connection_[v] >= 1 && mate_degree_[v] >= 1) {
        //    cout << "con: " << v << ", " << mate_degree_[v] << ", " << mate_connection_[v] << endl;
        //    return 0;
        //}
        ++itor;
    }
    if (state->GetCurrentEdgeNumber() >= state->GetNumberOfEdges() - 1) { // last
        return 1;
    } else {
        return -1;
    }
}

#ifndef MATERCUT_H
#define MATERCUT_H

#include "MateSForest.h"
#include "RootManager.h"

//*************************************************************************************************
// StateRcut: アルゴリズム動作時の「状態」を表すクラス
class StateRcut : public State {
private:
    RootManager* root_mgr_;
    int max_cut_size_;
public:
    StateRcut(Graph* graph, int max_cut_size);
    Mate* CreateMate(bool is_terminal);

    RootManager* GetRootManager();
    void SetRootManager(RootManager* root_mgr);
    int GetMaxCutSize();
};

//*************************************************************************************************
// MateRcut: mate を表すクラス
class MateRcut : public MateSForest {
private:
    int number_of_cuts_;
public:
    MateRcut(State* state);
    void Initialize(State* state);
    void Copy(Mate* mate, State* state);
    bool Equals(Mate* mate, State* state);
    uintx GetHashValue(State* state);
    void UpdateMate(State* state, int lo_or_hi);
    int CheckTerminateBefore(State* state, int lo_or_hi);
    int CheckTerminateAfter(State* state);
};

#endif // MATERCUT_H

#include "MateComponent.h"

using namespace std;

//*************************************************************************************************
// StateComponent
StateComponent::StateComponent(Graph* graph, int component_limit, bool is_le, bool is_me)
    : State(graph), component_limit_(component_limit), is_le_(is_le), is_me_(is_me)
{
    // nothing
}

Mate* StateComponent::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateComponent(NULL);
    } else {
        return new MateComponent(this);
    }
}

int StateComponent::GetComponentLimit()
{
    return component_limit_;
}

bool StateComponent::IsLe()
{
    return is_le_;
}

bool StateComponent::IsMe()
{
    return is_me_;
}

//*************************************************************************************************
// MateComponent
MateComponent::MateComponent(State* state) : MateSForest(state), number_of_components_(0)
{
    // nothing
}

// 引数で与えた mate を自身にコピーする
void MateComponent::Copy(Mate* mate, State* state)
{
    MateSForest::Copy(mate, state);

    MateComponent* m = static_cast<MateComponent*>(mate);

    number_of_components_ = m->number_of_components_;
}

// mate が「等価」かどうか判定する
bool MateComponent::Equals(Mate* mate, State* state)
{
    MateComponent* m = static_cast<MateComponent*>(mate);

    if (number_of_components_ != m->number_of_components_) {
        return false;
    }
    return MateSForest::Equals(mate, state);
}

// ハッシュ値を取得
uintx MateComponent::GetHashValue(State* state)
{
    return MateSForest::GetHashValue(state) * 142624221901ll + number_of_components_ * 12452197ll;
}

void MateComponent::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理
        int c1 = mate_[edge.src];
        int c2 = mate_[edge.dest];

        int cmax = (c1 < c2 ? c2 : c1);
        int cmin = (c1 < c2 ? c1 : c2);

        for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
            if (mate_[i] == cmin) {
                mate_[i] = cmax;
            }
        }
    }

    // フロンティアから抜けるときの処理
    set<int>::iterator itor_l = state->GetLeavingIterator();
    set<int> isolating_set;
    while (itor_l != state->GetLeavingEnd()) {
        mate_t v = *itor_l;
        bool is_exist = false;
        set<int>::iterator itor_f = state->GetFrontierIterator();
        while (itor_f != state->GetFrontierEnd()) {
            if (mate_[v] == mate_[*itor_f]) {
                is_exist = true;
                break;
            }
            ++itor_f;
        }
        if (!is_exist) {
            if (isolating_set.count(mate_[v]) == 0) {
                isolating_set.insert(mate_[v]);
                ++number_of_components_;
            }
        }
        ++itor_l;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateComponent::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) {
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] == mate_[edge.dest]) {
            return 0;
        } else {
            return -1;
        }
    } else {
        return -1;
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateComponent::CheckTerminateAfter(State* state)
{
    StateComponent* st = static_cast<StateComponent*>(state);

    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        if (st->IsLe()) {
            if (number_of_components_ <= st->GetComponentLimit()) {
                return 1;
            } else {
                return 0;
            }
        } else if (st->IsMe()) {
            if (number_of_components_ >= st->GetComponentLimit()) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if (number_of_components_ == st->GetComponentLimit()) {
                return 1;
            } else {
                return 0;
            }
        }
    } else {
        if (st->IsLe() || !st->IsMe()) {
            if (number_of_components_ > st->GetComponentLimit()) { // 枝刈り
                return 0;
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }
}

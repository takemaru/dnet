#include <algorithm>
#include <list>
#include "Graph.h"

using namespace std;

Edge::Edge(int src, int dest)
{
    this->src = src;
    this->dest = dest;
}

void Graph::Load(istream& ist)
{
    number_of_vertices_ = 0;

    string s;
    while (std::getline(ist, s)) {
        ++number_of_vertices_;
        istringstream iss(s);
        int x;
        while (iss >> x) {
            Edge edge(number_of_vertices_, x);
            if (number_of_vertices_ > x) {
                std::swap(edge.src, edge.dest);
            }

            unsigned int e;
            for (e = 0; e < edge_list_.size(); ++e) {
                if (edge_list_[e].src == edge.src && edge_list_[e].dest == edge.dest) {
                    break;
                }
            }
            if (e >= edge_list_.size()) { // 要素が見つからない
                edge_list_.push_back(edge);
            }
        }
    }
}

void Graph::LoadDirected(istream& ist)
{
    number_of_vertices_ = 0;

    string s;
    while (std::getline(ist, s)) {
        ++number_of_vertices_;
        istringstream iss(s);
        int x;
        while (iss >> x) {
            edge_list_.push_back(Edge(number_of_vertices_, x));
        }
    }
}

void Graph::LoadC(istream& ist)
{
    string s;
    std::getline(ist, s);
    istringstream issx(s);
    issx >> number_of_vertices_;

    while (std::getline(ist, s)) {
        istringstream iss(s);
        int src, dest;
        iss >> src >> dest;
        edge_list_.push_back(Edge(src, dest));
    }
}

vector<Edge>* Graph::GetEdgeList()
{
    return &edge_list_;
}

int Graph::GetVertexSize()
{
    return number_of_vertices_;
}

void Graph::RearrangeByBreadthFirst(int start_vertex)
{
    list<Edge> old_edge_list;
    vector<bool> visited_vertex_list(number_of_vertices_ + 1);

    for (int i = 1; i <= number_of_vertices_; ++i) {
        visited_vertex_list[i] = false;
    }

    for (unsigned int i = 0; i < edge_list_.size(); ++i) {
        old_edge_list.push_back(edge_list_[i]);
    }
    edge_list_.clear();

    list<int> vertex_list;

    vertex_list.push_back(start_vertex);
    visited_vertex_list[start_vertex] = true;
    while (vertex_list.size() > 0) {
        int v = vertex_list.front();
        vertex_list.pop_front();

        vector<int> adjacent_list;

        list<Edge>::iterator itor = old_edge_list.begin();
        while (itor != old_edge_list.end()) {
            if (itor->src == v) {
                adjacent_list.push_back(itor->dest);
                itor = old_edge_list.erase(itor);
            } else if (itor->dest == v) {
                adjacent_list.push_back(itor->src);
                itor = old_edge_list.erase(itor);
            } else {
                ++itor;
            }
        }

        for (unsigned int i = 0; i < adjacent_list.size(); ++i) {
            int w = adjacent_list[i];
            if (!visited_vertex_list[w]) {
                visited_vertex_list[w] = true;
                vertex_list.push_back(w);
            }
            int v0 = v;
            if (v0 > w) {
                swap(v0, w);
            }
            edge_list_.push_back(Edge(v0, w));
            //cout << v0 << " " << w << endl;
        }
    }
    if (old_edge_list.size() > 0) {
        cerr << "old_edge_list > 0" << endl;
        exit(1);
    }
    for (unsigned int i = 1; i < visited_vertex_list.size(); ++i) {
        if (!visited_vertex_list[i]) {
            cerr << "visited_vertex_list[" << i << "] == false" << endl;
            exit(1);
        }
    }
}

void Graph::AddDummyVertex()
{
    ++number_of_vertices_;

    list<Edge> new_edge_list;
    for (int i = static_cast<int>(edge_list_.size()) - 1; i >= 0; --i) {
        new_edge_list.push_back(edge_list_[i]);
    }

    for (int v = number_of_vertices_ - 1; v >= 1; --v) {
        list<Edge>::iterator itor = new_edge_list.begin();
        while (itor != new_edge_list.end()) {
            if (itor->src == v || itor->dest == v) {
                new_edge_list.insert(itor, Edge(v, number_of_vertices_));
                break;
            }
            ++itor;
        }
        if (itor == new_edge_list.end()) {
            new_edge_list.insert(itor, Edge(v, number_of_vertices_));
        }
    }

    edge_list_.clear();

    list<Edge>::reverse_iterator itor2 = new_edge_list.rbegin();
    while (itor2 != new_edge_list.rend()) {
        edge_list_.push_back(*itor2);
        //cout << itor2->src << " " << itor2->dest << endl;
        ++itor2;
    }
}

void Graph::Print(ostream& ost)
{
    for (int i = 1; i <= number_of_vertices_; ++i) {
        vector<int> vertex_list;
        for (unsigned int j = 0; j < edge_list_.size(); ++j) {
            if (edge_list_[j].src == i && i < edge_list_[j].dest) {
                vertex_list.push_back(edge_list_[j].dest);
            }
            if (edge_list_[j].dest == i && i < edge_list_[j].src) {
                vertex_list.push_back(edge_list_[j].src);
            }
        }
        sort(vertex_list.begin(), vertex_list.end());
        for (unsigned int j = 0; j < vertex_list.size(); ++j) {
            ost << vertex_list[j];
            if (j < vertex_list.size() - 1) {
                ost << " ";
            }
        }
        ost << endl;
    }
}

void Graph::PrintC(ostream& ost)
{
    ost << number_of_vertices_ << endl;
    for (unsigned int i = 0; i < edge_list_.size(); ++i) {
        ost << edge_list_[i].src << " " << edge_list_[i].dest << endl;
    }
}

void Graph::PrintForGraphviz(ostream& ost)
{
    ost << "graph G {" << endl;
    for (unsigned int i = 0; i < edge_list_.size(); ++i) {
        ost << "\t" << edge_list_[i].src << " -- " << edge_list_[i].dest << " [label=" << (i + 1) << "];" << endl;
    }
    ost << "}" << endl;
}

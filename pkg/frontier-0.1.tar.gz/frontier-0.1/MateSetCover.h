#ifndef MATESETCOVER_H
#define MATESETCOVER_H

#include "MateSetPartition.h"

//*************************************************************************************************
// StateSetPartition: アルゴリズム動作時の「状態」を表すクラス
class StateSetCover : public StateSetPartition {
public:
    StateSetCover(HyperGraph* graph);
    virtual Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateSetCover: mate を表すクラス
class MateSetCover : public MateSetPartition {
public:
    MateSetCover(State* state);
    virtual ~MateSetCover();

    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
};

#endif // MATESETCOVER_H

#ifndef MATESETPACKING_H
#define MATESETPACKING_H

#include "MateSetPartition.h"

//*************************************************************************************************
// StateSetPartition: アルゴリズム動作時の「状態」を表すクラス
class StateSetPacking : public StateSetPartition {
public:
    StateSetPacking(HyperGraph* graph);
    virtual Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateSetPacking: mate を表すクラス
class MateSetPacking : public MateSetPartition {
public:
    MateSetPacking(State* state);
    virtual ~MateSetPacking();

    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
};

#endif // MATESETPACKING_H

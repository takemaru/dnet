#ifndef ROOTMANAGER_H
#define ROOTMANAGER_H

#include <vector>

//*************************************************************************************************
// RootManager: 根を管理するクラス

class RootManager {
private:
    std::vector<int> source_list_;
public:
    void Add(int v);
    int Get(int index);
    int GetSize();
};

#endif // ROOTMANAGER_H

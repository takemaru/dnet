#ifndef MATECOMPONENT_H
#define MATECOMPONENT_H

#include "MateSForest.h"

//*************************************************************************************************
// StateComponent: アルゴリズム動作時の「状態」を表すクラス
class StateComponent : public State {
private:
    int component_limit_;
    bool is_le_; // true なら component 数を component_limit_ 以下に制限
    bool is_me_; // true なら component 数を component_limit_ 以上に制限
    // is_le_, is_me_ ともに false なら component 数を component_limit_ に制限
public:
    StateComponent(Graph* graph, int component_limit, bool is_le, bool is_me);
    Mate* CreateMate(bool is_terminal);

    int GetComponentLimit();
    bool IsLe();
    bool IsMe();
};

//*************************************************************************************************
// MateComponent: mate を表すクラス
class MateComponent : public MateSForest {
private:
    int number_of_components_;
public:
    MateComponent(State* state);

    void Copy(Mate* mate, State* state);
    bool Equals(Mate* mate, State* state);
    uintx GetHashValue(State* state);

    void UpdateMate(State* state, int lo_or_hi);
    int CheckTerminateBefore(State* state, int lo_or_hi);
    int CheckTerminateAfter(State* state);
};

#endif // MATECOMPONENT_H

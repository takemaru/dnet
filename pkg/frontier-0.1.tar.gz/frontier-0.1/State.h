#ifndef STATE_H
#define STATE_H

#include <vector>
#include <set>
#include <algorithm>

#include "Graph.h"

typedef long long int int64;
typedef unsigned long long int uint64;
typedef unsigned short ushort;

#ifdef BIT64
typedef int64 intx;
typedef uint64 uintx;
#define PERCENT_D "%lld"
#define PERCENT_X "%llx"
#else
typedef int intx;
typedef unsigned int uintx;
#define PERCENT_D "%d"
#define PERCENT_X "%x"
#endif

typedef short mate_t;

class Mate;

//*************************************************************************************************
// State: アルゴリズム動作時の「状態」を表すクラス
class State {
public:
    int NUMBER_OF_VERTICES;

protected:
    Graph* graph_;
    int current_edge_;

    std::set<int> frontier_set_;
    std::set<int> leaving_set_;

public:
    State(Graph* graph);
    virtual ~State() {}
    virtual void PrintFrontier();
    int GetCurrentEdgeNumber();
    //virtual int GetNumberOfVertices();
    virtual int GetNumberOfEdges();
    Edge GetCurrentEdge();
    std::vector<Edge>* GetEdgeList();
    bool IsExistUnprocessedVertex();

    virtual Mate* CreateMate(bool is_terminal) = 0;
    virtual void Update(int current_edge);

    std::set<int>::iterator GetFrontierIterator();
    std::set<int>::iterator GetFrontierEnd();
    std::set<int>::iterator GetLeavingIterator();
    std::set<int>::iterator GetLeavingEnd();

    int GetFrontierSize();

private:
    bool Find(int edge_number, int value);
};

//*************************************************************************************************
// Mate: mate を表すクラス
class Mate {
public:
    virtual ~Mate() {}
    virtual void Initialize(State* state) = 0;
    virtual void Copy(Mate* mate, State* state) = 0;
    virtual bool Equals(Mate* mate, State* state) = 0;
    virtual uintx GetHashValue(State* state) = 0;

    virtual void UpdateMate(State* state, int lo_or_hi) = 0;
    virtual int CheckTerminateBefore(State* state, int lo_or_hi) = 0;
    virtual int CheckTerminateAfter(State* state) = 0;
};

#endif // STATE_H

#ifndef MATESTPATH_H
#define MATESTPATH_H

#include "State.h"

//*************************************************************************************************
// StateSTPath: アルゴリズム動作時の「状態」を表すクラス
class StateSTPath : public State {
protected:
    int start_vertex_;
    int end_vertex_;
    bool is_hamilton_;
    bool is_cycle_;

public:
    StateSTPath(Graph* graph);
    Mate* CreateMate(bool is_terminal);

    int GetStartVertex();
    int GetEndVertex();
    void SetStartAndEndVertex(int start_vertex, int end_vertex);
    bool IsHamilton();
    void SetHamilton(bool is_hamilton);
    bool IsCycle();
    void SetCycle(bool is_cycle);
};

//*************************************************************************************************
// MateSTPath: mate を表すクラス
class MateSTPath : public Mate {
protected:
    mate_t* mate_;
public:
    MateSTPath(State* state);
    virtual ~MateSTPath();
    virtual void Initialize(State* state);
    virtual void Copy(Mate* mate, State* state);
    virtual bool Equals(Mate* mate, State* state);
    virtual uintx GetHashValue(State* state);

    virtual void UpdateMate(State* state, int lo_or_hi);
    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
    virtual int CheckTerminateAfter(State* state);
};

#endif // MATESTPATH_H

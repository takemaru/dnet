#include "MateSetPacking.h"

using namespace std;

//*************************************************************************************************
// StateSetPacking
StateSetPacking::StateSetPacking(HyperGraph* graph) : StateSetPartition(graph)
{
    // nothing
}

Mate* StateSetPacking::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSetPacking(NULL);
    } else {
        return new MateSetPacking(this);
    }
}

//*************************************************************************************************
// MateSetPacking

MateSetPacking::MateSetPacking(State* state) : MateSetPartition(state)
{
    // nothing
}

MateSetPacking::~MateSetPacking()
{
    // nothing
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSetPacking::CheckTerminateBefore(State* state, int lo_or_hi)
{
    StateSetPacking* st = static_cast<StateSetPacking*>(state);
    HyperEdge edge = st->GetCurrentEdge();

    if (lo_or_hi == 1) { // Lo枝の処理のときはチェックの必要がない
        for (int i = 0; i < state->NUMBER_OF_VERTICES; ++i) {
            if (edge.var_list[i]) {
                if (GetMateBit(i) == 1) {
                    return 0;
                }
            }
        }
    }
    return -1;
}

#ifndef STATEHYPER_H
#define STATEHYPER_H

#include <vector>
#include <set>
#include <algorithm>

#include "HyperGraph.h"
#include "State.h"

//*************************************************************************************************
// StateHyper: アルゴリズム動作時の「状態」を表すクラス。ハイパーグラフ用
class StateHyper : public State {
private:
    bool Find(int edge_number, int value);

protected:
    HyperGraph* hgraph_;

public:
    StateHyper(HyperGraph* graph);
    void Update(int current_edge);
    void PrintFrontier();
    int GetNumberOfVertices();
    int GetNumberOfEdges();
    HyperEdge GetCurrentEdge();
    std::vector<HyperEdge>* GetEdgeList();
};

#endif // STATEHYPER_H

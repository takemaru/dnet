#include "State.h"

using namespace std;

State::State(Graph* graph) : graph_(graph), current_edge_(-1)
{
    if (graph != NULL) {
        NUMBER_OF_VERTICES = graph->GetVertexSize();
    }
}

int State::GetCurrentEdgeNumber()
{
    return current_edge_;
}

void State::Update(int current_edge)
{
    current_edge_ = current_edge;
    vector<Edge>* edge_list = graph_->GetEdgeList();
    int src = (*edge_list)[current_edge].src;
    int dest = (*edge_list)[current_edge].dest;

    leaving_set_.clear();

    frontier_set_.insert(src);
    frontier_set_.insert(dest);

    if (!Find(current_edge, src)) {
        leaving_set_.insert(src);
        frontier_set_.erase(src);
    }
    if (!Find(current_edge, dest)) {
        leaving_set_.insert(dest);
        frontier_set_.erase(dest);
    }
}

void State::PrintFrontier()
{
    // not implemented.
}

//int State::GetNumberOfVertices()
//{
//    return graph_->GetVertexSize();
//}

int State::GetNumberOfEdges()
{
    return static_cast<int>(graph_->GetEdgeList()->size());
}

Edge State::GetCurrentEdge()
{
    return (*graph_->GetEdgeList())[current_edge_];
}

vector<Edge>* State::GetEdgeList()
{
    return graph_->GetEdgeList();
}

bool State::IsExistUnprocessedVertex()
{
    vector<Edge>* edge_list = graph_->GetEdgeList();
    for (unsigned int i = current_edge_ + 1; i < edge_list->size(); ++i) {
        if (frontier_set_.find((*edge_list)[i].src) == frontier_set_.end()) { // 要素が見つからない
            return true;
        }
        if (frontier_set_.find((*edge_list)[i].dest) == frontier_set_.end()) {
            return true;
        }
    }
    return false;
}

set<int>::iterator State::GetFrontierIterator()
{
    return frontier_set_.begin();
}

set<int>::iterator State::GetFrontierEnd()
{
    return frontier_set_.end();
}

set<int>::iterator State::GetLeavingIterator()
{
    return leaving_set_.begin();
}

set<int>::iterator State::GetLeavingEnd()
{
    return leaving_set_.end();
}

int State::GetFrontierSize()
{
    return static_cast<int>(frontier_set_.size());
}

bool State::Find(int edge_number, int value)
{
    vector<Edge>* edge_list = graph_->GetEdgeList();
    for (unsigned int i = edge_number + 1; i < edge_list->size(); ++i) {
        if (value == (*edge_list)[i].src || value == (*edge_list)[i].dest) {
            return true;
        }
    }
    return false;
}

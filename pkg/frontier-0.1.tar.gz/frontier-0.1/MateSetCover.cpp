#include "MateSetCover.h"

using namespace std;

//*************************************************************************************************
// StateSetCover
StateSetCover::StateSetCover(HyperGraph* graph) : StateSetPartition(graph)
{
    // nothing
}

Mate* StateSetCover::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSetCover(NULL);
    } else {
        return new MateSetCover(this);
    }
}

//*************************************************************************************************
// MateSetCover

MateSetCover::MateSetCover(State* state) : MateSetPartition(state)
{
    // nothing
}

MateSetCover::~MateSetCover()
{
    // nothing
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSetCover::CheckTerminateBefore(State* state, int lo_or_hi)
{
    StateSetCover* st = static_cast<StateSetCover*>(state);
    HyperEdge edge = st->GetCurrentEdge();

    set<int>::iterator itor = state->GetLeavingIterator();
    while (itor != state->GetLeavingEnd()) {
        if (GetMateBit(*itor) == 0) {
            if (lo_or_hi == 0) {
                return 0;
            } else {
                if (!edge.var_list[*itor]) {
                    return 0;
                }
            }
        }
        ++itor;
    }
    return -1;
}

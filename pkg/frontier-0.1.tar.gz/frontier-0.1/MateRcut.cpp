#include "MateRcut.h"

using namespace std;

//*************************************************************************************************
// StateRcut
StateRcut::StateRcut(Graph* graph, int max_cut_size) : State(graph), max_cut_size_(max_cut_size)
{
    // nothing
}

Mate* StateRcut::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateRcut(NULL);
    } else {
        return new MateRcut(this);
    }
}

RootManager* StateRcut::GetRootManager()
{
    return root_mgr_;
}

void StateRcut::SetRootManager(RootManager* root_mgr)
{
    root_mgr_ = root_mgr;
}

int StateRcut::GetMaxCutSize()
{
    return max_cut_size_;
}

//*************************************************************************************************
// MateRcut
MateRcut::MateRcut(State* state) : MateSForest(state), number_of_cuts_(0)
{
    // nothing
}

// mate を初期化する（初期ZDDノード専用）
void MateRcut::Initialize(State* state)
{
    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = i;
    }

    StateRcut* st = static_cast<StateRcut*>(state);
    RootManager* root_mgr = st->GetRootManager();

    for (int i = 0; i < root_mgr->GetSize(); ++i) {
        mate_[root_mgr->Get(i)] += state->NUMBER_OF_VERTICES;
    }
}

// 引数で与えた mate を自身にコピーする
void MateRcut::Copy(Mate* mate, State* state)
{
    MateSForest::Copy(mate, state);

    MateRcut* m = static_cast<MateRcut*>(mate);

    number_of_cuts_ = m->number_of_cuts_;
}

// mate が「等価」かどうか判定する
bool MateRcut::Equals(Mate* mate, State* state)
{
    MateRcut* m = static_cast<MateRcut*>(mate);

    if (number_of_cuts_ != m->number_of_cuts_) {
        return false;
    }
    return MateSForest::Equals(mate, state);
}

// ハッシュ値を取得
uintx MateRcut::GetHashValue(State* state)
{
    return MateSForest::GetHashValue(state) * 142624221901ll + number_of_cuts_ * 105920193ll;
}

void MateRcut::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理
        int c1 = mate_[edge.src];
        int c2 = mate_[edge.dest];

        int cmax = (c1 < c2 ? c2 : c1);
        int cmin = (c1 < c2 ? c1 : c2);

        for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
            if (mate_[i] == cmin) {
                mate_[i] = cmax;
            }
        }
    } else { // Lo枝処理
        ++number_of_cuts_;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateRcut::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        StateRcut* st = static_cast<StateRcut*>(state);
        if (number_of_cuts_ >= st->GetMaxCutSize()) {
            return 0;
        } else {
            Edge edge = state->GetCurrentEdge();
            if (mate_[edge.src] == mate_[edge.dest]) {
                return 0;
            } else {
                return -1;
            }
        }
    } else {
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] != mate_[edge.dest]
            && mate_[edge.src] > state->NUMBER_OF_VERTICES
            && mate_[edge.dest] > state->NUMBER_OF_VERTICES) { // short!
            return 0;
        } else {
            return -1;
        }
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateRcut::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] <= state->NUMBER_OF_VERTICES
            || mate_[edge.dest] <= state->NUMBER_OF_VERTICES) { // no coloring
            return 0;
        } else {
            return 1;
        }
    } else {
        set<int>::iterator itor_l = state->GetLeavingIterator();
        while (itor_l != state->GetLeavingEnd()) {
            mate_t v = *itor_l;
            if (mate_[v] <= state->NUMBER_OF_VERTICES) { // v is not colored
                bool is_exist = false;
                set<int>::iterator itor_f = state->GetFrontierIterator();
                while (itor_f != state->GetFrontierEnd()) {
                    if (mate_[v] == mate_[*itor_f]) {
                        is_exist = true;
                        break;
                    }
                    ++itor_f;
                }
                if (!is_exist) {
                    return 0;
                }
            }
            ++itor_l;
        }
        return -1;
    }
}

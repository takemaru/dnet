#include "MateRForest.h"

using namespace std;

//*************************************************************************************************
// StateRForest
StateRForest::StateRForest(Graph* graph) : State(graph)
{
    // nothing
}

Mate* StateRForest::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateRForest(NULL);
    } else {
        return new MateRForest(this);
    }
}

RootManager* StateRForest::GetRootManager()
{
    return root_mgr_;
}

void StateRForest::SetRootManager(RootManager* root_mgr)
{
    root_mgr_ = root_mgr;
}

//*************************************************************************************************
// MateRForest
MateRForest::MateRForest(State* state) : MateSForest(state)
{
    // nothing
}

// mate を初期化する（初期ZDDノード専用）
void MateRForest::Initialize(State* state)
{
    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = i;
    }

    StateRForest* st = static_cast<StateRForest*>(state);
    RootManager* root_mgr = st->GetRootManager();

    for (int i = 0; i < root_mgr->GetSize(); ++i) {
        mate_[root_mgr->Get(i)] += state->NUMBER_OF_VERTICES;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateRForest::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        return -1;
    } else {
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] == mate_[edge.dest]) { // generated circle!
            return 0;
        } else if (mate_[edge.src] > state->NUMBER_OF_VERTICES
                && mate_[edge.dest] > state->NUMBER_OF_VERTICES) { // short!
            return 0;
        } else {
            return -1;
        }
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateRForest::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] <= state->NUMBER_OF_VERTICES
            || mate_[edge.dest] <= state->NUMBER_OF_VERTICES) { // no coloring
            return 0;
        } else {
            return 1;
        }
    } else {
        set<int>::iterator itor_l = state->GetLeavingIterator();
        while (itor_l != state->GetLeavingEnd()) {
            mate_t v = *itor_l;
            if (mate_[v] <= state->NUMBER_OF_VERTICES) { // v is not colored
                bool is_exist = false;
                set<int>::iterator itor_f = state->GetFrontierIterator();
                while (itor_f != state->GetFrontierEnd()) {
                    if (mate_[v] == mate_[*itor_f]) {
                        is_exist = true;
                        break;
                    }
                    ++itor_f;
                }
                if (!is_exist) {
                    return 0;
                }
            }
            ++itor_l;
        }
        return -1;
    }
}

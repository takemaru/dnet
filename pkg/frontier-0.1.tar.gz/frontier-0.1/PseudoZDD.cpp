#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <map>

#include "PseudoZDD.h"
#include "Automaton.h"

using namespace std;

ZDDNode* ZDDNode::ZeroNode; // 0 終端
ZDDNode* ZDDNode::OneNode; // 1 終端

vector<ZDDNode*> ZDDNode::reuse_node_list_;

//*************************************************************************************************
// ZDDNode

ZDDNode::ZDDNode(State* state, bool is_terminal)
{
    mate_ = state->CreateMate(is_terminal);
}

ZDDNode::~ZDDNode()
{
    delete mate_;
}

// ZDDNode のコピーを作る。mate もコピーされる
ZDDNode* ZDDNode::Clone(State* state)
{
    ZDDNode* node; 
    if (reuse_node_list_.size() > 0) {
        node = reuse_node_list_.back();
        reuse_node_list_.pop_back();
    } else {
        node = new ZDDNode(state, false);
    }
    node->mate_->Copy(mate_, state);
    return node;
}

intx ZDDNode::GetId()
{
    return id_;
}

void ZDDNode::SetId(intx id)
{
    id_ = id;
}

// node が「等価」かどうか判定する
bool ZDDNode::Equals(ZDDNode* node, State* state)
{
    if (node == ZeroNode || node == OneNode || this == ZeroNode || this == OneNode) {
        return node == this;
    } else {
        return mate_->Equals(node->mate_, state);
    }
}

// ハッシュ値を取得
uintx ZDDNode::GetHashValue(State* state)
{
    return mate_->GetHashValue(state);
}

void ZDDNode::UpdateMate(State* state, int lo_or_hi)
{
    mate_->UpdateMate(state, lo_or_hi);
}

int ZDDNode::CheckTerminateBefore(State* state, int lo_or_hi)
{
    return mate_->CheckTerminateBefore(state, lo_or_hi);
}

int ZDDNode::CheckTerminateAfter(State* state)
{
    return mate_->CheckTerminateAfter(state);
}

// 初期ノード（ZDD構築開始時のtopのノード）
ZDDNode* ZDDNode::MakeInitialNode(State* state)
{
    ZDDNode* initial_node = new ZDDNode(state, false);
    initial_node->SetId(2); // 最初のIDは2
    initial_node->mate_->Initialize(state);
    return initial_node;
}

// 最初に1度呼ぶ必要がある
void ZDDNode::Initialize(State* state)
{
    ZeroNode = new ZDDNode(state, true);
    ZeroNode->id_ = 0;
    OneNode = new ZDDNode(state, true);
    OneNode->id_ = 1;
}

void ZDDNode::ClearReuseNodeList()
{
    for (unsigned int i = 0; i < reuse_node_list_.size(); ++i) {
        delete reuse_node_list_[i];
    }
    reuse_node_list_.clear();
}

void ZDDNode::Finalize()
{
    delete OneNode;
    delete ZeroNode;
}

static const unsigned int REUSE_NODE_LIST_LIMIT = 1024;
static const unsigned int REUSE_NODE_LIST_HALF_LIMIT = REUSE_NODE_LIST_LIMIT / 2;

void ZDDNode::DestructNode(ZDDNode* node)
{
    reuse_node_list_.push_back(node);

    if (reuse_node_list_.size() >= REUSE_NODE_LIST_LIMIT) {
        unsigned int n = reuse_node_list_.size();
        for (unsigned int i = REUSE_NODE_LIST_HALF_LIMIT; i < n; ++i) {
            delete reuse_node_list_[i];
        }
        reuse_node_list_.resize(REUSE_NODE_LIST_HALF_LIMIT);
    }
}

//*************************************************************************************************
// Hash

Hash::Hash(intx size) : size_(size)
{
    Initialize();
}

Hash::~Hash()
{
    Deinitialize();
}

/* private */ void Hash::Initialize()
{
    hash_time_table_ = (mate_t*)calloc(size_, sizeof(mate_t)); // 0 padding
    if (hash_time_table_ == NULL) {
        cerr << "Error: calloc for hash_time_table_ failed!" << endl;
        exit(1);
    }

    hash_table_ = (intx*)malloc(size_ * sizeof(intx));
    if (hash_table_ == NULL) {
        cerr << "Error: malloc for hash_table_ failed!" << endl;
        exit(1);
    }
}

/* private */ void Hash::Deinitialize()
{
    free(hash_table_);
    hash_table_ = NULL;
    free(hash_time_table_);
    hash_time_table_ = NULL;
}

void Hash::Expand()
{
    Deinitialize();
    size_ *= 2;
    Initialize();
}

intx Hash::GetSize()
{
    return size_;
}

// hash_value を size_ で割った余りをアドレスとして、
// value をテーブルに格納する。
// 衝突が起きたときは、アドレスを+1して次を試す。
void Hash::Set(uintx hash_value, mate_t time, intx value)
{
    hash_value %= size_;
    for (uintx i = hash_value; i < static_cast<uintx>(size_); ++i) {
        if (hash_time_table_[i] != time) {
            hash_table_[i] = value;
            hash_time_table_[i] = time;
            return;
        }
    }
    for (uintx i = 0; i < hash_value; ++i) {
        if (hash_time_table_[i] != time) {
            hash_table_[i] = value;
            hash_time_table_[i] = time;
            return;
        }
    }
    cerr << "Error: the hash is full!" << endl;
    exit(1);
}

//*************************************************************************************************
// ZDDNodeSet

ZDDNodeSet::ZDDNodeSet(Hash* global_hash) : global_hash_(global_hash)
{
    return;
}

// 集合の大きさを返す
intx ZDDNodeSet::GetSize()
{
    return static_cast<intx>(node_list_.size());
}

// 集合のindex番目の要素を返す
ZDDNode* ZDDNodeSet::Get(intx index)
{
    return node_list_[index];
}

// node と「等価」なZDDNodeが見つかれば、その場所（0始まり）を返す。
// 見つからなければ -1 を返す。
intx ZDDNodeSet::Find(ZDDNode* node, State* state)
{
    if (node == ZDDNode::ZeroNode || node == ZDDNode::OneNode) {
        return -1;
    }

    uintx hash_value = node->GetHashValue(state) % global_hash_->size_;

    while (global_hash_->hash_time_table_[hash_value] == state->GetCurrentEdgeNumber() + 2) {
        intx address = global_hash_->hash_table_[hash_value];
        if (node->Equals(node_list_[address], state)) {
            return address;
        }
        hash_value = (hash_value + 1) % global_hash_->size_;
    }
    return static_cast<intx>(-1);
}

// node を集合に加える
void ZDDNodeSet::Add(ZDDNode* node, State* state)
{
    if (static_cast<intx>(node_list_.size()) >= global_hash_->GetSize() / 2) {
        cerr << "The hash is expanded." << endl;
        global_hash_->Expand();

        for (uintx i = 0; i < node_list_.size(); ++i) {
            global_hash_->Set(node_list_[i]->GetHashValue(state), state->GetCurrentEdgeNumber() + 2, i);
        }
    }
    node_list_.push_back(node);
    global_hash_->Set(node->GetHashValue(state), state->GetCurrentEdgeNumber() + 2, node_list_.size() - 1);
}

void ZDDNodeSet::DeleteClear()
{
    for (unsigned int i = 0; i < node_list_.size(); ++i) {
        ZDDNode::DestructNode(node_list_[i]);
    }
    node_list_.clear();
}

void ZDDNodeSet::Clear()
{
    node_list_.clear();
}

//*************************************************************************************************
// PseudoZDD

PseudoZDD::~PseudoZDD()
{
    for (unsigned int i = 0; i < zdd_node_set_list_.size(); ++i) {
        zdd_node_set_list_[i]->DeleteClear();
        delete zdd_node_set_list_[i];
    }
    zdd_node_set_list_.clear();
}

ZDDNodeSet* PseudoZDD::GetZDDNodeSet(int index)
{
    return zdd_node_set_list_[index];
}

int PseudoZDD::GetHeight()
{
    return static_cast<int>(zdd_node_set_list_.size());
}

vector<intx>* PseudoZDD::GetLoNodeList()
{
    return &lo_list_;
}

vector<intx>* PseudoZDD::GetHiNodeList()
{
    return &hi_list_;
}

vector<intx>* PseudoZDD::GetLevelFirstList()
{
    return &level_first_list_;
}

void PseudoZDD::Construct(State* state)
{
    int m = state->GetNumberOfEdges(); // 辺数
    Hash global_hash(HASH_SIZE);
    zdd_node_set_list_.push_back(new ZDDNodeSet(&global_hash)); // 最初のZDDノード集合
    zdd_node_set_list_[0]->Add(ZDDNode::MakeInitialNode(state), state); // 最初のZDDノード
    intx total_id = 3; // 次に作成したノードに振るID（根ノードには2が既に振られているので、3から始まる）

    lo_list_.push_back(-1);
    lo_list_.push_back(-1);
    hi_list_.push_back(-1);
    hi_list_.push_back(-1);

    // 各辺について、以下を実行する。
    for (int edge = 0; edge < m; ++edge) {
        // 「状態」を更新する
        state->Update(edge);

        // レベルがedge+1のノード用にノード集合を用意
        zdd_node_set_list_.push_back(new ZDDNodeSet(&global_hash));

        // レベルがedge, edge+1のノードの集合
        ZDDNodeSet* current_node_set = zdd_node_set_list_[edge];
        ZDDNodeSet* next_node_set = zdd_node_set_list_[edge + 1];

        // レベルがedgeのノードがどこから始まるかを記録
        level_first_list_.push_back(lo_list_.size());

        // レベルがedgeの各ノードに対するループ
        for (intx i = 0; i < current_node_set->GetSize(); ++i) {
            ZDDNode* node = current_node_set->Get(i);

            ZDDNode* child_node[2]; // child_node[0] が Lo枝の子ノード、child_node[1] が Hi枝の子ノード

            // Lo枝とHi枝について処理をする（lo_or_hi が 0 のとき Lo枝、lo_or_hi が 1 のとき Hi枝についての処理）
            for (int lo_or_hi = 0; lo_or_hi <= 1; ++lo_or_hi) {
                // 子ノードを作成
                child_node[lo_or_hi] = MakeChildNode(node, state, lo_or_hi);

                // child_node が既存のノードと一致するなら、その既存のノードを child_node に代入。
                // 既存のノードがなければ、ZDDのレベル edge+1 のノード集合に新たに child_node を加える。
                intx index = next_node_set->Find(child_node[lo_or_hi], state);
                if (index >= 0) { // 既存のノードが存在すれば
                    ZDDNode::DestructNode(child_node[lo_or_hi]); // 新しく生成されたノードは不要なのでdestruct
                    child_node[lo_or_hi] = next_node_set->Get(index); // 既存のノードを child_node に代入
                } else if (child_node[lo_or_hi] != ZDDNode::ZeroNode
                        && child_node[lo_or_hi] != ZDDNode::OneNode) { // 終端節点でなければ
                    child_node[lo_or_hi]->SetId(total_id); // ノードにIDを振る
                    ++total_id;
                    next_node_set->Add(child_node[lo_or_hi], state); // レベル edge+1 のノード集合に child_node を加える
                }
            }
            SetChildNode(child_node[0]->GetId(), child_node[1]->GetId());
            ZDDNode::DestructNode(node);
        }
        current_node_set->Clear();
        //if (!is_save_prev_level) {
        //    current_node_set->DeleteClear();
        //}
    }
    zdd_node_set_list_[zdd_node_set_list_.size() - 1]->DeleteClear();
    //if (!is_save_prev_level) {
    //    zdd_node_set_list_[zdd_node_set_list_.size() - 1]->DeleteClear();
    //}
    level_first_list_.push_back(lo_list_.size());
    ZDDNode::ClearReuseNodeList();
}

// Lo枝またはHi枝の先の子ノードを計算
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝
/*private*/ ZDDNode* PseudoZDD::MakeChildNode(ZDDNode* node, State* state, int lo_or_hi)
{
    int c = node->CheckTerminateBefore(state, lo_or_hi); // 終端に遷移するか事前にチェック
    if (c == 0) { // 0終端に行くとき
        return ZDDNode::ZeroNode; // 0終端を返す
    } else if (c == 1) { // 1終端に行くとき
        return ZDDNode::OneNode; // 1終端を返す
    }

    ZDDNode* child_node = node->Clone(state); // 親をコピー

    child_node->UpdateMate(state, lo_or_hi); // mate を更新する

    c = child_node->CheckTerminateAfter(state); // 終端に遷移するか再度チェック
    if (c == 0) { // 0終端に行くとき
        ZDDNode::DestructNode(child_node);
        return ZDDNode::ZeroNode; // 0終端を返す
    } else if (c == 1) { // 1終端に行くとき
        ZDDNode::DestructNode(child_node);
        return ZDDNode::OneNode; // 1終端を返す
    } else {
        return child_node;
    }
}

/* private */ void PseudoZDD::SetChildNode(intx lo_node, intx hi_node)
{
    lo_list_.push_back(lo_node);
    hi_list_.push_back(hi_node);

    // node のLo枝の先の子を lo_node に、Hi枝の先の子を hi_node に設定する。
    //node->SetNode(child_node[0], child_node[1]);
}

// This routine is based on simpath-reduce written by D. Knuth.
void PseudoZDD::Reduce()
{
    vector<intx> node_parent_list;
    vector<intx> reduced_lo_list;
    vector<intx> reduced_hi_list;
    vector<intx> reduced_level_list;

    reduced_level_list.resize(level_first_list_.size());

    for (unsigned int i = 0; i < reduced_level_list.size(); ++i) {
        reduced_level_list[i] = -1;
    }

    // begin Knuth's code
    intx head, k, p, q, r = 0;

    lo_list_[0] = -1;
    lo_list_[1] = -1;
    hi_list_[0] = 0;
    hi_list_[1] = 0;

    for (int t = static_cast<int>(level_first_list_.size()) - 2; t >= 0; --t) {
        head = 0;
        for (k = level_first_list_[t]; k < level_first_list_[t + 1]; ++k) {
            q = lo_list_[k];
            if (lo_list_[q] >= 0) {
                lo_list_[k] = lo_list_[q];
            }
            q = hi_list_[k];
            if (lo_list_[q] >= 0) {
                q = lo_list_[q];
                hi_list_[k] = q;
            }
            if (q != 0) {
                if (hi_list_[q] >= 0) {
                    hi_list_[k] = -head;
                    head = q;
                } else {
                    hi_list_[k] = -hi_list_[q];
                }
                hi_list_[q] = -k;
            }
        }

        for (p = head; p != 0; p = -q) {
            for (q = -hi_list_[p]; q > 0; q = hi_list_[q]) {
                r = lo_list_[q];
                if (lo_list_[r] <= 0) {
                    //printf("%llx: (~%d?%llx:%llx)\n", q, t + 1, r, p);
                    node_parent_list.push_back(q);
                    reduced_lo_list.push_back(r);
                    reduced_hi_list.push_back(p);
                    reduced_level_list[t] = q;
                    lo_list_[r] = q;
                    lo_list_[q] = -r - 1;
                } else {
                    lo_list_[q] = lo_list_[r];
                }
            }
            for (q = -hi_list_[p], hi_list_[p] = 0; q > 0; r = q, q = hi_list_[r]) {
                r = lo_list_[q];
                if (r < 0) {
                    lo_list_[-r - 1] = -1;
                }
            }
            hi_list_[r] = 0;
        }
    }
    // end Knuth's code

    map<intx, intx> node_map;
    node_map.insert(map<intx, intx>::value_type(0, 0));
    node_map.insert(map<intx, intx>::value_type(1, 1));
    intx n = static_cast<intx>(reduced_lo_list.size());
    for (intx i = n - 1; i >= 0; --i) {
        node_map.insert(map<intx, intx>::value_type(node_parent_list[i], n - i + 1));
    }
    for (intx i = n - 1; i >= 0; --i) {
        //printf("%x, %x, %x\n", node_map[node_parent_list[i]], node_map[reduced_lo_list[i]], node_map[reduced_hi_list[i]]);
        lo_list_[node_map[node_parent_list[i]]] = node_map[reduced_lo_list[i]];
        hi_list_[node_map[node_parent_list[i]]] = node_map[reduced_hi_list[i]];
    }
    lo_list_.resize(reduced_lo_list.size() + 2);
    hi_list_.resize(reduced_hi_list.size() + 2);

    level_first_list_.back() = static_cast<intx>(lo_list_.size());

    for (int i = static_cast<int>(reduced_level_list.size()) - 2; i >= 0; --i) {
        if (reduced_level_list[i] >= 0) {
            level_first_list_[i] = node_map[reduced_level_list[i]];
        } else {
            level_first_list_[i] = level_first_list_[i + 1];
        }
    }
}

// I use FILE* pointer instead of cout for efficiency.
void PseudoZDD::OutputZDD(FILE* fp, bool is_hex)
{
    if (is_hex) {
        for (unsigned int i = 0; i < level_first_list_.size() - 1; ++i) {
            fprintf(fp, "#%d:\n", i + 1);
            for (intx j = level_first_list_[i]; j < level_first_list_[i + 1]; ++j) {
                fprintf(fp, PERCENT_X ":" PERCENT_X "," PERCENT_X "\n",
                        j, lo_list_[j], hi_list_[j]);
            }
        }
    } else {
        for (unsigned int i = 0; i < level_first_list_.size() - 1; ++i) {
            fprintf(fp, "#%d:\n", i + 1);
            for (intx j = level_first_list_[i]; j < level_first_list_[i + 1]; ++j) {
                fprintf(fp, PERCENT_D ":" PERCENT_D "," PERCENT_D "\n",
                        j, lo_list_[j], hi_list_[j]);
            }
        }
    }
}

void PseudoZDD::OutputZDDForGraphviz(ostream& ost, bool is_print_zero)
{
    ost << "digraph zdd {" << endl;
    for (unsigned int i = 0; i < level_first_list_.size() - 1; ++i) {
        for (intx j = level_first_list_[i]; j < level_first_list_[i + 1]; ++j) {
            ost << "\tn" << j << " [label = \"" << (i + 1) << ", " << j << "\"];" << endl;
            if (is_print_zero || lo_list_[j] != 0) {
                ost << "\tn" << j << " -> n" << lo_list_[j] << " [style = dashed];" << endl;
            }
            if (is_print_zero || hi_list_[j] != 0) {
                ost << "\tn" << j << " -> n" << hi_list_[j] << ";" << endl;
            }
        }
        ost << "\t{rank = same;";
        for (intx j = level_first_list_[i]; j < level_first_list_[i + 1]; ++j) {
            ost << " n" << j << ";";
        }
        ost << "}" << endl;
    }
    if (is_print_zero) {
        ost << "\tn0 [shape = box, label = \"0\"];" << endl;
    }
    ost << "\tn1 [shape = box, label = \"1\"];" << endl;
    ost << "\t{ rank = same;";
    if (is_print_zero) {
        ost << " n0;";
    }
    ost << " n1 }" << endl;
    ost << "}" << endl;
}

void PseudoZDD::OutputZDDForSapporoBDD(ostream& ost)
{
    vector<bool> negative_list;
    negative_list.resize(lo_list_.size());

    negative_list[0] = false;
    negative_list[1] = true;

    int n = level_first_list_.size() - 1;

    ost << "_i " << n << endl;
    ost << "_o 1" << endl;
    ost << "_n " << (lo_list_.size() - 2) << endl; // minus 2 for 0/1-terminal

    for (int i = static_cast<int>(level_first_list_.size()) - 2; i >= 0; --i) {
        for (unsigned int j = level_first_list_[i]; j < level_first_list_[i + 1]; ++j) {
            negative_list[j] = negative_list[lo_list_[j]];
            ost << (j * 2) << " " << (n - i) << " ";
            if (lo_list_[j] <= 1) {
                ost << "F";
            } else {
                ost << (lo_list_[j] * 2);
            }
            ost << " ";
            if (hi_list_[j] == 1) {
                ost << "T";
            } else if (negative_list[hi_list_[j]]) {
                ost << (hi_list_[j] * 2 + 1);
            } else {
                ost << (hi_list_[j] * 2);
            }
            ost << endl;
        }
    }
    ost << (negative_list[2] ? "5" : "4") << endl;
}

// OutputAllSolutions の中で呼ばれる
/* private */void PseudoZDD::OutputElementRecursively(intx id, vector<int>* vec, FILE* fp)
{
    if (id == 0) {
        return;
    }
    if (id == 1) {
        for (unsigned int i = 0; i < vec->size(); ++i) {
            fprintf(fp, "%d", (*vec)[i]);
            if (i < vec->size() - 1) {
                fprintf(fp, " ");
            }
        }
        fprintf(fp, "\n");
        return;
    } else {
        int top = 0;

        for (unsigned int i = 0; i < level_first_list_.size() - 1; ++i) {
            if (level_first_list_[i] <= id && id < level_first_list_[i + 1]) {
                top = i + 1;
                break;
            }
        }

        vec->push_back(top);
        OutputElementRecursively(hi_list_[id], vec, fp);
        vec->pop_back();

        OutputElementRecursively(lo_list_[id], vec, fp);
    }
}

// 全解を出力
void PseudoZDD::OutputAllSolutions(FILE* fp)
{
    vector<int> vec;
    OutputElementRecursively(2, &vec, fp); // 2 is the first id of the zdd root node.
}

// 一様ランダムサンプリングを sample_num 回行う
void PseudoZDD::OutputSamplingSolutions(FILE* fp, int sample_num)
{
    for (int i = 0; i < sample_num; ++i) {
        vector<int> vec;
        SampleUniformlyRandomly(&vec);
        for (unsigned int j = 0; j < vec.size(); ++j) {
            fprintf(fp, "%d", vec[j]);
            if (j < vec.size() - 1) {
                fprintf(fp, " ");
            }
        }
        fprintf(fp, "\n");
    }
}

intx PseudoZDD::GetNumberOfNodes()
{
    return static_cast<intx>(lo_list_.size());
}

BigInteger PseudoZDD::ComputeNumberOfSolutions()
{
    sol_list_.resize(lo_list_.size());
    sol_list_[0] = 0;
    sol_list_[1] = 1;

    for (intx i = static_cast<intx>(sol_list_.size()) - 1; i >= 2; --i) {
        sol_list_[i] = sol_list_[lo_list_[i]] + sol_list_[hi_list_[i]];
    }

    return sol_list_[2];
}

// 引数に与えるリストはソートされていなければならない
bool PseudoZDD::Judge(int n, ...)
{
    va_list ap;
    va_start(ap, n);

    vector<int> v_list;

    for (int i = 0; i < n; ++i) {
        v_list.push_back(va_arg(ap, int));
    }

    va_end(ap);

    return Judge(v_list);
}

// sequence に与えるリストはソートされていなければならない
bool PseudoZDD::Judge(const vector<int>& sequence)
{
    int current_level = 0;
    intx current_node = 2;
    unsigned int seq_pos = 0;

    while (seq_pos < sequence.size() && current_node >= 2) {
        if (current_level <= sequence[seq_pos]) {
            if (current_level == sequence[seq_pos]) { // match
                current_node = hi_list_[current_node];
                ++seq_pos;
            } else { // not match
                current_node = lo_list_[current_node];
            }
            while (current_level < static_cast<int>(level_first_list_.size()) - 1) {
                if (current_node < level_first_list_[current_level + 1]) {
                    break;
                }
                ++current_level;
            }
        } else { // current_level > sequence[seq_pos]
            return false;
        }
    }
    while (current_node >= 2) {
        current_node = lo_list_[current_node];
    }
    return current_node == 1;
}

static double Divide(BigInteger nume, BigInteger deno)
{
#if USE_APFLOAT
    apfloat num = apfloat(nume);
    apfloat den = apfloat(deno);
    num.prec(10);
    den.prec(10);
    apfloat probap = num / den;
    return ap2double(probap.ap);
#else
    return static_cast<double>(nume) / static_cast<double>(deno);
#endif
}

// need to be called ComputeNumberOfSolutions method before this method is called
void PseudoZDD::SampleUniformlyRandomly(vector<int>* result)
{
    intx current_node = 2;
    while (current_node >= 2) {
        bool is_hi = false;
        BigInteger lo = sol_list_[lo_list_[current_node]];
        BigInteger hi = sol_list_[hi_list_[current_node]];
        if (lo == 0) {
            is_hi = true;
        } else if (hi == 0) {
            is_hi = false;
        } else {
            BigInteger sum = lo + hi;
            double prob = Divide(lo, sum);
            double ra = static_cast<double>(rand()) / RAND_MAX;
            if (ra < prob) {
                is_hi = false;
            } else {
                is_hi = true;
            }
        }
        if (is_hi) {
            for (unsigned int i = 0; i < level_first_list_.size(); ++i) {
                if (level_first_list_[i] <= current_node && current_node < level_first_list_[i + 1]) {
                    result->push_back(i + 1);
                    break;
                }
            }
            current_node = hi_list_[current_node];
        } else {
            current_node = lo_list_[current_node];
        }
    }
}

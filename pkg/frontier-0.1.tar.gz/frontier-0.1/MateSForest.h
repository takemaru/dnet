#ifndef MATESFOREST_H
#define MATESFOREST_H

#include "PseudoZDD.h"

//*************************************************************************************************
// StateSForest: アルゴリズム動作時の「状態」を表すクラス
class StateSForest : public State {
public:
    StateSForest(Graph* graph);
    Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateSForest: mate を表すクラス
class MateSForest : public Mate {
protected:
    mate_t* mate_;
public:
    MateSForest(State* state);
    ~MateSForest();
    virtual void Initialize(State* state);
    virtual void Copy(Mate* mate, State* state);
    virtual bool Equals(Mate* mate, State* state);
    virtual uintx GetHashValue(State* state);

    virtual void UpdateMate(State* state, int lo_or_hi);
    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
    virtual int CheckTerminateAfter(State* state);
};

#endif // MATESFOREST_H

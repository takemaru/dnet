#ifndef GRAPH_H
#define GRAPH_H

#include <vector>
#include <iostream>
#include <sstream>

//*************************************************************************************************
// Edge: グラフの枝を表すクラス
struct Edge {
public:
    int src;
    int dest;
    Edge(int src, int dest);
};

//*************************************************************************************************
// Graph: グラフを表すクラス
class Graph {
private:
    int number_of_vertices_;
    std::vector<Edge> edge_list_;
public:
    void Load(std::istream& ist);
    void LoadDirected(std::istream& ist);
    void LoadC(std::istream& ist);
    std::vector<Edge>* GetEdgeList();
    int GetVertexSize();
    void RearrangeByBreadthFirst(int start_vertex);
    void AddDummyVertex();
    void Print(std::ostream& ost);
    void PrintC(std::ostream& ost);
    void PrintForGraphviz(std::ostream& ost);
};

#endif // GRAPH_H

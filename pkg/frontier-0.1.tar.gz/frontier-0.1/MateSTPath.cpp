#include "MateSTPath.h"
#include <cstring>

using namespace std;

//*************************************************************************************************
// StateSTPath
StateSTPath::StateSTPath(Graph* graph) : State(graph)
{
    // nothing
}

Mate* StateSTPath::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSTPath(NULL);
    } else {
        return new MateSTPath(this);
    }
}

int StateSTPath::GetStartVertex()
{
    return start_vertex_;
}

int StateSTPath::GetEndVertex()
{
    return end_vertex_;
}

void StateSTPath::SetStartAndEndVertex(int start_vertex, int end_vertex)
{
    start_vertex_ = start_vertex;
    end_vertex_ = end_vertex;
}

bool StateSTPath::IsHamilton()
{
    return is_hamilton_;
}

void StateSTPath::SetHamilton(bool is_hamilton)
{
    is_hamilton_ = is_hamilton;
}

bool StateSTPath::IsCycle()
{
    return is_cycle_;
}

void StateSTPath::SetCycle(bool is_cycle)
{
    is_cycle_ = is_cycle;
}

//*************************************************************************************************
// MateSTPath
MateSTPath::MateSTPath(State* state)
{
    if (state != NULL) {
        mate_ = new mate_t[state->NUMBER_OF_VERTICES + 1];
    } else {
        mate_ = NULL;
    }
}

MateSTPath::~MateSTPath()
{
    if (mate_ != NULL) {
        delete[] mate_;
    }
}

// mate を初期化する（初期ZDDノード専用）
void MateSTPath::Initialize(State* state)
{
    StateSTPath* st = static_cast<StateSTPath*>(state);
    int sv = st->GetStartVertex();
    int ev = st->GetEndVertex();

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = i;
    }
    if (!st->IsCycle()) { // パス列挙の場合
        mate_[sv] = ev;
        mate_[ev] = sv;
    }
}

// 引数で与えた mate を自身にコピーする
void MateSTPath::Copy(Mate* mate, State* state)
{
    MateSTPath* m = static_cast<MateSTPath*>(mate);

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = m->mate_[i];
    }
}

// mate が「等価」かどうか判定する
bool MateSTPath::Equals(Mate* mate, State* state)
{
    MateSTPath* m = static_cast<MateSTPath*>(mate);

    // フロンティアに含まれる各頂点についてmate値が同じかどうか判定
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        mate_t v = *itor;
        if (mate_[v] != m->mate_[v]) {
            return false;
        }
        ++itor;
    }
    return true;
}

// ハッシュ値を取得
uintx MateSTPath::GetHashValue(State* state)
{
    uintx hash_value = 0;
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        hash_value = hash_value * 15284356289ll + mate_[*itor];
        ++itor;
    }
    return hash_value;
}

void MateSTPath::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理のときのみ更新
        int sm = mate_[edge.src];
        int dm = mate_[edge.dest];

        // 枝をつないだときの mate の更新
        // （↓の計算順を変更すると正しく動作しないことに注意）
        mate_[edge.src] = 0;
        mate_[edge.dest] = 0;
        mate_[sm] = dm;
        mate_[dm] = sm;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSTPath::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        return -1;
    } else {
        Edge edge = state->GetCurrentEdge();

        if (mate_[edge.src] == 0 || mate_[edge.dest] == 0) { // 分岐が発生した
            return 0;
        } else if (mate_[edge.src] == edge.dest) { // サイクルが完成した
            StateSTPath* st = static_cast<StateSTPath*>(state);            
            // フロンティアに属する残りの頂点についてチェック
            set<int>::iterator itor = state->GetFrontierIterator();
            while (itor != state->GetFrontierEnd()) {
                mate_t v = *itor;
                // 張った枝の始点と終点はチェックから除外
                if (v != edge.src && v != edge.dest) {
                    if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                        if (mate_[v] != 0) {
                            return 0;
                        }
                    } else {
                        // パスの途中でなく、孤立した点でもない場合、
                        // 不完全なパスができることになるので、0を返す
                        if (mate_[v] != 0 && mate_[v] != v) {
                            return 0;
                        }
                    }
                }
                ++itor;
            }
            if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                if (st->IsExistUnprocessedVertex()) {
                    return 0;
                }
            }
            return 1;
        } else {
            return -1;
        }
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateSTPath::CheckTerminateAfter(State* state)
{
    StateSTPath* st = static_cast<StateSTPath*>(state);

    set<int>::iterator itor = state->GetLeavingIterator();
    while (itor != state->GetLeavingEnd()) {
        mate_t v = *itor;
        if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
            if (mate_[v] != 0) {
                return 0;
            }
        } else {
            if (mate_[v] != 0 && mate_[v] != v) {
                return 0;
            }
        }
        ++itor;
    }
    if (state->GetCurrentEdgeNumber() >= state->GetNumberOfEdges() - 1) { // last
        return 0;
    } else {
        return -1;
    }
}

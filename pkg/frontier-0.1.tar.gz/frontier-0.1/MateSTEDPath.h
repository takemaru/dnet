#ifndef MATESTEDPATH_H
#define MATESTEDPATH_H

#include "State.h"

//*************************************************************************************************
// StateSTEDPath: アルゴリズム動作時の「状態」を表すクラス
class StateSTEDPath : public State {
protected:
    int start_vertex_;
    int end_vertex_;
    bool is_hamilton_;
    bool is_cycle_;

public:
    StateSTEDPath(Graph* graph);
    Mate* CreateMate(bool is_terminal);

    int GetStartVertex();
    int GetEndVertex();
    void SetStartAndEndVertex(int start_vertex, int end_vertex);
    bool IsHamilton();
    void SetHamilton(bool is_hamilton);
    bool IsCycle();
    void SetCycle(bool is_cycle);
};

//*************************************************************************************************
// MateSTEDPath: mate を表すクラス
class MateSTEDPath : public Mate {
protected:
    mate_t* mate_degree_;
    mate_t* mate_connection_;
public:
    MateSTEDPath(State* state);
    virtual ~MateSTEDPath();
    virtual void Initialize(State* state);
    virtual void Copy(Mate* mate, State* state);
    virtual bool Equals(Mate* mate, State* state);
    virtual uintx GetHashValue(State* state);

    virtual void UpdateMate(State* state, int lo_or_hi);
    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
    virtual int CheckTerminateAfter(State* state);
};

#endif // MATESTEDPATH_H

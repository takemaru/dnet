#ifndef HYPERGRAPH_H
#define HYPERGRAPH_H

#include <vector>
#include <iostream>
#include <sstream>

//*************************************************************************************************
// Edge: グラフの枝を表すクラス
struct HyperEdge {
public:
    std::vector<bool> var_list;
};

//*************************************************************************************************
// Graph: グラフを表すクラス
class HyperGraph {
private:
    int number_of_vertices_;
    std::vector<HyperEdge> edge_list_;
public:
    HyperGraph();
    void Load(std::istream& ist);
    void LoadC(std::istream& ist);
    void Print();
    std::vector<HyperEdge>* GetEdgeList();
    int GetVertexSize();
};

#endif // HYPERGRAPH_H

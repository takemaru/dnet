#include "MateSTree.h"

using namespace std;

//*************************************************************************************************
// StateSTree
StateSTree::StateSTree(Graph* graph) : State(graph)
{
    // nothing
}

Mate* StateSTree::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSTree(NULL);
    } else {
        return new MateSTree(this);
    }
}

//*************************************************************************************************
// MateSTree
MateSTree::MateSTree(State* state) : MateSForest(state)
{
    // nothing
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateSTree::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        Edge edge = state->GetCurrentEdge();
        if (mate_[edge.src] == mate_[edge.dest]) {
            return 1;
        } else {
            return 0;
        }
    } else {
        set<int>::iterator itor_l = state->GetLeavingIterator();
        while (itor_l != state->GetLeavingEnd()) {
            int m = mate_[*itor_l];
            bool is_exist = false;
            set<int>::iterator itor_f = state->GetFrontierIterator();
            while (itor_f != state->GetFrontierEnd()) {
                if (m == mate_[*itor_f]) {
                    is_exist = true;
                    break;
                }
                ++itor_f;
            }
            if (!is_exist) {
                return 0;
            }
            ++itor_l;
        }
        return -1;
    }
}

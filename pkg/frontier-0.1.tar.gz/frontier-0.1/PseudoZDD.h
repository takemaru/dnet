#ifndef FRONTIER_H
#define FRONTIER_H

#include <vector>
#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <iostream>
#include <fstream>
//#include <boost/pool/pool.hpp>
//#include <boost/pool/object_pool.hpp>

#ifdef USE_APFLOAT
#include <apfloat/ap.h>
#include <apfloat/apint.h>
#include <apfloat/apfloat.h>
#endif

#include "State.h"

//#undef BIT64

typedef long long int int64;
typedef unsigned long long int uint64;
typedef unsigned short ushort;

#ifdef BIT64
typedef int64 intx;
typedef uint64 uintx;
#else
typedef int intx;
typedef unsigned int uintx;
#endif

#ifdef USE_APFLOAT
typedef apint BigInteger;
#else
typedef intx BigInteger;
#endif

const intx HASH_SIZE = (1ll << 24);

//*************************************************************************************************
// ZDDNode: ZDDのノードを表すクラス
class ZDDNode {
private:
    intx id_; // ノード固有の数字
    Mate* mate_;

    static std::vector<ZDDNode*> reuse_node_list_;

private:
    ZDDNode(State* state, bool is_terminal);
public:
    ~ZDDNode();

    static ZDDNode* ZeroNode; // 0終端
    static ZDDNode* OneNode; // 1終端

    ZDDNode* Clone(State* state);
    intx GetId();
    void SetId(intx id);
    bool Equals(ZDDNode* node, State* state);
    uintx GetHashValue(State* state);

    void UpdateMate(State* state, int lo_or_hi);
    int CheckTerminateBefore(State* state, int lo_or_hi);
    int CheckTerminateAfter(State* state);

    static ZDDNode* MakeInitialNode(State* state);
    static void Initialize(State* state);
    static void Finalize();
    static void ClearReuseNodeList();
    inline static void DestructNode(ZDDNode* node);
};

//*************************************************************************************************
// Hash: Hashを表すクラス
// 内部ハッシュ法により実装している。
// ZDDNodeSetクラスからの使用を想定している。
// time の値を指定することによって、同じtimeの値をもつエントリのみを検索する。
// これを使用することで、ハッシュテーブルをクリアする（0で埋める）ことなく次回に使用できる。
class Hash {
private:
    mate_t* hash_time_table_;
    intx* hash_table_;
    intx size_;
public:
    Hash(intx size);
    ~Hash();
    void Expand();
    intx GetSize();
    void Set(uintx hash_value, mate_t time, intx value);
    friend class ZDDNodeSet;
private:
    void Initialize();
    void Deinitialize();
};

//*************************************************************************************************
// ZDDNodeSet: ZDDのノードの集合を表すクラス
class ZDDNodeSet {
private:
    std::vector<ZDDNode*> node_list_;
    Hash* global_hash_;
public:
    ZDDNodeSet(Hash* global_hash);
    intx GetSize();
    ZDDNode* Get(intx index);
    intx Find(ZDDNode* node, State* state);
    void Add(ZDDNode* node, State* state);
    void DeleteClear();
    void Clear();
};

//*************************************************************************************************
// PseudoZDD: 構築する（既約とは限らない）ZDDを表すクラス。
// このクラスの Construct メンバ関数を呼び出すことで、アルゴリズムが開始して、
// ZDDが構築される。
class PseudoZDD {
private:
    std::vector<ZDDNodeSet*> zdd_node_set_list_;
    std::vector<intx> level_first_list_;
    std::vector<intx> lo_list_;
    std::vector<intx> hi_list_;
    std::vector<BigInteger> sol_list_;

public:
    ~PseudoZDD();
    ZDDNodeSet* GetZDDNodeSet(int index);
    int GetHeight();
    std::vector<intx>* GetLoNodeList();
    std::vector<intx>* GetHiNodeList();
    std::vector<intx>* GetLevelFirstList();
    void Construct(State* state);
    void Reduce();
    void OutputZDD(FILE* /*fp*/, bool is_hex);
    void OutputZDDForGraphviz(std::ostream& ost, bool is_print_zero);
    void OutputZDDForSapporoBDD(std::ostream& ost);
    void OutputAllSolutions(FILE* /*fp*/);
    void OutputSamplingSolutions(FILE* /*fp*/, int sample_num);
    intx GetNumberOfNodes();
    BigInteger ComputeNumberOfSolutions();
    // 引数に与えるリストはソートされていなければならない
    bool Judge(int n, ...);
    bool Judge(const std::vector<int>& sequence);
    void SampleUniformlyRandomly(std::vector<int>* result);

private:
    void OutputElementRecursively(intx id, std::vector<int>* vec, FILE* fp);
    ZDDNode* MakeChildNode(ZDDNode* node, State* state, int lo_or_hi);
    void SetChildNode(intx lo_node, intx hi_node);
};

#endif // FRONTIER_H

#ifndef MATESETPARTITION_H
#define MATESETPARTITION_H

#include "StateHyper.h"
#include "PseudoZDD.h"

//*************************************************************************************************
// StateSetPartition: アルゴリズム動作時の「状態」を表すクラス
class StateSetPartition : public StateHyper {
public:
    StateSetPartition(HyperGraph* graph);
    virtual Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateSetPartition: mate を表すクラス
class MateSetPartition : public Mate {
protected:
    uintx* mate_;

    int GetMateBit(int pos);
    void SetMateBit(int pos, int v);
public:
    MateSetPartition(State* state);
    virtual ~MateSetPartition();
    virtual void Initialize(State* state);
    virtual void Copy(Mate* mate, State* state);
    virtual bool Equals(Mate* mate, State* state);
    virtual uintx GetHashValue(State* state);

    virtual void UpdateMate(State* state, int lo_or_hi);
    virtual int CheckTerminateBefore(State* state, int lo_or_hi);
    virtual int CheckTerminateAfter(State* state);
};

#endif // MATESETPARTITION_H

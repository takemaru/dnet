 /***************************************
 * BDD+ Manipulator (SAPPORO-1.40)      *
 * (Basic methods)                      *
 * (C) Shin-ichi MINATO (May 1, 2011)   *
 ****************************************/

#include "BDD.h"

#define BDD_CPP
#include "bddc.h"

static const char BC_Smooth = 60;
static const char BC_Spread = 61;

extern "C"
{
  int rand();
};

/* Public Operations */
extern "C"
{
  /***************** Init. and config. ****************/
  extern int    bddinit B_ARG((bddp initsize, bddp limitsize));
  extern bddvar bddnewvar B_ARG((void));
  extern bddvar bddnewvaroflev B_ARG((bddvar lev));
  extern bddvar bddlevofvar B_ARG((bddvar v));
  extern bddvar bddvaroflev B_ARG((bddvar lev));
  extern bddvar bddvarused B_ARG((void));

  /************** Basic logic operations *************/
  extern bddp   bddprime B_ARG((bddvar v));
  extern bddvar bddtop B_ARG((bddp f));
  extern bddp   bddcopy B_ARG((bddp f));
  extern bddp   bddnot B_ARG((bddp f));
  extern bddp   bddand B_ARG((bddp f, bddp g));
  extern bddp   bddor B_ARG((bddp f, bddp g));
  extern bddp   bddxor B_ARG((bddp f, bddp g));
  extern bddp   bddnand B_ARG((bddp f, bddp g));
  extern bddp   bddnor B_ARG((bddp f, bddp g));
  extern bddp   bddxnor B_ARG((bddp f, bddp g));
  extern bddp   bddat0 B_ARG((bddp f, bddvar v));
  extern bddp   bddat1 B_ARG((bddp f, bddvar v));
  
  /********** Memory management and observation ***********/
  extern void   bddfree B_ARG((bddp f));
  extern bddp   bddused B_ARG((void));
  extern int    bddgc B_ARG((void));
  extern bddp   bddsize B_ARG((bddp f));
  extern bddp   bddvsize B_ARG((bddp *p, int lim));
  extern void   bddexport B_ARG((FILE *strm, bddp *p, int lim));
  extern int    bddimport B_ARG((FILE *strm, bddp *p, int lim));
  extern int    bddimportz B_ARG((FILE *strm, bddp *p, int lim));
  extern void   bddgraph B_ARG((bddp f));
  extern void   bddgraph0 B_ARG((bddp f));
  extern void   bddvgraph B_ARG((bddp *p, int lim));
  extern void   bddvgraph0 B_ARG((bddp *p, int lim));
  
  /************** Advanced logic operations *************/
  extern bddp   bddlshift B_ARG((bddp f, bddvar shift));
  extern bddp   bddrshift B_ARG((bddp f, bddvar shift));
  extern bddp   bddsupport B_ARG((bddp f));
  extern bddp   bdduniv B_ARG((bddp f, bddp g));
  extern bddp   bddexist B_ARG((bddp f, bddp g));
  extern bddp   bddcofactor B_ARG((bddp f, bddp g));
  extern bddp   bddimply B_ARG((bddp f, bddp g));
  extern bddp   bddrcache B_ARG((unsigned char op, bddp f, bddp g));
  extern void   bddwcache
                B_ARG((unsigned char op, bddp f, bddp g, bddp h));

  /************** ZBDD operations *************/
  extern bddp   bddoffset B_ARG((bddp f, bddvar v));
  extern bddp   bddonset B_ARG((bddp f, bddvar v));
  extern bddp   bddonset0 B_ARG((bddp f, bddvar v));
  extern bddp   bddchange B_ARG((bddp f, bddvar v));
  extern bddp   bddintersec B_ARG((bddp f, bddp g));
  extern bddp   bddunion B_ARG((bddp f, bddp g));
  extern bddp   bddsubtract B_ARG((bddp f, bddp g));
  extern bddp   bddcard B_ARG((bddp f));
  extern bddp   bddlit B_ARG((bddp f));
}

//--- SBDD class for default initialization ----

class SBDD
{
public:
  int BDDV_Active;
  SBDD(bddword init, bddword limit) { bddinit(init, limit); }
};
static SBDD BDD_Manager((bddword)256, (bddword)1024);


//----- External constant data for BDD -------

const bddword BDD_MaxNode = B_VAL_MASK >> 1U;
const int BDD_MaxVar = bddvarmax;

//----- External constant data for BDD Vector -------

const int BDDV_SysVarTop = 20;
const int BDDV_MaxLen = 1 << BDDV_SysVarTop;
const int BDDV_MaxLenImport = 1000;

//----- External functions for BDD -------


void BDD_Init(bddword init, bddword limit)
{
  bddinit(init, limit);
  BDD_Manager.BDDV_Active = 0;
}
	
int BDD_NewVar(void)
{
  return bddnewvaroflev(BDD_TopLev() + 1);
}
	
int BDD_NewVarOfLev(int lev)
{
  if(lev > BDD_TopLev() + 1)
    BDDerr("BDD_NewVarOfLev:Invald lev ", (bddword)lev);
  return bddnewvaroflev(lev);
}
	
int BDD_LevOfVar(int v) { return bddlevofvar(v); }
	
int BDD_VarOfLev(int lev) { return bddvaroflev(lev); }
	
int BDD_VarUsed(void) { return bddvarused(); }

int BDD_TopLev(void)
{
  if(BDD_Manager.BDDV_Active) return bddvarused() - BDDV_SysVarTop;
  return bddvarused();
}

bddword BDD_Used(void) { return bddused(); }

void BDD_GC() { bddgc(); }

bddword BDD_CacheInt(unsigned char op, bddword f, bddword g)
{
  return bddrcache(op, f, g);
}

BDD BDD_CacheBDD(unsigned char op, bddword f, bddword g)
{
  BDD h;
  h._bdd = bddcopy(bddrcache(op, f, g));
  return h;
}

void BDD_CacheEnt(unsigned char op, bddword f, bddword g, bddword h)
{
  bddwcache(op, f, g, h);
}

#define BDD_CACHE_CHK_RETURN(op, fx, gx) \
  { BDD h; h._bdd = bddcopy(bddrcache(op, fx, gx)); \
    if(h != -1) return h; \
    BDD_RECUR_INC; }

#define BDD_CACHE_ENT_RETURN(op, fx, gx, h) \
  { BDD_RECUR_DEC; \
    if(h != -1) bddwcache(op, fx, gx, h.GetID()); \
    return h; }

BDD BDD_ID(bddword bdd)
{
  BDD h;
  h._bdd = bddcopy(bdd);
  return h;
}

//----- External functions for BDD Vector -------

void BDDV_Init(bddword init, bddword limit)
{
  bddinit(init, limit);
  for(int i=0; i<BDDV_SysVarTop; i++) bddnewvar();
  BDD_Manager.BDDV_Active = 1;
}
	
int BDDV_UserTopLev(void) { return BDD_TopLev(); }
int BDDV_NewVar(void) { return BDD_NewVar(); }
int BDDV_NewVarOfLev(int lev) { return BDD_NewVarOfLev(lev); }

//-------------- class BDD --------------------

BDD::BDD(){ _bdd = bddfalse; }

BDD::BDD(int val)
{
  if(val == 0) _bdd = bddfalse;
  else if(val > 0) _bdd = bddtrue;
  else _bdd = bddnull;
}

BDD::BDD(const BDD& f){ _bdd = bddcopy(f._bdd); }

BDD BDD::create_from_bddp(bddword bdd)
{
  BDD h;
  h._bdd = bddcopy(bdd);
  return h;
}

BDD::~BDD(){ bddfree(_bdd); }

BDD& BDD::operator=(const BDD& f)
{
  if(_bdd != f._bdd)
  {
  	bddfree(_bdd);
  	_bdd = bddcopy(f._bdd);
  }
  return *this;

}

BDD BDD::operator&=(const BDD& f) { return *this = *this & f; }
BDD BDD::operator|=(const BDD& f) { return *this = *this | f; }
BDD BDD::operator^=(const BDD& f) { return *this = *this ^ f; }
BDD BDD::operator<<=(int s) { return *this = *this << s; }
BDD BDD::operator>>=(int s) { return *this = *this >> s; }

BDD BDD::operator~()
{
  BDD h;
  h._bdd = bddnot(_bdd);
  return h;
}

BDD BDD::operator<<(int shift)
{
  BDD h;
  h._bdd = bddlshift(_bdd, shift);
  return h;
}

BDD BDD::operator>>(int shift)
{
  BDD h;
  h._bdd = bddrshift(_bdd, shift);
  return h;
}

BDD BDD::At0(int v)
{
  BDD h;
  h._bdd = bddat0(_bdd, v);
  return h;
}

BDD BDD::At1(int v)
{
  BDD h;
  h._bdd = bddat1(_bdd, v);
  return h;
}

BDD BDD::Cofact(BDD f)
{
  BDD h;
  h._bdd = bddcofactor(_bdd, f._bdd);
  return h;
}

BDD BDD::Univ(BDD f)
{
  BDD h;
  h._bdd = bdduniv(_bdd, f._bdd);
  return h;
}

BDD BDD::Exist(BDD f)
{
  BDD h;
  h._bdd = bddexist(_bdd, f._bdd);
  return h;
}

BDD BDD::Support()
{
  BDD h;
  h._bdd = bddsupport(_bdd);
  return h;
}

int BDD::Top() const { return bddtop(_bdd); }
bddword BDD::Size() const { return bddsize(_bdd); }

void BDD::Export(FILE *strm) { bddexport(strm, &_bdd, 1); }

bddword BDD::GetID(void) const { return _bdd; }

BDD BDDvar(int v)
{
  BDD h;
  h._bdd = bddprime(v);
  return h;
}

BDD operator&(const BDD& f, const BDD& g)
{
	BDD h;
	h._bdd = bddand(f._bdd, g._bdd);
	return h;
}

BDD operator|(const BDD& f, const BDD& g)
{
	BDD h;
	h._bdd = bddor(f._bdd, g._bdd);
	return h;
}

BDD operator^(const BDD& f, const BDD& g)
{
	BDD h;
	h._bdd = bddxor(f._bdd, g._bdd);
	return h;
}

int operator==(const BDD& f, const BDD& g) { return f._bdd == g._bdd; }
int operator!=(const BDD& f, const BDD& g) { return !(f == g); }

int BDD_Imply(BDD f, BDD g){ return bddimply(f._bdd, g._bdd); }

BDD BDD_Import(FILE *strm)
{
	bddword bdd;
	if(bddimport(strm, &bdd, 1)) return -1;
	return BDD_ID(bdd);
}

void BDD::Print()
{
  cout << "[ " << GetID();
  cout << " Var:" << Top() << "(" << BDD_LevOfVar(Top()) << ")";
  cout << " Size:" << Size() << " ]\n";
  cout.flush();
}

BDD BDD::Swap(int v1, int v2)
{
  if(v1 == v2) return *this;
  BDD x = BDDvar(v1);
  BDD y = BDDvar(v2);
  BDD fx0 = At0(v1);
  BDD fx1 = At1(v1);
  return x & ( ~y & fx0.At1(v2) | y & fx1.At1(v2) ) |
        ~x & ( ~y & fx0.At0(v2) | y & fx1.At0(v2) );
}

BDD BDD::Smooth(int v)
{
  int t = Top();
  if(t == 0) return *this;
  if(BDD_LevOfVar(t) <= BDD_LevOfVar(v)) return 1;
  bddword fx = GetID();
  bddword gx = BDDvar(v).GetID();
  BDD_CACHE_CHK_RETURN(BC_Smooth, fx, gx);
  BDD x = BDDvar(t);
  BDD h = (~x & At0(t).Smooth(v))|(x & At1(t).Smooth(v));
  BDD_CACHE_ENT_RETURN(BC_Smooth, fx, gx, h);
}

BDD BDD::Spread(int k)
{
  int t = Top();
  if(t == 0) return *this;
  if(k == 0) return *this;
  if(k < 0) BDDerr("BDD::Spread: k < 0.",k);
  bddword fx = GetID();
  bddword gx = BDDvar(k).GetID();
  BDD_CACHE_CHK_RETURN(BC_Spread, fx, gx);
  BDD x = BDDvar(t);
  BDD f0 = At0(t);
  BDD f1 = At1(t);
  BDD h = (~x & f0.Spread(k)) | (x & f1.Spread(k))
    | (~x & f1.Spread(k-1)) | (x & f0.Spread(k-1));
  BDD_CACHE_ENT_RETURN(BC_Spread, fx, gx, h);
}

BDD BDD_Random(int level, int density)
{
  if(level < 0)
    BDDerr("BDD_Random: level < 0.",level);
  if(level == 0) return ((rand()%100) < density)? 1: 0;
  return (BDDvar(BDD_VarOfLev(level))
        & BDD_Random(level-1, density)) |
         (~BDDvar(BDD_VarOfLev(level))
        & BDD_Random(level-1, density));
}

void BDDerr(const char* msg)
{
  cerr << "<ERROR> " << msg << " \n";
  exit(1);
}

void BDDerr(const char* msg, bddword key)
{
  cerr << "<ERROR> " << msg << " (" << key << ")\n";
  exit(1);
}

void BDDerr(const char* msg, const char* name)
{
  cerr << "<ERROR> " << msg << " (" << name << ")\n";
  exit(1);
}

//--------------- class BDDV ------------------------

bddword BDDV::Size()
{
	bddword* bddv = new bddword[_len];
	for(int i=0; i<_len; i++) bddv[i] = GetBDD(i).GetID(); 
	bddword s = bddvsize(bddv, _len);
	delete[] bddv;
	return s;
}

void BDDV::Export(FILE *strm)
{
	bddword* bddv = new bddword[_len];
	for(int i=0; i<_len; i++) bddv[i] = GetBDD(i).GetID(); 
	bddexport(strm, bddv, _len);
	delete[] bddv;
}


BDDV::BDDV()
{
  _bdd = 0;
  _len = 0;
  _level = 0;
}

BDDV::BDDV(const BDDV& fv)
{
  _bdd = fv._bdd;
  _len = fv._len;
  _level = fv._level;
}

static int BDDV_GetLev(int);
static int BDDV_GetLev(int len)
{
  int lev = 0;
  for(len--; len>0; len>>=1) lev++;
  return lev;
}

BDDV::BDDV(const BDD& f, int len)
{
  if(len < 0) BDDerr("BDDV::BDDV: len < 0.", len);
  if(len > BDDV_MaxLen)
    BDDerr("BDDV::BDDV: Too large len.", len);
  int t = BDD(f).Top();
  if(t > 0 && BDD_LevOfVar(t) > BDD_TopLev())
    BDDerr("BDDV::BDDV: Invalid Top Var.", t);
  if(len == 0) _bdd = 0;
  else
    _bdd = f;
  if(f == -1)
  {
    _len = 1;
    _level = 0;
  }
  else
  {
    _len = len;
    _level = BDDV_GetLev(len);
  }
}

BDDV::~BDDV() { }

BDDV& BDDV::operator=(const BDDV& fv)
{
  _bdd = fv._bdd;
  _len = fv._len;
  _level = fv._level;
  return *this;
}

BDDV BDDV::operator&=(const BDDV& fv) { return *this = *this & fv; }
BDDV BDDV::operator|=(const BDDV& fv) { return *this = *this | fv; }
BDDV BDDV::operator^=(const BDDV& fv) { return *this = *this ^ fv; }
BDDV BDDV::operator<<=(int shift) { return *this = *this << shift; }
BDDV BDDV::operator>>=(int shift) { return *this = *this >> shift; }

BDDV BDDV::operator~()
{
  BDDV tmp;
  tmp._bdd = ~_bdd;
  tmp._len = _len;
  tmp._level = _level;
  return tmp;
}

BDDV BDDV::operator<<(int shift)
{
  BDDV tmp;
  if(Uniform() == 0) tmp = (Former() << shift) || (Latter() << shift);
  else
  {
    tmp._bdd = _bdd << shift;
    if(tmp._bdd == -1) tmp._len = 1;
    else
    {
      tmp._len = _len;
      tmp._level = _level;
    }
  }
  return tmp;
}

BDDV BDDV::operator>>(int shift)
{
  BDDV tmp;
  if(!Uniform())
    tmp = (Former() >> shift) || (Latter() >> shift);
  else
  {
    tmp._bdd = _bdd >> shift;
    if(tmp._bdd == -1) tmp._len = 1;
    else
    {
      tmp._len = _len;
      tmp._level = _level;
    }
  }
  return tmp;
}

BDDV BDDV::At0(int v)
{
  if(BDD_LevOfVar(v) > BDD_TopLev())
    BDDerr("BDDV::At0: Invalid VarID.", v);
  BDDV tmp;
  tmp._bdd = _bdd.At0(v);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = _len;
    tmp._level = _level;
  }
  return tmp;
}
BDDV BDDV::At1(int v)
{
  if(BDD_LevOfVar(v) > BDD_TopLev())
    BDDerr("BDDV::At1: Invalid VarID.", v);
  BDDV tmp;
  tmp._bdd = _bdd.At1(v);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = _len;
    tmp._level = _level;
  }
  return tmp;
}

BDDV BDDV::Cofact(BDDV v)
{
  if(*this == BDDV(-1)) return *this;
  if(v == BDDV(-1)) return v;
  if(_len != v._len)
    BDDerr("BDDV::Cofact: Mismatch of len.");
  if(_level > 0 && v._level > 0)
    return Former().Cofact(v.Former()) ||
           Latter().Cofact(v.Latter());
  BDDV tmp;
  tmp._bdd = _bdd.Cofact(v._bdd);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = _len;
    tmp._level = _level;
  }
  return tmp;
}

BDDV BDDV::Swap(int v1, int v2)
{
  if(BDD_LevOfVar(v1) > BDD_TopLev())
    BDDerr("BDDV::Swap: Invalid VarID.", v1);
  if(BDD_LevOfVar(v2) > BDD_TopLev())
    BDDerr("BDDV::Swap: Invalid VarID.", v2);
  BDDV tmp;
  tmp._bdd = _bdd.Swap(v1, v2);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = _len;
    tmp._level = _level;
  }
  return tmp;
}

int BDDV::Top()
{
  if(Uniform()) return _bdd.Top();
  int t0 = Former().Top();
  int t1 = Latter().Top();
  if(BDD_LevOfVar(t0) > BDD_LevOfVar(t1)) return t0;
  else return t1;
}

BDDV BDDV::Spread(int k)
{
  if(Uniform()) return _bdd.Spread(k);
  return Former().Spread(k) || Latter().Spread(k);
}

BDDV BDDV::Former()
{
  BDDV tmp;
  if(_len <= 1) return tmp;

  tmp._bdd = _bdd.At0(_level);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = 1 << (_level-1);
    tmp._level = _level-1;
  }
  return tmp;
}

BDDV BDDV::Latter()
{
  BDDV tmp;
  if(_len == 0) return tmp;
  if(_len == 1) return *this;

  tmp._bdd = _bdd.At1(_level);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = _len - (1 << (_level-1));
    tmp._level = BDDV_GetLev(tmp._len);
  }
  return tmp;
}

BDDV BDDV::Part(int start, int len)
{
  if(*this == BDDV(-1)) return *this;
  BDDV tmp;
  if(len == 0) return tmp;

  if(start < 0 || start + len  > _len)
    BDDerr("BDDV::Part: Illegal index.");
  
  if(start == 0 && len == _len) return *this;
  
  int half = 1 << (_level-1);
  
  if(start + len <= half)
    return Former().Part(start, len);
  if(start >= half)
    return Latter().Part(start - half, len);
  return Former().Part(start, half - start)
      || Latter().Part(0, start + len - half);
}

BDD BDDV::GetBDD(int index)
{
  if(*this == BDDV(-1)) return -1;
  if(index < 0 || index >= _len)
    BDDerr("BDDV::GetBDD: Illegal index.",index);
  if(_len == 1) return _bdd;
  BDD f = _bdd;
  for(int i=_level-1; i>=0; i--)
    if((index & (1<<i)) == 0)
      f = f.At0(i + 1);
    else f = f.At1(i + 1);
  return f;
}

BDD BDDV::GetMetaBDD(void) { return _bdd; }

int BDDV::Uniform(void)
{
  return (BDD_LevOfVar(_bdd.Top()) <= BDD_TopLev());
}

int BDDV::Len(void) { return _len; }

void BDDV::Print()
{
  for(int i=0; i<_len; i++)
  {
    cout << "f" << i << ": ";
    GetBDD(i).Print();
  }
  cout << "Size= " << Size() << "\n\n";
  cout.flush();
}

BDDV operator&(const BDDV& fv, const BDDV& gv)
{
  if(fv == BDDV(-1)) return fv;
  if(gv == BDDV(-1)) return gv;
  if(fv._len != gv._len)
    BDDerr("BDDV::operator&: Mismatch of len.");
  BDDV tmp;
  tmp._bdd = fv._bdd & gv._bdd;
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = fv._len;
    tmp._level = fv._level;
  }
  return tmp;
}

BDDV operator|(const BDDV& fv, const BDDV& gv)
{
  if(fv == BDDV(-1)) return fv;
  if(gv == BDDV(-1)) return gv;
  if(fv._len != gv._len)
    BDDerr("BDDV::operator|: Mismatch of len.");
  BDDV tmp;
  tmp._bdd = fv._bdd | gv._bdd;
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = fv._len;
    tmp._level = fv._level;
  }
  return tmp;
}

BDDV operator^(const BDDV& fv, const BDDV& gv)
{
  if(fv == BDDV(-1)) return fv;
  if(gv == BDDV(-1)) return gv;
  if(fv._len != gv._len)
    BDDerr("BDDV::operator^: Mismatch of len.");
  BDDV tmp;
  tmp._bdd = fv._bdd ^ gv._bdd;
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = fv._len;
    tmp._level = fv._level;
  }
  return tmp;
}

int operator==(const BDDV& fv, const BDDV& gv)
{
  return (fv._bdd == gv._bdd && fv._len == gv._len);
}
	
int operator!=(const BDDV& fv, const BDDV& gv) { return !(fv == gv); }

int BDDV_Imply(BDDV fv, BDDV gv)
{
  if(fv == BDDV(-1)) return 0;
  if(gv == BDDV(-1)) return 0;
  if(fv._len != gv._len)
    BDDerr("BDDV::operator==: Mismatch of len.");
  return BDD_Imply(fv._bdd, gv._bdd);
}

BDDV operator||(const BDDV& fv, const BDDV& gv)
{
  if(fv == BDDV(-1)) return fv;
  if(gv == BDDV(-1)) return gv;
  if(fv._len == 0) return gv;
  if(gv._len == 0) return fv;
  if(fv._len != (1 << fv._level))
    return BDDV(fv).Former() || (BDDV(fv).Latter() || gv);
  if(fv._len < gv._len)
    return (fv || BDDV(gv).Former()) || BDDV(gv).Latter();
  BDDV tmp;
  BDD x = BDDvar(fv._level + 1);
  tmp._bdd = (~x & fv._bdd)|(x & gv._bdd);
  if(tmp._bdd == -1) tmp._len = 1;
  else
  {
    tmp._len = fv._len + gv._len;
    if(tmp._len > BDDV_MaxLen)
    	BDDerr("BDDV::operatop||: Too large len.", tmp._len);
    tmp._level = fv._level + 1;
  }
  return tmp;
}

BDDV BDDV_Mask1(int index, int len)
{
  if(len < 0)
    BDDerr("BDDV_Mask1: len < 0.", len);
  if(index < 0 || index >= len)
    BDDerr("BDDV_Mask1: Illegal index.", index);
  return BDDV(0,index)||BDDV(1,1)||BDDV(0,len-index-1);
}

BDDV BDDV_Mask2(int index, int len)
{
  if(len < 0)
    BDDerr("BDDV_Mask2: len < 0.", len);
  if(index < 0 || index > len)
    BDDerr("BDDV_Mask2: Illegal index.", index);
  return BDDV(0,index)||BDDV(1,len-index);
}

#define IMPORTHASH(x) (((x >> 1) ^ (x >> 16)) & (hashsize - 1))

#ifdef B_64
#  define B_STRTOI strtoll
#else
#  define B_STRTOI strtol
#endif

BDDV BDDV_Import(FILE *strm)
{
  int inv, e;
  bddword hashsize;
  BDD f, f0, f1;
  char s[256];
  bddword *hash1;
  BDD *hash2;

  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  if(strcmp(s, "_i") != 0) return BDDV(-1);
  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  int n = strtol(s, NULL, 10);
  while(n > BDD_TopLev()) BDD_NewVar();

  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  if(strcmp(s, "_o") != 0) return BDDV(-1);
  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  int m = strtol(s, NULL, 10);

  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  if(strcmp(s, "_n") != 0) return BDDV(-1);
  if(fscanf(strm, "%s", &s) == EOF) return BDDV(-1);
  bddword n_nd = B_STRTOI(s, NULL, 10);

  for(hashsize = 1; hashsize < (n_nd<<1); hashsize <<= 1)
    ; /* empty */
  hash1 = new bddword[hashsize];
  if(hash1 == 0) return BDDV(-1);
  hash2 = new BDD[hashsize];
  if(hash2 == 0) { delete[] hash1; return BDDV(-1); }
  for(bddword ix=0; ix<hashsize; ix++)
  {
    hash1[ix] = B_VAL_MASK;
    hash2[ix] = 0;
  }

  e = 0;
  for(bddword ix=0; ix<n_nd; ix++)
  {
    if(fscanf(strm, "%s", &s) == EOF) { e = 1; break; }
    bddword nd = B_STRTOI(s, NULL, 10);
    
    if(fscanf(strm, "%s", &s) == EOF) { e = 1; break; }
    int lev = strtol(s, NULL, 10);
    int var = bddvaroflev(lev);

    if(fscanf(strm, "%s", &s) == EOF) { e = 1; break; }
    if(strcmp(s, "F") == 0) f0 = 0;
    else if(strcmp(s, "T") == 0) f0 = 1;
    else
    {
      bddword nd0 = B_STRTOI(s, NULL, 10);

      bddword ixx = IMPORTHASH(nd0);
      while(hash1[ixx] != nd0)
      {
        if(hash1[ixx] == B_VAL_MASK)
          BDDerr("BDDV_Import(): internal error", ixx);
        ixx++;
        ixx &= (hashsize-1);
      }
      f0 = hash2[ixx];
    }

    if(fscanf(strm, "%s", &s) == EOF) { e = 1; break; }
    if(strcmp(s, "F") == 0) f1 = 0;
    else if(strcmp(s, "T") == 0) f1 = 1;
    else
    {
      bddword nd1 = B_STRTOI(s, NULL, 10);
      if(nd1 & 1) { inv = 1; nd1 ^= 1; }
      else inv = 0;
  
      bddword ixx = IMPORTHASH(nd1);
      while(hash1[ixx] != nd1)
      {
        if(hash1[ixx] == B_VAL_MASK)
          BDDerr("BDDV_Import(): internal error", ixx);
        ixx++;
        ixx &= (hashsize-1);
      }
      f1 = (inv)? ~hash2[ixx]: hash2[ixx];
    }

    BDD x = BDDvar(var);
    f = (x & f1) | (~x & f0);
    if(f == -1) { e = 1; break; }

    bddword ixx = IMPORTHASH(nd);
    while(hash1[ixx] != B_VAL_MASK)
    {
      if(hash1[ixx] == nd)
        BDDerr("BDDV_Import(): internal error", ixx);
      ixx++;
      ixx &= (hashsize-1);
    }
    hash1[ixx] = nd;
    hash2[ixx] = f;
  }

  if(e)
  {
    delete[] hash2;
    delete[] hash1;
    return BDDV(-1);
  }

  BDDV v = BDDV();
  for(int i=0; i<m; i++)
  {
    if(fscanf(strm, "%s", &s) == EOF)
    {
      delete[] hash2;
      delete[] hash1;
      return BDDV(-1);
    }
    bddword nd = B_STRTOI(s, NULL, 10);
    if(strcmp(s, "F") == 0) v = v || BDD(0);
    else if(strcmp(s, "T") == 0) v = v || BDD(1);
    else
    {
      if(nd & 1) { inv = 1; nd ^= 1; }
      else inv = 0;
  
      bddword ixx = IMPORTHASH(nd);
      while(hash1[ixx] != nd)
      {
        if(hash1[ixx] == B_VAL_MASK)
          BDDerr("BDDV_Import(): internal error", ixx);
        ixx++;
        ixx &= (hashsize-1);
      }
      v = v || (inv? ~hash2[ixx]: hash2[ixx]);
    }
  }

  delete[] hash2;
  delete[] hash1;
  return v;
}


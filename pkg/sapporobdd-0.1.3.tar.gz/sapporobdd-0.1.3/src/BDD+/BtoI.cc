/******************************************
 * Binary-to-Integer function class       *
 * (SAPPORO-1.24) - Body                  *
 * (C) Shin-ichi MINATO  (Mar. 19, 2010)  *
 ******************************************/

#include "BtoI.h"

BtoI::BtoI() { _bddv = BDD(0); }
BtoI::BtoI(const BtoI& fv) { _bddv = fv._bddv; }
BtoI::BtoI(const BDDV& fv) { _bddv = fv; }

BtoI::BtoI(const BDD& f)
{
  _bddv = BDDV(f, 1);
  if(f != 0) _bddv = _bddv || BDD(0);
}

BtoI::BtoI(int n)
{
  int k = n;
  if(k < 0)
  {
    k = -k;
    if(k < 0) BDDerr("BtoI::BtoI(): overflow.", n);
  }
  while(k != 0)
  {
    if((k & 1) != 0) _bddv = _bddv || BDD(1);
    else             _bddv = _bddv || BDD(0);
    k >>= 1;
  }
  _bddv = _bddv || BDD(0);
  if(n < 0) *this = - (*this);
}

BtoI::~BtoI() { }

BtoI& BtoI::operator=(const BtoI& fv)
{
  _bddv = fv._bddv;
  return *this;
}

BtoI BtoI::operator+=(const BtoI& fv) { return *this = *this + fv; }
BtoI BtoI::operator-=(const BtoI& fv) { return *this = *this - fv; }
BtoI BtoI::operator*=(const BtoI& fv) { return *this = *this * fv; }
BtoI BtoI::operator/=(const BtoI& fv) { return *this = *this / fv; }
BtoI BtoI::operator%=(const BtoI& fv) { return *this = *this % fv; }
BtoI BtoI::operator&=(const BtoI& fv) { return *this = *this & fv; }
BtoI BtoI::operator|=(const BtoI& fv) { return *this = *this | fv; }
BtoI BtoI::operator^=(const BtoI& fv) { return *this = *this ^ fv; }
BtoI BtoI::operator<<=(const BtoI& fv) { return *this = *this << fv; }
BtoI BtoI::operator>>=(const BtoI& fv) { return *this = *this >> fv; }

BtoI BtoI::operator-() { return 0 - *this; }

BtoI BtoI::operator~() { return BtoI(~_bddv); }

BtoI BtoI::operator!() { return BtoI_EQ(*this, 0); }

BtoI BtoI::Shift(int power)
{
  if(power == 0) return *this;
  if(power > 0)
  {
    if(*this == 0) return *this;
    return BtoI(BDDV(0, power) || _bddv);
  }
  int p = -power;
  int len = Len();
  if(p >= len) p = len-1;
  return BtoI(_bddv.Part(p, len - p));
}
		
BtoI BtoI::operator<<(const BtoI& fv)
{
  if(_bddv == BDDV(-1)) return *this;
  if(fv == BtoI(BDD(-1))) return fv;
  BtoI ffv = fv;
  BDD sign = ffv.GetSignBDD();
  BtoI p1 = BtoI_ITE(sign, 0, *this);
  BtoI n1 = BtoI_ITE(sign, *this, 0);
  BtoI p2 = BtoI_ITE(sign, 0, ffv);
  BtoI n2 = BtoI_ITE(sign, -ffv, 0);

  for(int i=0; i<ffv.Len(); i++)
  {
    BDD f = p2.GetBDD(i);
    if(f != 0) p1 = BtoI_ITE(f, p1.Shift(1 << i), p1);
    f = n2.GetBDD(i);
    if(f != 0) n1 = BtoI_ITE(f, n1.Shift(-(1 << i)), n1);
  }
  return p1 | n1;
}

BtoI BtoI::operator>>(const BtoI& fv)
{ BtoI ffv = fv; return *this << -ffv; }

BtoI BtoI::Sup()
{
  BDDV fv = _bddv;
  int len = fv.Len();
  while(len > 1)
  {
    if(fv.GetBDD(len-1) != fv.GetBDD(len-2))
      break;
    fv = fv.Part(0, --len);
  }
  return BtoI(fv);
}

BtoI BtoI::UpperBound()
{
  if(_bddv == BDDV(-1)) return *this;
  BDD d = GetSignBDD();
  BDD c0 = BDD(d==1);
  BDDV ub = c0;
  BDD cond = c0 | ~d;
  for(int i=Len()-2; i>=0; i--)
  {
    d = GetBDD(i);
    c0 = BDD((cond & d) != 0);
    if(c0 == -1) return BtoI(BDD(-1));
    ub = c0 || ub;
    cond &= ~c0 | d;
  }
  return BtoI(ub).Sup();
}

BtoI BtoI::UpperBound(BDD f)
{
  if(_bddv == BDDV(-1)) return *this;
  if(f == -1) return BtoI(BDDV(-1));
  BDD d = GetSignBDD();
  BDD c0 = d.Univ(f);
  BDDV ub = c0;
  BDD cond = c0 | ~d;
  for(int i=Len()-2; i>=0; i--)
  {
    d = GetBDD(i);
    c0 = (cond & d).Exist(f);
    if(c0 == -1) return BtoI(BDD(-1));
    ub = c0 || ub;
    cond &= ~c0 | d;
  }
  return BtoI(ub).Sup();
}

BtoI BtoI::LowerBound() { return - (- *this).UpperBound(); }
BtoI BtoI::LowerBound(BDD f) { return - (- *this).UpperBound(f); }

BtoI BtoI::At0(int var)
{
  if(BDD_LevOfVar(var) > BDDV_UserTopLev())
    BDDerr("BtoI::At0: Invalid VarID.", var);
  return BtoI(_bddv.At0(var)).Sup();
}

BtoI BtoI::At1(int var)
{
  if(BDD_LevOfVar(var) > BDDV_UserTopLev())
    BDDerr("BtoI::At1: Invalid VarID.", var);
  return BtoI(_bddv.At1(var)).Sup();
}

BtoI BtoI::Cofact(BtoI fv)
{
  BDDV a = BDDV(BtoI_NE(fv, 0).GetBDD(0), Len());
  return BtoI(_bddv.Cofact(a)).Sup();
}

BtoI BtoI::Spread(int k)
{
  return BtoI(_bddv.Spread(k));
}

int BtoI::Top() { return _bddv.Top(); }

BDD BtoI::GetSignBDD() { return _bddv.GetBDD(Len()-1); }

BDD BtoI::GetBDD(int index)
{
  if(index < 0)
    BDDerr("BtoI::GetBDD(): Illegal index.",index);
  if(index >=  Len()) index = Len()-1;
  return _bddv.GetBDD(index);
}

BDDV BtoI::GetMetaBDDV(void) { return _bddv; }

int BtoI::Len(void) { return _bddv.Len(); }

int BtoI::GetInt()
{
  if(Top() > 0)
  {
    if(_bddv == BDDV(-1)) return 0;
    return At0(Top()).GetInt();
  }
  if(GetSignBDD() != 0) return - (- *this).GetInt();
  int len = Len();
  if(len > 32) len = 32; // Assuming 32-bit int.
  int n = 0;
  for(int i=len-2; i>=0; i--)
  {
    n <<= 1;
    if(GetBDD(i) != 0) n |= 1;
  }
  return n;
}

bddword BtoI::Size() { return _bddv.Size(); }

void BtoI::Print() { _bddv.Print(); }

int operator==(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  return (aa.Len() == bb.Len() && a._bddv == b._bddv);
}

int operator!=(const BtoI& a, const BtoI& b) { return !(a == b); }

BtoI operator+(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  if(a == 0) return b;
  if(b == 0) return a;
  if(a == BtoI(BDD(-1))) return a;
  if(b == BtoI(BDD(-1))) return b;
  BDD a0;
  BDD b0;
  BDD c = 0;
  BDD c0 = 0;
  BDDV fv;
  int len = aa.Len();
  if(len < bb.Len()) len = bb.Len();
  for(int i=0; i<len; i++)
  {
    a0 = aa.GetBDD(i);
    b0 = bb.GetBDD(i);
    c0 = c;
    fv = fv || (a0 ^ b0 ^ c0);
    c = (a0 & b0)|(b0 & c0)|(c0 & a0);
  }
  if(c != c0) fv = fv || (a0 ^ b0 ^ c);
  return BtoI(fv).Sup();
}

BtoI operator-(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  if(b == 0) return a;
  if(b == BtoI(BDD(-1))) return b;
  if(a == b) return 0;
  if(a == BtoI(BDD(-1))) return a;
  BDD a0;
  BDD b0;
  BDD c = 0;
  BDD c0 = 0;
  BDDV fv;
  int len = aa.Len();
  if(len < bb.Len()) len = bb.Len();
  for(int i=0; i<len; i++)
  {
    a0 = aa.GetBDD(i);
    b0 = bb.GetBDD(i);
    c0 = c;
    fv = fv || (a0 ^ b0 ^ c0);
    c = (~a0 & b0)|(b0 & c0)|(c0 & ~a0);
  }
  if(c != c0) fv = fv || (a0 ^ b0 ^ c);
  return BtoI(fv).Sup();
}

BtoI operator*(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  if(a == 1) return b;
  if(b == 1) return a;
  if(a == BtoI(BDD(-1))) return a;
  if(b == BtoI(BDD(-1))) return b;
  if(a == 0) return 0;
  if(b == 0) return 0;
  BDD sign = bb.GetSignBDD();
  BtoI a0 = BtoI_ITE(sign, -aa, aa);
  BtoI b0 = BtoI_ITE(sign, -bb, bb);
  BtoI s = BtoI_ITE(bb.GetBDD(0), a0, 0);
  while(b0 != 0)
  {
    a0 <<= 1;
    b0 >>= 1;
    s += BtoI_ITE(b0.GetBDD(0), a0, 0);
    if(s == BtoI(BDD(-1))) break;
  }
  return s;
}

BtoI operator/(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  if(b == 1) return a;
  if(a == BtoI(BDD(-1))) return a;
  if(b == BtoI(BDD(-1))) return b;
  if(a == 0) return 0;
  if(a == b) return 1;
  if(BtoI_EQ(b, 0) != 0) 
    BDDerr("BtoI::operator/(): Divided by 0.");
  BDD sign = aa.GetSignBDD() ^ bb.GetSignBDD();
  BtoI a0 = BtoI_ITE(aa.GetSignBDD(), -aa, aa);
  if(a0 == BtoI(BDD(-1))) return a0;
  BtoI b0 = BtoI_ITE(bb.GetSignBDD(), -bb, bb);
  if(b0 == BtoI(BDD(-1))) return b0;
  int len = a0.Len();
  b0 <<= len - 2;
  BtoI s = 0;
  for(int i=0; i<len-1; i++)
  {
    s <<= 1;
    BtoI cond = BtoI_GE(a0, b0);
    a0 = BtoI_ITE(cond, a0 - b0, a0);
    s += cond;
    b0 >>= 1;
  }
  return BtoI_ITE(sign, -s, s);
}

BtoI operator%(const BtoI& a, const BtoI& b)
{ return a - b * (a / b); }

BtoI operator&(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  int len = aa.Len();
  if(len < bb.Len()) len = bb.Len();
  BDDV fv;
  for(int i=0; i<len; i++)
    fv = fv || (aa.GetBDD(i) & bb.GetBDD(i));
  return BtoI(fv).Sup();
}

BtoI operator|(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  int len = aa.Len();
  if(len < bb.Len()) len = bb.Len();
  BDDV fv;
  for(int i=0; i<len; i++)
    fv = fv || (aa.GetBDD(i) | bb.GetBDD(i));
  return BtoI(fv).Sup();
}

BtoI operator^(const BtoI& a, const BtoI& b)
{
  BtoI aa = a; BtoI bb = b;
  int len = aa.Len();
  if(len < bb.Len()) len = bb.Len();
  BDDV fv;
  for(int i=0; i<len; i++)
    fv = fv || (aa.GetBDD(i) ^ bb.GetBDD(i));
  return BtoI(fv).Sup();
}

BtoI BtoI_ITE(BDD f, BtoI a, BtoI b)
{
  if(a == b) return a;
  int len = a.Len();
  if(len < b.Len()) len = b.Len();
  BDDV fv;
  for(int i=0; i<len; i++)
  {
    BDD g = (f & a.GetBDD(i)) | (~f & b.GetBDD(i));
    fv = fv || g;
  }
  return BtoI(fv).Sup();
}

BtoI BtoI_ITE(BtoI a, BtoI b, BtoI c)
{
  return BtoI_ITE(~(BtoI_EQ(a, 0).GetBDD(0)), b, c);
}

BtoI BtoI_EQ(BtoI a, BtoI b)
{
  BtoI c = a - b;
  BDD cond = 0;
  for(int i=0; i<c.Len(); i++)
  {
    cond |= c.GetBDD(i);
    if(cond == 1) break;
  }
  return BtoI(~cond);
}

BtoI BtoI_NE(BtoI a, BtoI b) { return ! BtoI_EQ(a, b); }

BtoI BtoI_GT(BtoI a, BtoI b)
{
  BtoI c = b - a;
  return BtoI(c.GetSignBDD());
}

BtoI BtoI_LT(BtoI a, BtoI b)
{
  BtoI c = a - b;
  return BtoI(c.GetSignBDD());
}

BtoI BtoI_GE(BtoI a, BtoI b) { return ! BtoI_LT(a, b); }

BtoI BtoI_LE(BtoI a, BtoI b) { return ! BtoI_GT(a, b); }

static BtoI atoi16(char *);
static BtoI atoi16(char* s)
{
  const int width = 6;
  int p = 0;
  int len = strlen(s);
  char a[width + 1];
  BtoI fv = 0;
  while(len - p > width)
  {
    fv <<= BtoI(width*4);
    strncpy(a, s+p, width);
    fv += BtoI((int)strtol(a, 0, 16));
    p += width;
  }
  if(len > width) fv <<= BtoI((len-p)*4);
  strncpy(a, s+p, width);
  fv += BtoI((int)strtol(a, 0, 16));
  return fv;
}
	
static BtoI atoi2(char *);
static BtoI atoi2(char* s)
{
  int p = 0;
  int len = strlen(s);
  BtoI fv = 0;
  while(p < len)
  {
    fv <<= BtoI(1);
    if(s[p] == '1') fv += 1;
    p++;
  }
  return fv;
}
	
static BtoI atoi10(char *);
static BtoI atoi10(char* s)
{
  const int width = 9;
  int times = 1000000000; // 10 ** width
  int p = 0;
  int len = strlen(s);
  char a[width + 1];
  BtoI fv = 0;
  while(len - p > width)
  {
    fv *= BtoI(times);
    strncpy(a, s+p, width);
    fv += BtoI((int)strtol(a, 0, 10));
    p += width;
  }
  if(len > width)
  {
    times = 1;
    for(int i=p; i<len; i++) times *= 10;
    fv *= BtoI(times);
  }
  strncpy(a, s+p, width);
  fv += BtoI((int)strtol(a, 0, 10));
  return fv;
}
	
BtoI BtoI_atoi(char* s)
{
  if(s[0] == '0')
  {
    switch(s[1])
    {
    case 'x':
    case 'X':
      return atoi16(s+2);
    case 'b':
    case 'B':
      return atoi2(s+2);
    default:
      ;
    }
  }
  return atoi10(s);
}

static const char table[] = "0123456789ABCDEF";

int BtoI::StrNum10(char* s)
{
  if(*this == BtoI(BDD(-1)))
  {
    sprintf(s, "0");
    return 1;
  }
  const int width = 9;
  BtoI fv0 = *this;
  while(fv0.Top() > 0) fv0 = fv0.At0(fv0.Top());
  int i=0;
  int sign = 0;
  if(fv0.GetSignBDD() == 1)
  {
    sign = 1;
    fv0 = -fv0;
  }
  BtoI a;
  char s0[12];
  if(fv0.Len() > 29)
  {
    BtoI fvb = BtoI(1000000000); // 10 ** width 
    while(1)
    {
      BtoI t = BtoI_GE(fv0, fvb);
      if(t == BtoI(BDD(-1)))
      {
        sprintf(s, "0");
        return 1;
      }
      if(t == BtoI(0)) break;
      a = fv0 % fvb;
      if(a == BtoI(BDD(-1)))
      {
        sprintf(s, "0");
        return 1;
      }
      sprintf(s0, "%09d", a.GetInt());
      for(int j=i-1; j>=0; j--) s[j+width] = s[j];
      for(int j=0; j<width; j++) s[j] = s0[j];
      i += width;
      fv0 /= fvb;
    }
  }
  sprintf(s0, "%d", fv0.GetInt());
  int len = strlen(s0);
  for(int j=i-1; j>=0; j--) s[j+len] = s[j];
  for(int j=0; j<len; j++) s[j] = s0[j];
  i += len;
  if(sign == 1)
  {
    for(int j=i-1; j>=0; j--) s[j+1] = s[j];
    s[0] = '-';
    i++;
  }
  s[i] = 0;
  return 0;
}

int BtoI::StrNum16(char* s)
{
  if(*this == BtoI(BDD(-1)))
  {
    sprintf(s, "0");
    return 1;
  }
  const int width = 7;
  BtoI fv0 = *this;
  while(fv0.Top() > 0) fv0 = fv0.At0(fv0.Top());
  int i=0;
  int sign = 0;
  if(fv0.GetSignBDD() == 1)
  {
    sign = 1;
    fv0 = -fv0;
  }
  BtoI a;
  char s0[10];
  if(fv0.Len() > 27)
  {
    BtoI fvb = BtoI(1<<(width*4));
    while(1)
    {
      BtoI t = BtoI_GE(fv0, fvb);
      if(t == BtoI(BDD(-1)))
      {
        sprintf(s, "0");
        return 1;
      }
      if(t == BtoI(0)) break;
      a = fv0 & (fvb-1);
      if(a == BtoI(BDD(-1)))
      {
        sprintf(s, "0");
        return 1;
      }
      sprintf(s0, "%07X", a.GetInt());
      for(int j=i-1; j>=0; j--) s[j+width] = s[j];
      for(int j=0; j<width; j++) s[j] = s0[j];
      i += width;
      fv0 >>= width*4;
    }
  }
  sprintf(s0, "%X", fv0.GetInt());
  int len = strlen(s0);
  for(int j=i-1; j>=0; j--) s[j+len] = s[j];
  for(int j=0; j<len; j++) s[j] = s0[j];
  i += len;
  if(sign == 1)
  {
    for(int j=i-1; j>=0; j--) s[j+1] = s[j];
    s[0] = '-';
    i++;
  }
  s[i] = 0;
  return 0;
}



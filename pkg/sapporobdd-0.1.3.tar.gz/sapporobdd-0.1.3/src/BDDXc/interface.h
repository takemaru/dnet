		/* bddio libraries */

bddp	Strip();		/* Strip( bddp node ) */
int	AttributeOfEdge();	/* AttributeOfEdge( bddp edge ) */
int	SameNode();		/* SameNode( bddp n1, n2 ) */
short	GetLevelOf();		/* GetLevelOf( bddp node ) */
bddp	GetLeftPtrOf();		/* GetLeftPtrOf( bddp node ) */
bddp	GetRightPtrOf();	/* GetRightPtrOf( bddp node ) */
bddp	ParseNode();		/* ParseNode( char *word ) */

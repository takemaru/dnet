/************************************************
 * ZBDD-based SOP class (SAPPORO-1.40) - Header *
 * (C) Shin-ichi MINATO  (May 1, 2011)          *
 ************************************************/

class SOP;
class SOPV;

#ifndef _SOP_
#define _SOP_

#include "ZBDD.h"

class SOP;
extern int SOP_NewVar(void);
extern int SOP_NewVarOfLev(int);

extern SOP operator&(const SOP&, const SOP&);
extern SOP operator+(const SOP&, const SOP&);
extern SOP operator-(const SOP&, const SOP&);
extern int operator==(const SOP&, const SOP&);
extern int operator!=(const SOP&, const SOP&);

extern SOP operator*(const SOP&, const SOP&);
extern SOP operator/(const SOP&, const SOP&);
extern SOP operator%(const SOP&, const SOP&);

extern SOP SOP_ISOP(BDD);
extern SOP SOP_ISOP(BDD, BDD);

class SOP
{
  ZBDD _zbdd;
public:
  SOP(void);
  SOP(int);
  SOP(const SOP&);
  SOP(const ZBDD&);

  ~SOP(void);

  SOP& operator=(const SOP&);
  SOP operator&=(const SOP&);
  SOP operator+=(const SOP&);
  SOP operator-=(const SOP&);
  SOP operator*=(const SOP&);
  SOP operator/=(const SOP&);
  SOP operator%=(const SOP&);
  SOP operator<<=(int);
  SOP operator>>=(int);

  SOP operator<<(int);
  SOP operator>>(int);
  SOP And0(int);
  SOP And1(int);
  SOP Factor0(int);
  SOP Factor1(int);
  SOP FactorD(int);

  int Top(void);
  bddword Size(void);
  bddword Cube(void);
  bddword Lit(void);
  
  int IsPolyCube(void);
  int IsPolyLit(void);
  SOP Divisor(void);
  SOP Implicants(BDD);
  SOP Support(void);
  SOP BoolDiv(SOP, int);
  SOP BoolDiv(SOP, SOP, int);
  SOP BoolDiv(BDD, int);

  void Print(void);
  int PrintPla(void);
  
  ZBDD GetZBDD(void);
  BDD GetBDD(void);
  SOP InvISOP(void);

  SOP Swap(int, int);

  friend SOP operator&(const SOP&, const SOP&);
  friend SOP operator+(const SOP&, const SOP&);
  friend SOP operator-(const SOP&, const SOP&);
  friend int operator==(const SOP&, const SOP&);
};

class SOPV;
extern int SOPV_NewVar(void);
extern int SOPV_NewVarOfLev(int);

extern SOPV operator&(const SOPV&, const SOPV&);
extern SOPV operator+(const SOPV&, const SOPV&);
extern SOPV operator-(const SOPV&, const SOPV&);
extern int operator==(const SOPV&, const SOPV&);
extern int operator!=(const SOPV&, const SOPV&);

extern SOPV SOPV_ISOP(BDDV);
extern SOPV SOPV_ISOP(BDDV, BDDV);
extern SOPV SOPV_ISOP2(BDDV);
extern SOPV SOPV_ISOP2(BDDV, BDDV);

class SOPV
{
  ZBDDV _v;

public:
  SOPV(void);
  SOPV(const SOPV&);
  SOPV(const ZBDDV&);
  SOPV(const SOP&, int location = 0);
  ~SOPV(void);

  SOPV& operator=(const SOPV&);
  SOPV operator&=(const SOPV&);
  SOPV operator+=(const SOPV&);
  SOPV operator-=(const SOPV&);
  SOPV operator<<=(int);
  SOPV operator>>=(int);

  SOPV operator<<(int);
  SOPV operator>>(int);
  SOPV And0(int);
  SOPV And1(int);
  SOPV Factor0(int);
  SOPV Factor1(int);
  SOPV FactorD(int);
  
  int Top(void);
  bddword Size(void);
  bddword Cube(void);
  bddword Lit(void);
  void Print(void);
  int PrintPla(void);
  
  SOPV Mask(int start, int length = 1);

  SOP GetSOP(int);
  ZBDDV GetZBDDV(void);

  int Last(void);
  
  SOPV Swap(int, int);

  friend SOPV operator&(const SOPV&, const SOPV&);
  friend SOPV operator+(const SOPV&, const SOPV&);
  friend SOPV operator-(const SOPV&, const SOPV&);
  
  friend int operator==(const SOPV&, const SOPV&);
};

#endif // _SOP_


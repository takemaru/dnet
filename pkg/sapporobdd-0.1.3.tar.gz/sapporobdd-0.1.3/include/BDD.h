/********************************************
 * BDD+ Manipulator (SAPPORO-1.40) - Header *
 * (C) Shin-ichi MINATO  (May 1, 2011)      *
 ********************************************/

class BDD;
class BDDV;

#ifndef _BDD_
#define _BDD_

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <iostream>
using namespace std;

class ORD;

//--------- Definition of "bddword" type --------
#ifdef B_64
  typedef unsigned long long bddword;
#else
  typedef unsigned int bddword;
#endif

//--------- External constant data for BDD ---------
extern const bddword BDD_MaxNode;
extern const int BDD_MaxVar;

//--------- Stack overflow limitter ---------
extern const int BDD_RecurLimit;
extern int BDD_RecurCount;
#define BDD_RECUR_INC \
  {if(++BDD_RecurCount >= BDD_RecurLimit) \
  BDDerr("BDD_RECUR_INC:Stack overflow ", (bddword) BDD_RecurCount);}
#define BDD_RECUR_DEC BDD_RecurCount--

//--------- External operations for BDD ---------
extern void    BDD_Init(bddword, bddword);
extern int     BDD_NewVar(void);
extern int     BDD_NewVarOfLev(int);
extern int     BDD_LevOfVar(int);
extern int     BDD_VarOfLev(int);
extern int     BDD_VarUsed(void);
extern int     BDD_TopLev(void);
extern bddword BDD_Used(void);
extern void    BDD_GC(void);
extern bddword BDD_CacheInt(unsigned char, bddword, bddword);
extern BDD  BDD_CacheBDD(unsigned char, bddword, bddword);
extern void BDD_CacheEnt(unsigned char, bddword, bddword, bddword);
extern BDD BDD_ID(bddword);

extern BDD BDDvar(int);
extern BDD operator&(const BDD&, const BDD&);
extern BDD operator|(const BDD&, const BDD&);
extern BDD operator^(const BDD&, const BDD&);
extern int operator==(const BDD&, const BDD&);
extern int operator!=(const BDD&, const BDD&);
extern int BDD_Imply(BDD, BDD);
extern BDD BDD_Import(FILE *strm = stdin);
extern BDD BDD_Random(int, int density = 50);
extern void BDDerr(const char *);
extern void BDDerr(const char *, bddword);
extern void BDDerr(const char *, const char *);

class BDD
{
  bddword _bdd;

public:
  BDD(void);
  BDD(int);
  BDD(const BDD&);

  static BDD create_from_bddp(bddword);

  ~BDD(void);

  BDD& operator=(const BDD&);

  BDD operator&=(const BDD&);
  BDD operator|=(const BDD&);
  BDD operator^=(const BDD&);
  BDD operator<<=(int);
  BDD operator>>=(int);

  BDD operator~(void);
  BDD operator<<(int);
  BDD operator>>(int);

  BDD At0(int);
  BDD At1(int);
  BDD Cofact(BDD);
  BDD Univ(BDD);
  BDD Exist(BDD);
  BDD Support(void);

  int Top(void) const;

  bddword Size(void) const;
  void Export(FILE *strm = stdout);
  void XPrint0(void);
  void XPrint(void);

  bddword GetID(void) const;

  void Print(void);
  BDD Swap(int, int);
  BDD Smooth(int);
  BDD Spread(int);

  friend BDD BDDvar(int);
  friend BDD operator&(const BDD&, const BDD&);
  friend BDD operator|(const BDD&, const BDD&);
  friend BDD operator^(const BDD&, const BDD&);
  friend int operator==(const BDD&, const BDD&);
  friend int operator!=(const BDD&, const BDD&);
  friend BDD BDD_CacheBDD(unsigned char, bddword, bddword);
  friend BDD BDD_ID(bddword);
  friend int BDD_Imply(BDD, BDD);
};


//----- External constant data for BDD Vector ---------
extern const int BDDV_SysVarTop;
extern const int BDDV_MaxLen;
extern const int BDDV_MaxLenImport;

//----- External operations for BDD Vector ---------
extern void    BDDV_Init(bddword, bddword);
extern int     BDDV_UserTopLev(void);
extern int     BDDV_NewVar(void);
extern int     BDDV_NewVarOfLev(int);
extern BDDV operator&(const BDDV&, const BDDV&);
extern BDDV operator|(const BDDV&, const BDDV&);
extern BDDV operator^(const BDDV&, const BDDV&);

extern int operator==(const BDDV&, const BDDV&);
extern int operator!=(const BDDV&, const BDDV&);
extern int BDDV_Imply(BDDV, BDDV);

extern BDDV operator||(const BDDV&, const BDDV&);
extern BDDV BDDV_Mask1(int, int);
extern BDDV BDDV_Mask2(int, int);

extern BDDV BDDV_Import(FILE *strm = stdin);

class BDDV
{
  BDD _bdd;
  int _len;
  int _level;

public:
  BDDV(void);
  BDDV(const BDDV&);
  BDDV(const BDD&, int len = 1);
  ~BDDV(void);

  BDDV& operator=(const BDDV&);
  BDDV operator&=(const BDDV&);
  BDDV operator|=(const BDDV&);
  BDDV operator^=(const BDDV&);
  BDDV operator<<=(int);
  BDDV operator>>=(int);

  BDDV operator~(void);
  BDDV operator<<(int);
  BDDV operator>>(int);

  BDDV At0(int);
  BDDV At1(int);
  BDDV Cofact(BDDV);
  BDDV Swap(int, int);
  BDDV Spread(int);

  int Top(void);

  bddword Size();
  void Export(FILE *strm = stdout);
  void XPrint0();
  void XPrint();

  BDDV Former(void);
  BDDV Latter(void);
  BDDV Part(int, int);
  BDD GetBDD(int);
  BDD GetMetaBDD(void);

  int Uniform(void);
  int Len(void);

  void Print();
	
  friend BDDV operator&(const BDDV&, const BDDV&);
  friend BDDV operator|(const BDDV&, const BDDV&);
  friend BDDV operator^(const BDDV&, const BDDV&);

  friend int operator==(const BDDV&, const BDDV&);
  friend int BDDV_Imply(BDDV, BDDV);

  friend BDDV operator||(const BDDV&, const BDDV&);

};

class BDD_Hash
{
  struct BDD_Entry
  {
    BDD _key;
    void* _ptr;
    BDD_Entry(void){ _key = -1; }
  };

  bddword _amount;
  bddword _hashSize;
  BDD_Entry* _wheel;

  BDD_Entry* GetEntry(BDD);
  void Enlarge(void);
public:
  BDD_Hash(void);
  ~BDD_Hash(void);
  void Clear(void);
  void Enter(BDD, void *);
  void* Refer(BDD);
  bddword Amount(void);
};

#endif // _BDD_ 

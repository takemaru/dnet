/*********************************************
 * ZBDD+ Manipulator (SAPPORO-1.41) - Header *
 * (C) Shin-ichi MINATO  (May 3, 2011)       *
 *********************************************/

class ZBDD;
class ZBDDV;

#ifndef _ZBDD_
#define _ZBDD_

#include "BDD.h"

class SeqBDD;

extern ZBDD operator&(const ZBDD&, const ZBDD&);
extern ZBDD operator+(const ZBDD&, const ZBDD&);
extern ZBDD operator-(const ZBDD&, const ZBDD&);
extern ZBDD operator*(const ZBDD&, const ZBDD&);
extern ZBDD operator/(const ZBDD&, const ZBDD&);
extern ZBDD operator%(const ZBDD&, const ZBDD&);
extern int operator==(const ZBDD&, const ZBDD&);
extern int operator!=(const ZBDD&, const ZBDD&);
extern ZBDD ZBDD_Random(int, int density = 50);
extern ZBDD ZBDD_Import(FILE *strm = stdin);
extern ZBDD BDD_CacheZBDD(char, bddword, bddword);
extern ZBDD ZBDD_ID(bddword);
extern ZBDD ZBDD_LCM_A(char *, int);
extern ZBDD ZBDD_LCM_C(char *, int);
extern ZBDD ZBDD_LCM_M(char *, int);
extern ZBDD ZBDD_Meet(ZBDD, ZBDD);

class ZBDD
{
  bddword _zbdd;

public:
  ZBDD(void);
  ZBDD(int);
  ZBDD(const ZBDD&);

  static ZBDD create_from_bddp(bddword);

  ~ZBDD(void);

  ZBDD& operator=(const ZBDD&);
  ZBDD operator&=(const ZBDD&);
  ZBDD operator+=(const ZBDD&);
  ZBDD operator-=(const ZBDD&);
  ZBDD operator*=(const ZBDD&);
  ZBDD operator/=(const ZBDD&);
  ZBDD operator%=(const ZBDD&);
  ZBDD operator<<=(int);
  ZBDD operator>>=(int);

  ZBDD operator<<(int);
  ZBDD operator>>(int);

  ZBDD OffSet(int);
  ZBDD OnSet(int);
  ZBDD OnSet0(int);
  ZBDD Change(int);

  ZBDD Swap(int, int);
  ZBDD Restrict(ZBDD);
  ZBDD Permit(ZBDD);
  ZBDD PermitSym(int);
  ZBDD Support(void);
  ZBDD Always(void);

  int SymChk(int, int);
  ZBDD SymGrp(void);
  ZBDD SymGrpNaive(void);

  int ImplyChk(int, int);
  int CoImplyChk(int, int);
  ZBDD SymSet(int);
  ZBDD ImplySet(int);
  ZBDD CoImplySet(int);

  int IsPoly(void);
  ZBDD Divisor(void);

  int Top(void) const;
  bddword GetID(void) const;

  bddword Size(void) const;
  bddword Card(void) const;
  bddword Lit(void) const;
  bddword Len(void) const;
  void Export(FILE *strm = stdout);
  void PrintPla(void) const;
  void XPrint(void);
//  void XPrint0(void);
  void Print(void);

  friend ZBDD operator&(const ZBDD&, const ZBDD&);
  friend ZBDD operator+(const ZBDD&, const ZBDD&);
  friend ZBDD operator-(const ZBDD&, const ZBDD&);
  friend ZBDD operator*(const ZBDD&, const ZBDD&);
  friend ZBDD operator/(const ZBDD&, const ZBDD&);
  friend ZBDD operator%(const ZBDD&, const ZBDD&);
  friend ZBDD BDD_CacheZBDD(char, bddword, bddword);
  friend int operator==(const ZBDD&, const ZBDD&);
  friend ZBDD ZBDD_ID(bddword);
  friend ZBDD ZBDD_SymSet(ZBDD, ZBDD);
  friend ZBDD ZBDD_CoImplySet(ZBDD, ZBDD);
  friend ZBDD ZBDD_Meet(ZBDD, ZBDD);

  friend class SeqBDD;
};


extern ZBDDV operator&(const ZBDDV&, const ZBDDV&);
extern ZBDDV operator+(const ZBDDV&, const ZBDDV&);
extern ZBDDV operator-(const ZBDDV&, const ZBDDV&);

extern int operator==(const ZBDDV&, const ZBDDV&);
extern int operator!=(const ZBDDV&, const ZBDDV&);

extern ZBDDV ZBDDV_Import(FILE *strm = stdin);

class ZBDDV
{
  ZBDD _zbdd;

public:
  ZBDDV(void);
  ZBDDV(const ZBDDV&);
  ZBDDV(const ZBDD&, int location = 0);
  ~ZBDDV(void);

  ZBDDV& operator=(const ZBDDV&);
  ZBDDV operator&=(const ZBDDV&);
  ZBDDV operator+=(const ZBDDV&);
  ZBDDV operator-=(const ZBDDV&);
  ZBDDV operator<<=(int);
  ZBDDV operator>>=(int);

  ZBDDV operator<<(int);
  ZBDDV operator>>(int);

  ZBDDV OffSet(int);
  ZBDDV OnSet(int);
  ZBDDV OnSet0(int);
  ZBDDV Change(int);
  ZBDDV Swap(int, int);
  
  int Top(void);

  ZBDDV Mask(int start, int length = 1);
  ZBDD GetZBDD(int);
  ZBDD GetMetaZBDD(void);

  int Last(void);

  bddword Size(void);
  void Print(void);
  void Export(FILE *strm = stdout);
  int PrintPla(void);
  void XPrint(void);
//  void XPrint0(void);
	
  friend ZBDDV operator&(const ZBDDV&, const ZBDDV&);
  friend ZBDDV operator+(const ZBDDV&, const ZBDDV&);
  friend ZBDDV operator-(const ZBDDV&, const ZBDDV&);
  friend int operator==(const ZBDDV&, const ZBDDV&);
};

class ZBDD_Hash;
class ZBDD_Hash
{
  struct ZBDD_Entry
  {
    ZBDD _key;
    void* _ptr;
    ZBDD_Entry(void){ _key = -1; }
  };

  bddword _amount;
  bddword _hashSize;
  ZBDD_Entry* _wheel;
  
  ZBDD_Entry* GetEntry(ZBDD);
  void Enlarge(void);
public:
  ZBDD_Hash(void);
  ~ZBDD_Hash(void);
  void Clear(void);
  void Enter(ZBDD, void *);
  void* Refer(ZBDD);
  bddword Amount(void);
};

#endif // _ZBDD_

/****************************************
 * BDD+ Manipulator (SAPPORO-1.21)      *
 * (Graphic methods)                    *
 * (C) Shin-ichi MINATO (Feb. 18, 2009) *
 ****************************************/

#include "BDD.h"

extern "C"
{
	extern void bddgraph0(...);
	extern void bddvgraph0(...);
	extern void bddgraph(...);
	extern void bddvgraph(...);
}

void BDD::XPrint0()
{
	bddgraph0(_bdd);
}

void BDDV::XPrint0()
{
	bddword* bddv = new bddword[_len];
	for(int i=0; i<_len; i++) bddv[i] = GetBDD(i).GetID(); 
	bddvgraph0(bddv, _len);
	delete[] bddv;
}

void BDD::XPrint()
{
	bddgraph(_bdd);
}

void BDDV::XPrint()
{
	bddword* bddv = new bddword[_len];
	for(int i=0; i<_len; i++) bddv[i] = GetBDD(i).GetID(); 
	bddvgraph(bddv, _len);
	delete[] bddv;
}


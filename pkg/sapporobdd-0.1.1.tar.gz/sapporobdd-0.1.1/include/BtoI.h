/******************************************
 * Binary-to-Integer function class       *
 * (SAPPORO-1.24) - Header                *
 * (C) Shin-ichi MINATO  (Mar. 19, 2010)  *
 ******************************************/

class BtoI;

#ifndef _BtoI_
#define _BtoI_

#include "BDD.h"

class BtoI
{
  BDDV _bddv;

  BtoI Shift(int);
  BtoI Sup(void);

public:
  BtoI(void);
  BtoI(const BtoI&);
  BtoI(const BDD&);
  BtoI(int);
  BtoI(const BDDV&);
  ~BtoI(void);

  BtoI& operator=(const BtoI&);
  BtoI operator+=(const BtoI&);
  BtoI operator-=(const BtoI&);
  BtoI operator*=(const BtoI&);
  BtoI operator/=(const BtoI&);
  BtoI operator%=(const BtoI&);
  BtoI operator&=(const BtoI&);
  BtoI operator|=(const BtoI&);
  BtoI operator^=(const BtoI&);
  BtoI operator<<=(const BtoI&);
  BtoI operator>>=(const BtoI&);
  
  BtoI operator-(void);
  BtoI operator~(void);
  BtoI operator!(void);
  BtoI operator<<(const BtoI&);
  BtoI operator>>(const BtoI&);
  
  BtoI UpperBound(void);
  BtoI UpperBound(BDD);
  BtoI LowerBound(void);
  BtoI LowerBound(BDD);
  
  BtoI At0(int);
  BtoI At1(int);
  BtoI Cofact(BtoI);

  BtoI Spread(int);

  int Top(void);

  BDD GetSignBDD(void);
  BDD GetBDD(int);
  BDDV GetMetaBDDV(void);

  int Len(void);

  int GetInt(void);
  int StrNum10(char *);
  int StrNum16(char *);
  bddword Size();

  void Print();

  friend int operator==(const BtoI&, const BtoI&);
  
  friend BtoI operator+(const BtoI&, const BtoI&);
  friend BtoI operator-(const BtoI&, const BtoI&);
  friend BtoI operator&(const BtoI&, const BtoI&);
  friend BtoI operator|(const BtoI&, const BtoI&);
  friend BtoI operator^(const BtoI&, const BtoI&);
  friend BtoI BtoI_ITE(BDD, BtoI, BtoI);
};

extern int operator==(const BtoI&, const BtoI&);
extern int operator!=(const BtoI&, const BtoI&);

extern BtoI operator+(const BtoI&, const BtoI&);
extern BtoI operator-(const BtoI&, const BtoI&);
extern BtoI operator*(const BtoI&, const BtoI&);
extern BtoI operator/(const BtoI&, const BtoI&);
extern BtoI operator%(const BtoI&, const BtoI&);
extern BtoI operator&(const BtoI&, const BtoI&);
extern BtoI operator|(const BtoI&, const BtoI&);
extern BtoI operator^(const BtoI&, const BtoI&);
extern BtoI BtoI_ITE(BDD, BtoI, BtoI);
extern BtoI BtoI_ITE(BtoI, BtoI, BtoI);

extern BtoI BtoI_EQ(BtoI, BtoI);
extern BtoI BtoI_NE(BtoI, BtoI);
extern BtoI BtoI_GT(BtoI, BtoI);
extern BtoI BtoI_LT(BtoI, BtoI);
extern BtoI BtoI_GE(BtoI, BtoI);
extern BtoI BtoI_LE(BtoI, BtoI);

extern BtoI BtoI_atoi(char *);

#endif // _BtoI_


*********************
Minimum Spanning Tree
*********************

.. automodule:: networkx.algorithms.mst
.. autosummary::
   :toctree: generated/

   minimum_spanning_tree
   minimum_spanning_edges

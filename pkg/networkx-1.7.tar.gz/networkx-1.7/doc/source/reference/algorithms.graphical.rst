*************************
Graphical degree sequence
*************************

.. automodule:: networkx.algorithms.graphical
.. autosummary::
   :toctree: generated/

   is_valid_degree_sequence
   is_valid_degree_sequence_havel_hakimi
   is_valid_degree_sequence_erdos_gallai



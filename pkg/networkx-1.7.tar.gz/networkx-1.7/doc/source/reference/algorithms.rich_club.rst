*********
Rich Club
*********

.. automodule:: networkx.algorithms.richclub
.. autosummary::
   :toctree: generated/

   rich_club_coefficient

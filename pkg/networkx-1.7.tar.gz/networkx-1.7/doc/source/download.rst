--------
Download
--------

Source and binary releases
~~~~~~~~~~~~~~~~~~~~~~~~~~
http://cheeseshop.python.org/pypi/networkx/

http://networkx.lanl.gov/download/networkx/

Mercurial source code repository
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*Anonymous*          

hg clone http://networkx.lanl.gov/hg/networkx

*Authenticated* 

hg clone https://networkx.lanl.gov/hg/networkx


Documentation
~~~~~~~~~~~~~
*PDF*

http://networkx.lanl.gov/networkx_reference.pdf
http://networkx.lanl.gov/networkx_tutorial.pdf

*HTML in zip file*

http://networkx.lanl.gov/networkx-documentation.zip

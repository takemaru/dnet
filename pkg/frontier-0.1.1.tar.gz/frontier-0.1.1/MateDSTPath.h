#ifndef MATEDSTPATH_H
#define MATEDSTPATH_H

#include "MateSTPath.h"

//*************************************************************************************************
// StateDPath: アルゴリズム動作時の「状態」を表すクラス
class StateDSTPath : public StateSTPath {
public:
    StateDSTPath(Graph* graph);
    Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateDSTPath: mate を表すクラス
class MateDSTPath : public MateSTPath {
public:
    MateDSTPath(State* state);
    //~MateDSTPath();
    void Initialize(State* state);

    void UpdateMate(State* state, int lo_or_hi);
    int CheckTerminateBefore(State* state, int lo_or_hi);
};

#endif // MATEDSTPATH_H

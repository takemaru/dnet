#include "StateHyper.h"

using namespace std;

StateHyper::StateHyper(HyperGraph* graph) : State(NULL), hgraph_(graph)
{
    NUMBER_OF_VERTICES = hgraph_->GetVertexSize();
}

void StateHyper::Update(int current_edge)
{
    current_edge_ = current_edge;

    HyperEdge edge = (*hgraph_->GetEdgeList())[current_edge];

    leaving_set_.clear();

    for (unsigned int i = 0; i < edge.var_list.size(); ++i) {
        if (edge.var_list[i]) {
            frontier_set_.insert(i);

            if (!Find(current_edge, i)) {
                leaving_set_.insert(i);
                frontier_set_.erase(i);
            }
        }
    }
}

void StateHyper::PrintFrontier()
{
    set<int>::iterator itor = frontier_set_.begin();
    while (itor != frontier_set_.end()) {
        cout << *itor << " ";
        ++itor;
    }
    cout << endl;

    itor = leaving_set_.begin();
    while (itor != leaving_set_.end()) {
        cout << *itor << " ";
        ++itor;
    }
    cout << endl;
}

int StateHyper::GetNumberOfVertices()
{
    return hgraph_->GetVertexSize();
}

int StateHyper::GetNumberOfEdges()
{
    return static_cast<int>(hgraph_->GetEdgeList()->size());
}

HyperEdge StateHyper::GetCurrentEdge()
{
    return (*hgraph_->GetEdgeList())[current_edge_];
}

vector<HyperEdge>* StateHyper::GetEdgeList()
{
    return hgraph_->GetEdgeList();
}

bool StateHyper::Find(int edge_number, int value)
{
    vector<HyperEdge>* edge_list = hgraph_->GetEdgeList();
    for (unsigned int i = edge_number + 1; i < edge_list->size(); ++i) {
        if ((*edge_list)[i].var_list[value]) {
            return true;
        }
    }
    return false;
}

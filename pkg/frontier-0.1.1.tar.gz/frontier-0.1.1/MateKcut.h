#ifndef MATEKCUT_H
#define MATEKCUT_H

#include "MateSForest.h"

//*************************************************************************************************
// StateKcut: アルゴリズム動作時の「状態」を表すクラス
class StateKcut : public State {
private:
    int max_cut_size_;
public:
    StateKcut(Graph* graph, int max_cut_size);
    Mate* CreateMate(bool is_terminal);

    int GetMaxCutSize();
};

//*************************************************************************************************
// MateKcut: mate を表すクラス
class MateKcut : public MateSForest {
private:
    int number_of_components_;
    int number_of_cuts_;
public:
    MateKcut(State* state);

    void Copy(Mate* mate, State* state);
    bool Equals(Mate* mate, State* state);
    uintx GetHashValue(State* state);

    void UpdateMate(State* state, int lo_or_hi);
    int CheckTerminateBefore(State* state, int lo_or_hi);
    int CheckTerminateAfter(State* state);
};

#endif // MATEKCUT_H

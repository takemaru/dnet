#include "MateKcut.h"

using namespace std;

//*************************************************************************************************
// StateKcut
StateKcut::StateKcut(Graph* graph, int max_cut_size) : State(graph), max_cut_size_(max_cut_size)
{
    // nothing
}

Mate* StateKcut::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateKcut(NULL);
    } else {
        return new MateKcut(this);
    }
}

int StateKcut::GetMaxCutSize()
{
    return max_cut_size_;
}

//*************************************************************************************************
// MateKcut
MateKcut::MateKcut(State* state) : MateSForest(state), number_of_components_(0), number_of_cuts_(0)
{
    // nothing
}

// 引数で与えた mate を自身にコピーする
void MateKcut::Copy(Mate* mate, State* state)
{
    MateSForest::Copy(mate, state);

    MateKcut* m = static_cast<MateKcut*>(mate);

    number_of_components_ = m->number_of_components_;
    number_of_cuts_ = m->number_of_cuts_;
}

// mate が「等価」かどうか判定する
bool MateKcut::Equals(Mate* mate, State* state)
{
    MateKcut* m = static_cast<MateKcut*>(mate);

    if (number_of_components_ != m->number_of_components_
        || number_of_cuts_ != m->number_of_cuts_) {
        return false;
    }
    return MateSForest::Equals(mate, state);
}

// ハッシュ値を取得
uintx MateKcut::GetHashValue(State* state)
{
    return MateSForest::GetHashValue(state) * 142624221901ll + number_of_components_ * 12452197ll
        + number_of_cuts_ * 105920193ll;
}

void MateKcut::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 0) { // Lo枝処理
        int c1 = mate_[edge.src];
        int c2 = mate_[edge.dest];

        int cmax = (c1 < c2 ? c2 : c1);
        int cmin = (c1 < c2 ? c1 : c2);

        for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
            if (mate_[i] == cmin) {
                mate_[i] = cmax;
            }
        }
    } else { // Hi枝処理
        ++number_of_cuts_;
    }

    // フロンティアから抜けるときの処理
    set<int>::iterator itor_l = state->GetLeavingIterator();
    set<int> isolating_set;
    while (itor_l != state->GetLeavingEnd()) {
        mate_t v = *itor_l;
        bool is_exist = false;
        set<int>::iterator itor_f = state->GetFrontierIterator();
        while (itor_f != state->GetFrontierEnd()) {
            if (mate_[v] == mate_[*itor_f]) {
                is_exist = true;
                break;
            }
            ++itor_f;
        }
        if (!is_exist) {
            if (isolating_set.count(mate_[v]) == 0) {
                isolating_set.insert(mate_[v]);
                ++number_of_components_;
            }
        }
        ++itor_l;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateKcut::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 1) {
        StateKcut* st = static_cast<StateKcut*>(state);
        if (number_of_cuts_ >= st->GetMaxCutSize()) {
            return 0;
        } else {
            return -1;
        }
    } else {
        return -1;
    }
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateKcut::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() == static_cast<int>(state->GetEdgeList()->size()) - 1) { // last
        if (number_of_components_ <= 1) {
            return 0;
        } else {
            return 1;
        }
    } else {
        if (number_of_components_ >= 1) {
            return 1;
        } else {
            return -1;
        }
    }
}

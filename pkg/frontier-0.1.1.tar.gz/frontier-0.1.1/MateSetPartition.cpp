#include "MateSetPartition.h"

using namespace std;

//*************************************************************************************************
// StateSetPartition
StateSetPartition::StateSetPartition(HyperGraph* graph) : StateHyper(graph)
{
    // nothing
}

Mate* StateSetPartition::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateSetPartition(NULL);
    } else {
        return new MateSetPartition(this);
    }
}

//*************************************************************************************************
// MateSetPartition
int MateSetPartition::GetMateBit(int pos)
{
    return (mate_[pos / (sizeof(intx) * 8)] >> (pos % (sizeof(intx) * 8))) & 1ull;
}

void MateSetPartition::SetMateBit(int pos, int v)
{
    mate_[pos / (sizeof(intx) * 8)] |= ((v & 1ull) << (pos % (sizeof(intx) * 8)));
}

MateSetPartition::MateSetPartition(State* state)
{
    if (state != NULL) {
        mate_ = new uintx[state->NUMBER_OF_VERTICES / (sizeof(intx) * 8) + 1];
    } else {
        mate_ = NULL;
    }
}

MateSetPartition::~MateSetPartition()
{
    if (mate_ != NULL) {
        delete[] mate_;
    }
}

// mate を初期化する（初期ZDDノード専用）
void MateSetPartition::Initialize(State* state)
{
    for (unsigned int i = 0; i < state->NUMBER_OF_VERTICES / (sizeof(intx) * 8) + 1; ++i) {
        mate_[i] = 0u;
    }
}

// 引数で与えた mate を自身にコピーする
void MateSetPartition::Copy(Mate* mate, State* state)
{
    MateSetPartition* m = static_cast<MateSetPartition*>(mate);

    for (unsigned int i = 0; i < state->NUMBER_OF_VERTICES / (sizeof(intx) * 8) + 1; ++i) {
        mate_[i] = m->mate_[i];
    }
}

// mate が「等価」かどうか判定する
bool MateSetPartition::Equals(Mate* mate, State* state)
{
    MateSetPartition* m = static_cast<MateSetPartition*>(mate);

    // フロンティアに含まれる各頂点についてmate値が同じかどうか判定
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        mate_t v = *itor;
        if (GetMateBit(v) != m->GetMateBit(v)) {
            return false;
        }
        ++itor;
    }
    return true;
}

// ハッシュ値を取得
uintx MateSetPartition::GetHashValue(State* state)
{
    uintx hash_value = 0;

    // フロンティアに含まれる各頂点についてmate値が同じかどうか判定
    set<int>::iterator itor = state->GetFrontierIterator();
    while (itor != state->GetFrontierEnd()) {
        hash_value = hash_value * 15284356289ll + GetMateBit(*itor) + 1;
        ++itor;
    }
    return hash_value;
}

void MateSetPartition::UpdateMate(State* state, int lo_or_hi)
{
    StateSetPartition* st = static_cast<StateSetPartition*>(state);
    HyperEdge edge = st->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理のときのみ更新
        for (int i = 0; i < state->NUMBER_OF_VERTICES; ++i) {
            if (edge.var_list[i]) {
                if (GetMateBit(i) == 0) {
                    SetMateBit(i, 1);
                }
            }
        }
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateSetPartition::CheckTerminateBefore(State* state, int lo_or_hi)
{
    StateSetPartition* st = static_cast<StateSetPartition*>(state);
    HyperEdge edge = st->GetCurrentEdge();

    if (lo_or_hi == 1) { // Lo枝の処理のときはチェックの必要がない
        for (int i = 0; i < state->NUMBER_OF_VERTICES; ++i) {
            if (edge.var_list[i]) {
                if (GetMateBit(i) == 1) {
                    return 0;
                }
            }
        }
    }

    set<int>::iterator itor = state->GetLeavingIterator();
    while (itor != state->GetLeavingEnd()) {
        if (GetMateBit(*itor) == 0) {
            if (lo_or_hi == 0) {
                return 0;
            } else {
                if (!edge.var_list[*itor]) {
                    return 0;
                }
            }
        }
        ++itor;
    }
    return -1;
}

// フロンティアから去るとき、0終端に行かないかをチェック
// 0終端に行くなら 0 を返す。それ以外の場合は -1 を返す
int MateSetPartition::CheckTerminateAfter(State* state)
{
    if (state->GetCurrentEdgeNumber() >= state->GetNumberOfEdges() - 1) {
        return 1;
    } else {
        return -1;
    }
}

#ifndef MATESTREE_H
#define MATESTREE_H

#include "MateSForest.h"

//*************************************************************************************************
// StateSTree: アルゴリズム動作時の「状態」を表すクラス
class StateSTree : public State {
public:
    StateSTree(Graph* graph);
    Mate* CreateMate(bool is_terminal);
};

//*************************************************************************************************
// MateSTree: mate を表すクラス
class MateSTree : public MateSForest {
public:
    MateSTree(State* state);
    int CheckTerminateAfter(State* state);
};

#endif // MATESTREE_H

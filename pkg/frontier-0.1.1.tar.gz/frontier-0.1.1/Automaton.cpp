#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstdarg>
#include <cstdio>

#include "Automaton.h"

using namespace std;

Automaton::Automaton(intx number_of_state, intx number_of_alphabet) : number_of_state_(number_of_state),
                                             number_of_alphabet_(number_of_alphabet)
{
    transition_list_ = new intx[number_of_state * number_of_alphabet];
    if (transition_list_ == NULL) {
        cerr << "can't allocate memory for transition_list" << endl;
        exit(1);
    }
    for (intx i = 0; i < number_of_state * number_of_alphabet; ++i) {
        transition_list_[i] = -1;
    }
    accept_list_ = new bool[number_of_state];
    if (accept_list_ == NULL) {
        cerr << "can't allocate memory for transition_list" << endl;
        exit(1);
    }
    for (intx i = 0; i < number_of_state; ++i) {
        accept_list_[i] = false;
    }
}

Automaton::~Automaton()
{
    delete accept_list_;
    delete transition_list_;
}

void Automaton::SetAccept(intx state_number, bool is_accept_state)
{
    accept_list_[state_number] = is_accept_state;
}

void Automaton::AddTrans(intx state_number, int character, intx dest)
{
    transition_list_[state_number * number_of_alphabet_ + character] = dest;
}

bool Automaton::Judge(intx initial_state, const vector<int>& sequence)
{
    intx state = initial_state;
    for (unsigned int i = 0; i < sequence.size(); ++i) {
        state = transition_list_[state * number_of_alphabet_ + sequence[i]];
        if (state < 0) {
            return false;
        }
    }
    return accept_list_[state];
}

// n: # of args
bool Automaton::Judge(intx initial_state, int n, ...)
{
    va_list ap;
    va_start(ap, n);

    vector<int> v_list;

    for (int i = 0; i < n; ++i) {
        v_list.push_back(va_arg(ap, int));
    }

    va_end(ap);

    /*for (int i = 0; i < v_list.size(); ++i) {
        cout << v_list[i] << " ";
    }
    cout << endl;*/

    return Judge(initial_state, v_list);
}

void Automaton::PrintForGraphviz()
{
    printf("digraph G {\n");
    //for (unsigned int i = 0; i < state_list_.size(); ++i) {
        //    AState* state = state_list_[i];
        //    if (state != NULL) {
        //        state->Print(i);
        //    }
    //}
    printf("}\n");
}

AutomatonManager::AutomatonManager(PseudoZDD* zdd) : zdd_(zdd), number_of_states_(0)
{
    // nothing
}

/*
void AutomatonManager::PutStateNumber()
{
    intx current_state_number = 2;

    ZDDNode::ZeroNode->SetStateNumber(0);
    ZDDNode::OneNode->SetStateNumber(1);

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);

        for (int j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            if (node->GetStateNumber() < 0) { // まだ番号が振られていない
                if (PutNumber(node, current_state_number)) { // 番号付けに成功した
                    ++current_state_number;
                }
            }
        }
    }
    max_state_number_ = current_state_number - 1;
    }*/

 /*
void AutomatonManager::PrintZDD()
{
    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        cout << "#" << (i + 1) << endl;
        for (int j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            cout << node->GetSerial() << "!" << node->GetStateNumber() << ":"
                 << node->GetLoNode()->GetSerial() << ","
                 << node->GetHiNode()->GetSerial() << endl;
        }
    }
}
 */
void AutomatonManager::PrintForGraphviz()
{
    /*printf("digraph pzdd {\n");
    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (int j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            printf("\tn" PERCENT_X " [label = \"" PERCENT_X
                   ": S" PERCENT_D "\", peripheries = %d];\n", node->GetSerial(), node->GetSerial(),
                   node->GetStateNumber(), (accept_state_set_.count(node->GetStateNumber()) == 1 ? 2 : 1));
            if (node->GetLoNode() != ZDDNode::ZeroNode) {
                printf("\tn" PERCENT_X " -> n" PERCENT_X " [style = dotted];\n", node->GetSerial(),
                   node->GetLoNode()->GetSerial());
            }
            if (node->GetHiNode() != ZDDNode::ZeroNode) {
                printf("\tn" PERCENT_X " -> n" PERCENT_X ";\n", node->GetSerial(),
                   node->GetHiNode()->GetSerial());
            }
        }
        printf("\t{rank = same;");
        for (int j = 0; j < node_set->GetSize(); ++j) {
            printf("n" PERCENT_X ";", node_set->Get(j)->GetSerial());
        }
        printf("}\n");
    }
    printf("}\n");*/
    }

/*Automaton* AutomatonManager::MakeAutomaton()
{
    Automaton* am = new Automaton();

    for (unsigned int i = 0; i <= max_state_number_; ++i) {
        if (i == 0 || i == 1) {
            am->AddState(i, (i == 1)); // i == 0 は拒否状態、i == 1 は受理状態
        } else {
            am->AddState(i, accept_state_set_.count(i) >= 1);
        }
    }

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            if (node->GetHiNode() != ZDDNode::ZeroNode) {
                am->AddTrans(node->GetStateNumber(), i, node->GetHiNode()->GetStateNumber());
            }
            //printf("%d -> %d: %d\n", node->GetStateNumber(), node->GetHiNode()->GetStateNumber(), i);
        }
    }
    return am;
}

Automaton* AutomatonManager::MakeAutomaton2()
{
    Automaton* am = new Automaton();

    int count = 2;
    //for (int i = 0; i < zdd_->GetHeight(); ++i) {
    //    ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
    //    count += node_set->GetSize();
    //}

    //for (int i = 0; i <= count; ++i) {
    //   if (i == 0 || i == 1) {
    //        am->AddState(i, (i == 1)); // i == 0 は拒否状態、i == 1 は受理状態
    //    } else {
    //        am->AddState(i, accept_state_set_.count(i) >= 1);
    //    }
    //}
    am->AddState(0, false);
    am->AddState(1, true);

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            ZDDNode* n2 = node;
            for (; n2 != ZDDNode::ZeroNode && n2 != ZDDNode::OneNode; n2 = n2->GetLoNode()) {
                // nothing
            }
            if (n2 == ZDDNode::OneNode) {
                am->AddState(count, true);
            } else {
                am->AddState(count, false);
            }
            ++count;
        }
    }

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            int var = i;
            ZDDNode* n2 = node;
            for (; n2 != ZDDNode::ZeroNode && n2 != ZDDNode::OneNode; n2 = n2->GetLoNode()) {
                if (n2->GetHiNode()->GetSerial() > 0) {
                    am->AddTrans(node->GetSerial(), var, n2->GetHiNode()->GetSerial());
                }
                //printf("%d -> %d: %d\n", node->GetSerial(), var, n2->GetHiNode()->GetSerial());
                ++var;
            }

            //if (node->GetHiNode() != ZDDNode::ZeroNode) {
            //    am->AddTrans(node->GetStateNumber(), i, node->GetHiNode()->GetStateNumber());
            //}
            //printf("%d -> %d: %d\n", node->GetStateNumber(), node->GetHiNode()->GetStateNumber(), i);
        }
    }
    return am;
    }*/

Automaton* AutomatonManager::MakeAutomaton3()
{
    vector<bool> accept_list;
    vector<bool> reachable_list;
    vector<bool> pointed_list;
    vector<vector<pair<int, intx> > > trans_list;
    vector<intx>& lo_list = *zdd_->GetLoNodeList();
    vector<intx>& hi_list = *zdd_->GetHiNodeList();
    vector<intx>& level_first_list = *zdd_->GetLevelFirstList();

    accept_list.resize(lo_list.size());
    reachable_list.resize(lo_list.size());
    trans_list.resize(lo_list.size());
    pointed_list.resize(lo_list.size());

    accept_list[0] = false;
    reachable_list[0] = false;
    accept_list[1] = true;
    reachable_list[1] = true;

    pointed_list[2] = true;


    Automaton* am = new Automaton(lo_list.size(), level_first_list.size() - 1);
    if (am == NULL) {
        cerr << "can't allocate memory for automaton" << endl;
        exit(1);
    }

    am->SetAccept(0, false);
    am->SetAccept(1, true);
    number_of_states_ += 2;

    for (int i = static_cast<int>(level_first_list.size()) - 2; i >= 0; --i) {
        for (intx j = level_first_list[i]; j < level_first_list[i + 1]; ++j) {
            accept_list[j] = accept_list[lo_list[j]];
            reachable_list[j] = reachable_list[lo_list[j]] || reachable_list[hi_list[j]];
            trans_list[j] = trans_list[lo_list[j]]; // copy
            if (hi_list[j] != 0) {
                trans_list[j].push_back(pair<int, intx>(i, hi_list[j]));
                pointed_list[hi_list[j]] = true;
            }
        }
    }

    for (unsigned int i = 0; i < level_first_list.size() - 1; ++i) {
        for (intx j = level_first_list[i]; j < level_first_list[i + 1]; ++j) {
            if (pointed_list[j] && reachable_list[j]) {
                am->SetAccept(j, accept_list[j]);
                ++number_of_states_;
            }
        }
    }
    for (unsigned int i = 0; i < level_first_list.size() - 1; ++i) {
        for (intx j = level_first_list[i]; j < level_first_list[i + 1]; ++j) {
            if (pointed_list[j] && reachable_list[j]) {
                for (unsigned int k = 0; k < trans_list[j].size(); ++k) {
                    if (reachable_list[trans_list[j][k].second]) {
                        am->AddTrans(j, trans_list[j][k].first, trans_list[j][k].second);
                    }
                }
            }
        }
    }


    /*ZDDNode::ZeroNode->is_accept_ = false;
    ZDDNode::ZeroNode->is_reachable_ = false;
    ZDDNode::OneNode->is_accept_ = true;
    ZDDNode::OneNode->is_reachable_ = true;
    zdd_->GetZDDNodeSet(0)->Get(0)->pointed_flag_ = true;

    for (int i = zdd_->GetHeight() - 1; i >= 0; --i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            node->is_accept_ = node->GetLoNode()->is_accept_;
            node->is_reachable_ = node->GetLoNode()->is_reachable_ || node->GetHiNode()->is_reachable_;
            node->trans_list_ = node->GetLoNode()->trans_list_; // copy
            if (node->GetHiNode() != ZDDNode::ZeroNode) {
                node->trans_list_.push_back(pair<intx, ZDDNode*>(i, node->GetHiNode()));
                node->GetHiNode()->pointed_flag_ = true;
            }
        }
    }

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            if (node->pointed_flag_ && node->is_reachable_) {
                am->SetAccept(node->GetSerial(), node->is_accept_);
            }
        }
    }

    for (int i = 0; i < zdd_->GetHeight(); ++i) {
        ZDDNodeSet* node_set = zdd_->GetZDDNodeSet(i);
        for (intx j = 0; j < node_set->GetSize(); ++j) {
            ZDDNode* node = node_set->Get(j);
            if (node->pointed_flag_ && node->is_reachable_) {
                for (unsigned int k = 0; k < node->trans_list_.size(); ++k){
                    if (node->trans_list_[k].second->is_reachable_) {
                        am->AddTrans(node->GetSerial(), node->trans_list_[k].first, node->trans_list_[k].second->GetSerial());
                    }
                }
            }
        }
        }*/

    return am;
}

/* private */ /*bool AutomatonManager::PutNumber(ZDDNode* node, intx current_state_number)
{
    ZDDNode* n2 = node;
    for (; n2 != ZDDNode::ZeroNode; n2 = n2->GetLoNode()) {
        if (n2->GetStateNumber() >= 0) { // 番号が既に振られている
            break;
        } else {
            n2->SetStateNumber(current_state_number);
        }
    }

    if (n2 == ZDDNode::ZeroNode) {
        return true;
    } else if (n2 == ZDDNode::OneNode) {
        accept_state_set_.insert(node->GetStateNumber());
        return true;
    } else { // 番号がコンフリクトした
        for (ZDDNode* n3 = node; n3 != n2; n3 = n3->GetLoNode()) {
            n3->SetStateNumber(n2->GetStateNumber());
        }
        //n2->SetStateNumber(n2->GetStateNumber() + 100); for debug
        return false;
    }
    }*/

intx AutomatonManager::GetNumberOfStates()
{
    return number_of_states_;
}

int testmain()
{
    Automaton am(5, 5);
    am.SetAccept(0, false);
    am.SetAccept(1, false);
    am.SetAccept(2, false);
    am.SetAccept(3, false);
    am.SetAccept(4, true);
    am.AddTrans(0, 1, 1);
    am.AddTrans(0, 2, 2);
    am.AddTrans(0, 3, 3);
    am.AddTrans(1, 2, 2);
    am.AddTrans(1, 3, 4);
    am.AddTrans(2, 3, 4);
    am.AddTrans(2, 4, 4);
    am.AddTrans(3, 4, 4);

    cout << am.Judge(0, 3, 1, 2, 3) << endl;
    cout << am.Judge(0, 4, 1, 2, 3, 4) << endl;
    cout << am.Judge(0, 2, 3, 4) << endl;
    cout << am.Judge(0, 2, 1, 2) << endl;
    
    return 0;
}


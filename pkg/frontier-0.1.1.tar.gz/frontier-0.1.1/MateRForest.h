#ifndef MATERFOREST_H
#define MATERFOREST_H

#include "MateSForest.h"
#include "RootManager.h"

//*************************************************************************************************
// StateRForest: アルゴリズム動作時の「状態」を表すクラス
class StateRForest : public State {
private:
    RootManager* root_mgr_;
public:
    StateRForest(Graph* graph);
    Mate* CreateMate(bool is_terminal);

    RootManager* GetRootManager();
    void SetRootManager(RootManager* root_mgr);
};

//*************************************************************************************************
// MateRForest: mate を表すクラス
class MateRForest : public MateSForest {
public:
    MateRForest(State* state);
    void Initialize(State* state);
    int CheckTerminateBefore(State* state, int lo_or_hi);
    int CheckTerminateAfter(State* state);
};

#endif // MATERFOREST_H

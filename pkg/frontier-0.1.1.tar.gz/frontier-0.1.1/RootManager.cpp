#include "RootManager.h"

using namespace std;

//*************************************************************************************************
// RootManager: 根を管理するクラス
void RootManager::Add(int v)
{
    source_list_.push_back(v);
}

int RootManager::Get(int index)
{
    return source_list_[index];
}

int RootManager::GetSize()
{
    return static_cast<int>(source_list_.size());
}

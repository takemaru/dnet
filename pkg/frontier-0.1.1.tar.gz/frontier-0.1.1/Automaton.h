#ifndef AUTOMATON_H
#define AUTOMATON_H

#include <vector>
#include <set>

#include "PseudoZDD.h"

class Automaton {
private:
    intx number_of_state_;
    intx number_of_alphabet_;
    intx* transition_list_;
    bool* accept_list_;
public:
    Automaton(intx number_of_state, intx number_of_alphabet);
    ~Automaton();
    void SetAccept(intx state_number, bool is_accept_state);
    void AddTrans(intx state_number, int character, intx dest);
    bool Judge(intx initial_state, const std::vector<int>& sequence);
    bool Judge(intx initial_state, int n, ...);
    void PrintForGraphviz();
};

class AutomatonManager {
private:
    PseudoZDD* zdd_;
    intx max_state_number_;
    //std::set<int> accept_state_set_;
    intx number_of_states_;

public:
    AutomatonManager(PseudoZDD* zdd);
    void PutStateNumber();
    void PrintZDD();
    void PrintForGraphviz();
    Automaton* MakeAutomaton();
    Automaton* MakeAutomaton2();
    Automaton* MakeAutomaton3();
    intx GetNumberOfStates();

private:
    bool PutNumber(ZDDNode* node, intx current_state_number);
};

#endif // AUTOMATON_H

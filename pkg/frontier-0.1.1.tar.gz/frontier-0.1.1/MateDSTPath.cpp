#include "MateDSTPath.h"

using namespace std;

//*************************************************************************************************
// StateDSTPath
StateDSTPath::StateDSTPath(Graph* graph) : StateSTPath(graph)
{
    // nothing
}

Mate* StateDSTPath::CreateMate(bool is_terminal)
{
    if (is_terminal) {
        return new MateDSTPath(NULL);
    } else {
        return new MateDSTPath(this);
    }
}

//*************************************************************************************************
// MateDSTPath
MateDSTPath::MateDSTPath(State* state) : MateSTPath(state)
{
    // nothing
}

//MateDSTPath::~MateDSTPath()
//{
//    //MateSTPath::~MateSTPath();
//}

// mate を初期化する（初期ZDDノード専用）
void MateDSTPath::Initialize(State* state)
{
    StateDSTPath* st = static_cast<StateDSTPath*>(state);
    int sv = st->GetStartVertex();
    int ev = st->GetEndVertex();

    for (int i = 1; i <= state->NUMBER_OF_VERTICES; ++i) {
        mate_[i] = i;
    }
    if (!st->IsCycle()) { // パス列挙の場合
        mate_[sv] = -ev;
        mate_[ev] = sv;
    }
}

void MateDSTPath::UpdateMate(State* state, int lo_or_hi)
{
    Edge edge = state->GetCurrentEdge();

    if (lo_or_hi == 1) { // Hi枝処理のときのみ更新
        int sm = mate_[edge.src];
        int dm = mate_[edge.dest];

        if (sm == edge.src) { // 始点が孤立点
            sm = -edge.src;
        }

        // 枝をつないだときの mate の更新
        // （↓の計算順を変更すると正しく動作しないことに注意）
        mate_[edge.src] = 0;
        mate_[edge.dest] = 0;
        mate_[-sm] = dm;
        mate_[dm] = sm;
    }
}

// 枝を張るとき、0終端または1終端に行くかチェック
// 0終端に行くとき0を、1終端に行くとき1を、それ以外のときは-1を返す。
// lo_or_hi が 0 なら Lo枝、1 なら Hi枝に関する処理のときのチェック
int MateDSTPath::CheckTerminateBefore(State* state, int lo_or_hi)
{
    if (lo_or_hi == 0) { // Lo枝の処理のときはチェックの必要がない
        return -1;
    } else {
        Edge edge = state->GetCurrentEdge();

        if (mate_[edge.src] == 0 || mate_[edge.dest] == 0) { // 分岐が発生した
            return 0;
        } else if (mate_[edge.src] != edge.src && mate_[edge.src] > 0) { // 始点から2本以上枝が出て行く
            return 0;
        } else if (mate_[edge.dest] < 0) { // 終点から2本以上枝が入ってくる
            return 0;
        } else if (mate_[edge.src] == -edge.dest) { // サイクルが完成した
            StateDSTPath* st = static_cast<StateDSTPath*>(state);            
            // フロンティアに属する残りの頂点についてチェック
            set<int>::iterator itor = state->GetFrontierIterator();
            while (itor != state->GetFrontierEnd()) {
                mate_t v = *itor;
                // 張った枝の始点と終点はチェックから除外
                if (v != edge.src && v != edge.dest) {
                    if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                        if (mate_[v] != 0) {
                            return 0;
                        }
                    } else {
                        // パスの途中でなく、孤立した点でもない場合、
                        // 不完全なパスができることになるので、0を返す
                        if (mate_[v] != 0 && mate_[v] != v) {
                            return 0;
                        }
                    }
                }
                ++itor;
            }
            if (st->IsHamilton()) { // ハミルトンパス、サイクルの場合
                if (st->IsExistUnprocessedVertex()) {
                    return 0;
                }
            }
            return 1;
        } else {
            return -1;
        }
    }
}

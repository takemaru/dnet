#include <cstdlib>
#include "HyperGraph.h"

using namespace std;

HyperGraph::HyperGraph() : number_of_vertices_(0)
{
    // nothing
}

void HyperGraph::Load(istream& ist)
{
    bool is_first = true;
    string s;
    while (std::getline(ist, s)) {
        if (s == "") {
            break;
        }
        HyperEdge edge;
        istringstream iss(s);
        int x;
        iss >> x; // ignore the first number
        while (iss >> x) {
            if (x != 0) {
                edge.var_list.push_back(true);
            } else {
                edge.var_list.push_back(false);
            }
        }
        if (is_first) {
            is_first = false;
            number_of_vertices_ = edge.var_list.size();
        } else {
            if (static_cast<int>(edge.var_list.size()) != number_of_vertices_) {
                cerr << "input error!" << endl;
                exit(1);
            }
        }
        edge_list_.push_back(edge);
    }
}

void HyperGraph::LoadC(istream&)
{
    //string s;
    //std::getline(ist, s);
    //istringstream issx(s);
    //issx >> number_of_vertices_;
    //
    //while (std::getline(ist, s)) {
    //    istringstream iss(s);
    //    int src, dest;
    //    iss >> src >> dest;
    //    edge_list_.push_back(HyperEdge(src, dest));
    //}
}

void HyperGraph::Print()
{
    for (unsigned int i = 0; i < edge_list_.size(); ++i) {
        for (unsigned int j = 0; j < edge_list_[i].var_list.size(); ++j) {
            cout << (edge_list_[i].var_list[j] ? "1" : "0") << " ";
        }
        cout << endl;
    }
}

vector<HyperEdge>* HyperGraph::GetEdgeList()
{
    return &edge_list_;
}

int HyperGraph::GetVertexSize()
{
    return number_of_vertices_;
}

/*********************************************
 * SeqBDD+ Class (SAPPORO-1.42) - Header     *
 * (C) Shin-ichi MINATO  (May 1, 2011)       *
 *********************************************/

class SeqBDD;
class SeqBDDV;

#ifndef _SeqBDD_
#define _SeqBDD_

#include "ZBDD.h"

extern SeqBDD operator&(const SeqBDD&, const SeqBDD&);
extern SeqBDD operator+(const SeqBDD&, const SeqBDD&);
extern SeqBDD operator-(const SeqBDD&, const SeqBDD&);
extern SeqBDD operator*(const SeqBDD&, const SeqBDD&);
//extern SeqBDD operator/(const SeqBDD&, const SeqBDD&);
//extern SeqBDD operator%(const SeqBDD&, const SeqBDD&);
extern int operator==(const SeqBDD&, const SeqBDD&);
extern int operator!=(const SeqBDD&, const SeqBDD&);
extern SeqBDD SeqBDD_Import(FILE *strm = stdin);
extern SeqBDD BDD_CacheSeqBDD(char, bddword, bddword);
extern SeqBDD SeqBDD_ID(bddword);
//extern SeqBDD SeqBDD_Meet(const SeqBDD&, const SeqBDD&);

class SeqBDD
{
  ZBDD _zbdd;
public:
  SeqBDD(void);
  SeqBDD(int);
  SeqBDD(const SeqBDD&);
  SeqBDD(const ZBDD&);

  ~SeqBDD(void);

  SeqBDD& operator=(const SeqBDD&);
  SeqBDD operator&=(const SeqBDD&);
  SeqBDD operator+=(const SeqBDD&);
  SeqBDD operator-=(const SeqBDD&);
  SeqBDD operator*=(const SeqBDD&);
 // SeqBDD operator/=(const SeqBDD&);
 // SeqBDD operator%=(const SeqBDD&);

  SeqBDD OffSet(int);
  SeqBDD OnSet(int);
  SeqBDD OnSet0(int);
  SeqBDD Push(int);

  int Top(void);
  ZBDD GetZBDD(void);

  bddword Size(void);
  bddword Card(void);
  bddword Lit(void);
  bddword Len(void);
  void Export(FILE *strm = stdout);
  void PrintSeq(void);
  void XPrint(void);
  void Print(void);

  friend SeqBDD operator&(const SeqBDD&, const SeqBDD&);
  friend SeqBDD operator+(const SeqBDD&, const SeqBDD&);
  friend SeqBDD operator-(const SeqBDD&, const SeqBDD&);
  friend SeqBDD operator*(const SeqBDD&, const SeqBDD&);
//  friend SeqBDD operator/(const SeqBDD&, const SeqBDD&);
//  friend SeqBDD operator%(const SeqBDD&, const SeqBDD&);
  friend SeqBDD BDD_CacheSeqBDD(char, bddword, bddword);
  friend int operator==(const SeqBDD&, const SeqBDD&);
  friend SeqBDD SeqBDD_ID(bddword);
};

#endif // _SeqBDD_

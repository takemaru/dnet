/************************************************
 * PiDD class (SAPPORO-1.5) - Header            *
 * (C) Shin-ichi MINATO  (Jul. 3, 2011)         *
 ************************************************/

class PiDD;

#ifndef _PiDD_
#define _PiDD_

#include "ZBDD.h"

class PiDD;

#define PiDD_MaxVar 254

extern int PiDD_NewVar(void);
extern int PiDD_VarUsed(void);

extern PiDD operator&(const PiDD&, const PiDD&);
extern PiDD operator+(const PiDD&, const PiDD&);
extern PiDD operator-(const PiDD&, const PiDD&);
extern int operator==(const PiDD&, const PiDD&);
extern int operator!=(const PiDD&, const PiDD&);

extern PiDD operator*(const PiDD&, const PiDD&);
extern PiDD operator/(const PiDD&, const PiDD&);
extern PiDD operator%(const PiDD&, const PiDD&);

class PiDD
{
  ZBDD _zbdd;
public:
  PiDD(void);
  PiDD(int);
  PiDD(const PiDD&);
  PiDD(const ZBDD&);

  ~PiDD(void);

  PiDD& operator=(const PiDD&);
  PiDD operator&=(const PiDD&);
  PiDD operator+=(const PiDD&);
  PiDD operator-=(const PiDD&);
  PiDD operator*=(const PiDD&);
  PiDD operator/=(const PiDD&);
  PiDD operator%=(const PiDD&);
  PiDD Swap(int, int);
  PiDD Cofact(int, int);

  PiDD Odd(void);
  PiDD Even(void);
  PiDD SwapBound(int);

  int TopX(void);
  int TopY(void);
  int TopLev(void);
  bddword Size(void);
  bddword Card(void);
  ZBDD GetZBDD(void);
  
  void Print(void);
  void Enum(void);
  void Enum2(void);

  friend PiDD operator&(const PiDD&, const PiDD&);
  friend PiDD operator+(const PiDD&, const PiDD&);
  friend PiDD operator-(const PiDD&, const PiDD&);
  friend PiDD operator*(const PiDD&, const PiDD&);
  friend PiDD operator/(const PiDD&, const PiDD&);
  friend int operator==(const PiDD&, const PiDD&);
};

#endif // _PiDD_


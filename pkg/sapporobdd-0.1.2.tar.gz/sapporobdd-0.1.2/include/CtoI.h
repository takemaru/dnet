/******************************************
 * Combination-to-Integer function class  *
 * (SAPPORO-1.40) - Header                *
 * (C) Shin-ichi MINATO  (May 1, 2011)    *
 ******************************************/

class CtoI;

#ifndef _CtoI_
#define _CtoI_

#include "ZBDD.h"

extern int operator==(const CtoI&, const CtoI&);
extern int operator!=(const CtoI&, const CtoI&);

extern CtoI operator+(const CtoI&, const CtoI&);
extern CtoI operator-(const CtoI&, const CtoI&);
extern CtoI operator*(const CtoI&, const CtoI&);
extern CtoI operator/(const CtoI&, const CtoI&);
extern CtoI operator%(const CtoI&, const CtoI&);

extern CtoI CtoI_Null(void);

extern CtoI CtoI_ITE(CtoI, CtoI, CtoI);

extern CtoI CtoI_EQ(CtoI, CtoI);
extern CtoI CtoI_NE(CtoI, CtoI);
extern CtoI CtoI_GT(CtoI, CtoI);
extern CtoI CtoI_GE(CtoI, CtoI);
extern CtoI CtoI_LT(CtoI, CtoI);
extern CtoI CtoI_LE(CtoI, CtoI);

extern CtoI CtoI_Max(CtoI, CtoI);
extern CtoI CtoI_Min(CtoI, CtoI);

extern CtoI CtoI_atoi(char *);

extern CtoI CtoI_Intsec(CtoI, CtoI);
extern CtoI CtoI_Union(CtoI, CtoI);
extern CtoI CtoI_Diff(CtoI, CtoI);

extern int CtoI_Lcm1(char *, char *, int, int);
extern CtoI CtoI_Lcm2(void);
extern int CtoI_LcmItems(void);
extern int CtoI_LcmPerm(int);
extern CtoI CtoI_LcmA(char *, char *, int);
extern CtoI CtoI_LcmC(char *, char *, int);
extern CtoI CtoI_LcmM(char *, char *, int);
extern CtoI CtoI_LcmAV(char *, char *, int);
extern CtoI CtoI_LcmCV(char *, char *, int);
extern CtoI CtoI_LcmMV(char *, char *, int);

extern CtoI CtoI_Meet(CtoI, CtoI);

class CtoI
{
  ZBDD _zbdd;

public:
  CtoI(void);
  CtoI(const CtoI&);
  CtoI(const ZBDD&);
  CtoI(int);
  ~CtoI(void);

  CtoI& operator=(const CtoI&);

  int Top(void);
  int TopItem(void);
  int TopDigit(void);
  int IsBool(void);
  int IsConst(void);

  CtoI AffixVar(int);
  CtoI Factor0(int);
  CtoI Factor1(int);

  CtoI FilterThen(CtoI);
  CtoI FilterElse(CtoI);

  CtoI FilterRestrict(CtoI);
  CtoI FilterPermit(CtoI);
  CtoI FilterPermitSym(int);
  CtoI Support(void);

  CtoI NonZero(void);
  CtoI Digit(int);
  CtoI ConstTerm();

  CtoI EQ_Const(CtoI);
  CtoI NE_Const(CtoI);
  CtoI GT_Const(CtoI);
  CtoI GE_Const(CtoI);
  CtoI LT_Const(CtoI);
  CtoI LE_Const(CtoI);

  CtoI MaxVal(void);
  CtoI MinVal(void);

  CtoI CountTerms(void);
  CtoI TotalVal(void);
  CtoI TotalValItems(void);

  ZBDD GetZBDD(void);

  CtoI Abs(void);
  CtoI Sign(void);
  CtoI operator-(void);

  CtoI TimesSysVar(int);
  CtoI DivBySysVar(int);
  CtoI ShiftDigit(int);

  CtoI operator+=(const CtoI&);
  CtoI operator-=(const CtoI&);
  CtoI operator*=(const CtoI&);
  CtoI operator/=(const CtoI&);
  CtoI operator%=(const CtoI&);

  bddword Size(void);

  int GetInt(void);

  int StrNum10(char *);
  int StrNum16(char *);

  int PutForm(void);
  void Print(void);

  void XPrint(void);
  void XPrint0(void);

  CtoI ReduceItems(CtoI);
  CtoI FreqPatA(int);
  CtoI FreqPatAV(int);
  CtoI FreqPatM(int);
  CtoI FreqPatC(int);

  CtoI FreqPatA2(int);

//  CtoI FilterClosed(CtoI);
//  CtoI FreqPatCV(int);

  friend int operator==(const CtoI&, const CtoI&);
  friend CtoI operator*(const CtoI&, const CtoI&);
  friend CtoI operator/(const CtoI&, const CtoI&);
  friend CtoI CtoI_Intsec(CtoI, CtoI);
  friend CtoI CtoI_Union(CtoI, CtoI);
  friend CtoI CtoI_Diff(CtoI, CtoI);
  friend CtoI CtoI_Meet(CtoI, CtoI);
};

#endif // _CtoI_


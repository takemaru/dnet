/****************************************
 * CtoI Class (SAPPORO-1.21)            *
 * (Graphic methods)                    *
 * (C) Shin-ichi MINATO (Feb. 18, 2009) *
 ****************************************/

#include "CtoI.h"

extern "C"
{
	extern void bddgraph(...);
	extern void bddvgraph(...);
	extern void bddgraph0(...);
	extern void bddvgraph0(...);
}

void CtoI::XPrint()
{
	int len = TopDigit() + 1;
	bddword* bddv = new bddword[len];
	for(int i=0; i<len; i++) bddv[i] = Digit(i).GetZBDD().GetID(); 
	bddvgraph(bddv, len);
	delete[] bddv;
}

void CtoI::XPrint0()
{
	int len = TopDigit() + 1;
	bddword* bddv = new bddword[len];
	for(int i=0; i<len; i++) bddv[i] = Digit(i).GetZBDD().GetID(); 
	bddvgraph0(bddv, len);
	delete[] bddv;
}


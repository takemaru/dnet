#define TRUE  1
#define FALSE 0
#define EMPTY -1

#define NORMAL   0x00000000
#define NEGATIV  0x00000001
#define EXCHANGE 0x00000002

/* for further expanded edge attribute, name it as 0x4, 0x8, 0x10 ... */

extern int	edgemode;	/* 0:Nomal 1:Out-Inv 2:Ont&In-Inv */


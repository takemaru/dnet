#ifndef FUKASHIGI_H__
#define FUKASHIGI_H__

#include <ctype.h>
#include <unistd.h>
#include <string.h>

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>

#include <BDD.h>
#include <ZBDD.h>

typedef struct {
    char type;
    int size;
} output_t;

extern bool is_bdd;
extern int n_vars;
extern ZBDD* vars;

void init();

BDD bdd_read(char* fname);
BDD bdd_calc(int argc, char** argv);
void bdd_output(BDD f, output_t out);

ZBDD zdd_read(char* fname);
ZBDD zdd_calc(int argc, char** argv);
void zdd_output(ZBDD f, output_t out);

inline bool is_digit(string s) {
    return s.find_first_not_of("0123456789") == string::npos;
}

inline int bdd_v(int v) {
    return n_vars + 1 - v;
}

inline bool zdd_is_terminal(ZBDD f) {
    return f.Top() == 0;
}

inline bool zdd_is_top_terminal(ZBDD f) {
    ZBDD bot(0);
    if (zdd_is_terminal(f))
        return f == bot ? false : true;
    else
        return false;
}

inline int zdd_v(int v) {
    return v - BDDV_SysVarTop;
}

#endif /* FUKASHIGI_H__ */


#include "fukashigi.h"

bool is_bdd = false;
int n_vars = 0;
ZBDD* vars;

output_t parse_output_type(char* arg) {
    output_t t;
    if (isdigit(arg[0])) { // sample size
        t.type = 's';
        t.size = atoi(arg);
    }
    else {
        t.type = tolower(arg[0]);
        t.size = 0;
    }
    return t;
}

void print_usage(string bin) {
    cout << "usage: " << bin << " [-b] -n var_number -t output_type file_and_operand ..." << endl;
    exit(64);
}

int main(int argc, char *argv[]) {
    int ch;
    output_t out;

    while ((ch = getopt(argc, argv, "bn:t:")) != -1) {
        char* p;
        if (ch == 'b')
            is_bdd = true;
        else if (ch == 'n')
            n_vars = atoi(optarg);
        else if (ch == 't')
            out = parse_output_type(optarg);
        else
            print_usage(argv[0]);
    }

    assert(n_vars > 0);

    init();

    argc -= optind;
    argv += optind;

    if (is_bdd) {
        BDD f = bdd_calc(argc, argv);
        bdd_output(f, out);
    }
    else {
        ZBDD f = zdd_calc(argc, argv);
        zdd_output(f, out);
    }

    return 0;
}

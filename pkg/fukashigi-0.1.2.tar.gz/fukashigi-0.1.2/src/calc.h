#ifndef CALC_H__
#define CALC_H__

#include <ZBDD.h>

ZBDD calc(int argc, char** argv);

#endif /* CALC_H__ */

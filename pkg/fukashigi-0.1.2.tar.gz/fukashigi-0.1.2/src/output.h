#ifndef OUTPUT_H__
#define OUTPUT_H__

#include <ZBDD.h>

typedef struct {
    char type;
    int size;
} output_t;

void output(ZBDD f, output_t out);

#endif /* OUTPUT_H__ */

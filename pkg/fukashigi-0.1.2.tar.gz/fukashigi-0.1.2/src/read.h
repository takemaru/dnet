#ifndef READ_H__
#define READ_H__

#include <ZBDD.h>

ZBDD read(char* fname);

#endif /* READ_H__ */

#include <cassert>
#include <map>
#include <string>

#include "read.h"
#include "util.h"

extern ZBDD* vars;

inline bool is_unitary_operator(string s) {
    return s == "~" || s == "#" || s == "<" || s == ">" || is_digit(s);
}

inline bool is_binary_operator(string s) {
    return s == "&" || s == "+" || s == "|" || s == "-" || s == "\\" || s == "/" || s == "%";
}

ZBDD _not(ZBDD f) {
    assert(! "not supported");
}

ZBDD minimal(ZBDD f) {
    assert(! "not supported");
}

ZBDD maximal(ZBDD f) {
    assert(! "not supported");
}

inline ZBDD l(ZBDD f) {
    return f.OffSet(f.Top());
}

inline ZBDD h(ZBDD f) {
    return f.OnSet0(f.Top());
}

inline int v(ZBDD f) { // gets the top varible
    return is_terminal(f) ? BDD_MaxVar : fix_v(f.Top());
}

pair<bddword, bddword> key(ZBDD f, ZBDD g) {
    return make_pair(f.GetID(), g.GetID());
}

ZBDD zuniq(int v, ZBDD l, ZBDD h) {
    return l + vars[v] * h;
}

ZBDD zuniq(int v, pair<bddword, bddword> k) {
    return zuniq(v, ZBDD_ID(k.first), ZBDD_ID(k.second));
}

map< pair<bddword, bddword>, ZBDD> nonsup_cache;

ZBDD nonsup(ZBDD f, ZBDD g) {
    int fv = v(f);
    int gv = v(g);

    if (g == ZBDD(0)) {
        return f;
    }
    else if (f == ZBDD(0) || g == ZBDD(1) || f == g) {
        return ZBDD(0);
    }
    else if (fv > gv) {
        return nonsup(f, l(g));
    }

    map< pair<bddword, bddword>, ZBDD>::iterator i
        = nonsup_cache.find(key(f, g));
    if (i != nonsup_cache.end()) {
        return i->second;
    }
    else if (fv < gv) {
        pair<bddword, bddword> k = key(nonsup(l(f), g), nonsup(h(f), g));
        return nonsup_cache[k] = zuniq(fv, k);
    }
    else if (fv == gv) {
        pair<bddword, bddword> k
            = key(nonsup(l(f), l(g)), nonsup(h(f), h(g)) & nonsup(h(f), l(g)));
        return nonsup_cache[k] = zuniq(fv, k);
    }

    cerr << "error" << endl;
    exit(1);
    return ZBDD(0);
}

map<bddword, ZBDD> minhit_cache;

// XXX Knuth's MINHIT, which will be replaced by Toda's algorithm
ZBDD hit(ZBDD f) {
    if (f == ZBDD(0)) {
        return ZBDD(1);
    }
    else if (f == ZBDD(1)) {
        return ZBDD(0);
    }

    map<bddword, ZBDD>::iterator i = minhit_cache.find(f.GetID());
    if (i != minhit_cache.end()) {
        return i->second;
    }
    else {
        return minhit_cache[f.GetID()]
            = zuniq(v(f), hit(l(f) + h(f)), nonsup(hit(l(f)), hit(l(f) + h(f))));
    }
}

ZBDD combination_size(ZBDD f) {
    assert(! "not supported");
}

ZBDD unitary_operation(string op, ZBDD f) {
    return op == "~" ? _not(f)
         : op == "<" ? minimal(f)
         : op == ">" ? maximal(f)
         : op == "#" ? hit(f)
         :             combination_size(f);
}

ZBDD binary_operation(string op, ZBDD f, ZBDD g) {
    if (op == "&")
        return f & g;
    else if (op == "+" || op == "|")
        return f + g;
    else if (op == "-" || op == "\\")
        return f - g;
    else if (op == "/")
        return f / g;
    else if (op == "%")
        return f % g;
    else
        assert(! "not supported");
}

ZBDD calc(int argc, char** argv) {
    ZBDD f;
    string b_op = "";
    for (int i = 0; i < argc; i++) {
        if (is_binary_operator(argv[i]))
            b_op = argv[i++];
        assert(! is_binary_operator(argv[i]));
        int j = i;
        while (j < argc && ! is_binary_operator(argv[j]))
            j++;
        int k = i;
        i = --j;
        assert(! is_unitary_operator(argv[j]));
        ZBDD g = read(argv[j]);
        while (k < j)
            g = unitary_operation(argv[--j], g);
        f = b_op != "" ? binary_operation(b_op, f, g) : g;
    }
    return f;
}

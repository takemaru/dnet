#ifndef INIT_H__
#define INIT_H__

void init();

#endif /* INIT_H__ */

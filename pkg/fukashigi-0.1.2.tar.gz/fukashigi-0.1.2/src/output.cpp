#include <cstdlib>
#include <map>
#include <set>
#include <vector>

#include <CtoI.h>

#include "output.h"
#include "util.h"

void cardinality(ZBDD f) {
    CtoI ct(f);
    char buf[1024];
    ct.CountTerms().StrNum10(buf);
    cout << buf << endl;
}

void enumerate(ZBDD f, vector<int>& stack) {
    if (is_terminal(f)) {
        if (is_top_terminal(f)) {
            for (int i = 0; i <= (int) stack.size() - 1; i++)
                cout << fix_v(stack[i]) << ' ';
            cout << endl;
        }
        return;
    }
    int v = f.Top();
    stack.push_back(v);
    enumerate(f.OnSet0(v), stack);
    stack.pop_back();
    enumerate(f.OffSet(v), stack);
}

void enumerate(ZBDD f) {
    vector<int> stack;
    enumerate(f, stack);
}

void sample(ZBDD f, vector<int>& stack) {
    if (is_terminal(f)) {
        if (is_top_terminal(f)) {
            for (int i = 0; i <= (int) stack.size() - 1; i++)
                cout << fix_v(stack[i]) << ' ';
            cout << endl;
        }
        return;
    }
    int v = f.Top();
    ZBDD fh = f.OnSet0(v);
    ZBDD fl = f.OffSet(v);
    CtoI ch(fh);
    CtoI cl(fl);
    char bh[256];
    char bl[256];
    ch.CountTerms().StrNum10(bh);
    cl.CountTerms().StrNum10(bl);
    double nh = atof(bh);
    double nl = atof(bl);
    if (((double) rand()) / RAND_MAX > nl / (nh + nl)) {
        stack.push_back(v);
        sample(fh, stack);
    }
    else {
        sample(fl, stack);
    }
}

void sample(ZBDD f, int size) {
    for (int i = 0; i < size; i++) {
        vector<int> stack;
        sample(f, stack);
    }
}

struct node {
    int n, v, l, h;
    bool operator<(const struct node& n) const {
        // XXX to work as reverse operator for descending order
        return this->v != n.v ? this->v > n.v : this->n < n.n;
    }
};

inline int id(ZBDD f) {
    return is_terminal(f) ? (is_top_terminal(f) ? 1 : 0) : f.GetID();
}

void dump(ZBDD f, set<struct node>& nodes) {
    if (is_terminal(f)) return;
    int v = f.Top();
    ZBDD l = f.OffSet(v);
    ZBDD h = f.OnSet0(v);
    struct node n;
    n.n = f.GetID();
    n.v = fix_v(v);
    n.l = id(l);
    n.h = id(h);
    if (nodes.find(n) != nodes.end()) return;
    nodes.insert(n);
    dump(l, nodes);
    dump(h, nodes);
}

map<int, int> renumber(set<struct node> nodes) {
    vector<int> n;
    for (set<struct node>::iterator it = nodes.begin(); it != nodes.end(); it++)
        n.push_back(it->n);
    sort(n.begin(), n.end(), std::greater<int>());
    map<int, int> r;
    r[0] = 0, r[1] = 1;
    int i = 2;
    for (vector<int>::iterator it = n.begin(); it != n.end(); it++)
        r[*it] = i++;
    return r;
}

void dump(ZBDD f) {
    set<struct node> nodes;
    dump(f, nodes);
    map<int, int> r = renumber(nodes);
    for (set<struct node>::iterator it = nodes.begin(); it != nodes.end(); it++)
        printf("%d: (~%d?%d:%d)\n", r[it->n], it->v, r[it->l], r[it->h]);
}

void output(ZBDD f, output_t out) {
    if (out.type == 'c')
        cardinality(f);
    else if (out.type == 'e')
        enumerate(f);
    else if (out.type == 's')
        sample(f, out.size);
    else
        dump(f);
}

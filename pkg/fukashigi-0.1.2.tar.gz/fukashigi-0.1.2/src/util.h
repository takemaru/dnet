#ifndef UTIL_H__
#define UTIL_H__

#include <ZBDD.h>

inline bool is_digit(string s) {
    return s.find_first_not_of("0123456789") == string::npos;
}

inline bool is_terminal(ZBDD f) {
    return f.Top() == 0;
}

inline bool is_top_terminal(ZBDD f) {
    ZBDD bot(0);
    if (is_terminal(f))
        return f == bot ? false : true;
    else
        return false;
}

inline int fix_v(int v) {
    return v - BDDV_SysVarTop;
}

#endif /* UTIL_H__ */

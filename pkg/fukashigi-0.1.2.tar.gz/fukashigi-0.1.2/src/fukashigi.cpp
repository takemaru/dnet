#include <cassert>
#include <cctype>
#include <cstdlib>
#include <string>

#include <unistd.h>
#include <ZBDD.h>

#include "calc.h"
#include "init.h"
#include "output.h"

extern int n_vars;

output_t parse_output_type(char* arg) {
    output_t t;
    if (isdigit(arg[0])) { // sample size
        t.type = 's';
        t.size = atoi(arg);
    }
    else {
        t.type = tolower(arg[0]);
        t.size = 0;
    }
    return t;
}

void print_usage(string bin) {
    cout << "usage: " << bin << " -n var_number -t output_type file_and_operand ..." << endl;
    exit(64);
}

int main(int argc, char *argv[]) {
    int ch;
    output_t out;

    while ((ch = getopt(argc, argv, "bn:t:")) != -1) {
        char* p;
        if (ch == 'n')
            n_vars = atoi(optarg);
        else if (ch == 't')
            out = parse_output_type(optarg);
        else
            print_usage(argv[0]);
    }

    assert(n_vars > 0);

    init();

    argc -= optind;
    argv += optind;

    ZBDD f = calc(argc, argv);
    output(f, out);

    return 0;
}

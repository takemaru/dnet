#include <ZBDD.h>

#include "init.h"
#include "util.h"

int n_vars = 0;
ZBDD* vars;

void init() {
    BDDV_Init(1000000, 8000000000ll);
    vars = new ZBDD[n_vars + 1];
    for (int v = 1; v <= n_vars; v++) {
        int u = BDD_NewVarOfLev(1);
        vars[fix_v(u)] = ZBDD(1).Change(u);
    }
}

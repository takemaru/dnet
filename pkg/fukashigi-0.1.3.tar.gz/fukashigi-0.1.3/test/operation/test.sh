#!/bin/sh

../src/fukashigi -n 4 -t diagram '#' operation/b.diagram > _ || exit
diff -bu operation/hit_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram 2 operation/a.diagram > _ || exit
diff -bu operation/size_a.diagram _ || exit

# TODO: ~, <, >

../src/fukashigi -n 4 -t diagram operation/a.diagram '&' operation/b.diagram > _ || exit
diff -bu operation/a_and_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '|' operation/b.diagram > _ || exit
diff -bu operation/a_or_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '-' operation/b.diagram > _ || exit
diff -bu operation/a_minus_b.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '/' operation/c.diagram > _ || exit
diff -bu operation/a_div_c.diagram _ || exit
../src/fukashigi -n 4 -t diagram operation/a.diagram '%' operation/c.diagram > _ || exit
diff -bu operation/a_mod_c.diagram _ || exit

rm -f _

#include <cassert>
#include <climits>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>

#include <CtoI.h>

#include "init.h"
#include "output.h"
#include "util.h"

extern Config config;

class Node {
public:
    int n, v, l, h;
    Node() : n(-1), v(0), l(-1), h(-1) {}
    Node(int _n, int _v, int _l, int _h) : n(_n), v(_v), l(_l), h(_h) {}
    bool operator<(const Node& n) const {
        // XXX to work as reverse operator for descending order
        return this->v != n.v ? this->v > n.v : this->n > n.n;
    }
};

inline int node_id(ZBDD f) {
    return is_terminal(f) ? (is_top(f) ? 1 : 0) : f.GetID();
}

void scan(ZBDD f, set<Node>& nodes) {
    if (is_terminal(f)) return;
    int v = f.Top();
    ZBDD l = f.OffSet(v);
    ZBDD h = f.OnSet0(v);
    Node n(f.GetID(), var(v), node_id(l), node_id(h));
    if (nodes.find(n) != nodes.end()) return;
    nodes.insert(n);
    scan(l, nodes);
    scan(h, nodes);
}

set<Node> renumber(set<Node>& nodes, bool is_descending_order = false) {
    map<int, int> r;
    r[0] = 0, r[1] = 1;
    if (is_descending_order) {
        int j = 2;
        for (auto& i: nodes)
            r[i.n] = j++;
    }
    else {
        int j = nodes.size() + 1;
        for (auto& i: nodes)
            r[i.n] = j--;
    }
    set<Node> nodes_ret;
    for (auto& i: nodes)
        nodes_ret.insert(Node(r[i.n], i.v, r[i.l], r[i.h]));
    return nodes_ret;
}

ZBDD choose_randomly(ZBDD f, vector<int>& stack, int& idum) {
    if (is_terminal(f)) {
        if (is_top(f)) {
            ZBDD g(1);
            for (int i = 0; i <= (int) stack.size() - 1; i++)
                g *= node(stack[i]);
            return g;
        }
        else
            assert(false);
    }
    int v = f.Top();
    ZBDD fh = f.OnSet0(v);
    ZBDD fl = f.OffSet(v);
    CtoI ch(fh);
    CtoI cl(fl);
    char bh[256];
    char bl[256];
    ch.CountTerms().StrNum10(bh);
    cl.CountTerms().StrNum10(bl);
    double nh = atof(bh);
    double nl = atof(bl);
    if (ran3(idum) > nl / (nh + nl)) {
        stack.push_back(var(v));
        return choose_randomly(fh, stack, idum);
    }
    else {
        return choose_randomly(fl, stack, idum);
    }
}

ZBDD choose_randomly(ZBDD f) {
    ZBDD g(0);
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        vector<int> stack;
        int idum = -1;
        ZBDD h = choose_randomly(f, stack, idum);
        f -= h;
        g += h;
    }
    return g;
}

// Algorithm B modified for ZDD
void algorithm_b(int n, int s, const Node ns[], const vector<int>& w, int x[]) {
    int ms[s];
    ms[0] = INT_MIN, ms[1] = 0;
    int t[s];
    for (int k = 0; k < s; k++) t[k] = 0;
    for (int k = 2; k < s; k++) {
        int v = ns[k].v;
        int l = ns[k].l;
        int h = ns[k].h;
        if (l != 0)
            ms[k] = ms[l];
        if (h != 0) {
            int m = ms[h] + w[v];
            if (l == 0 || m > ms[k]) {
                ms[k] = m;
                t[k] = 1;
            }
        }
    }
    int j = 0;
    int k = s - 1;
    for (int j = 0; j <= n; j++) x[j] = 0;
    while (k > 1) {
        int v = ns[k].v;
        x[v] = t[k];
        k = t[k] == 0 ? ns[k].l : ns[k].h;
    }
}

ZBDD choose_top_k(ZBDD f) {
    ZBDD g(0);
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        // XXX avoid copying nodes
        set<Node> nodes;
        scan(f, nodes);
        nodes = renumber(nodes, true);
        Node ns[nodes.size() + 3];
        ns[0] = Node(0, BDD_MaxVar, 0, 0);
        ns[1] = Node(1, BDD_MaxVar, 1, 1);
        for (auto& n: nodes)
            ns[n.n] = n;

        int x[config.num_vars + 1];
        algorithm_b(config.num_vars, nodes.size() + 2, ns, config.weights, x);

        ZBDD h(1);
        for (int j = 1; j <= config.num_vars; j++)
            if (x[j]) h *= node(j);

        f -= h;
        g += h;
    }
    return g;
}

void to_bitmap(ZBDD f, char bitmap[]) {
    if (is_terminal(f)) {
        if (is_top(f))
            cout << bitmap << endl;
        return;
    }
    int v = f.Top();
    ZBDD l = f.OffSet(v);
    ZBDD h = f.OnSet0(v);
    if (l == h) {
        bitmap[var(v) - 1] = '*';
        to_bitmap(l, bitmap);
        bitmap[var(v) - 1] = '0';
    }
    else {
        bitmap[var(v) - 1] = '1';
        to_bitmap(h, bitmap);
        bitmap[var(v) - 1] = '0';
        to_bitmap(l, bitmap);
    }
}

void to_bitmap(ZBDD f) {
    char bitmap[config.num_vars + 1];
    for (int v = 0; v < config.num_vars; v++)
        bitmap[v] = '0';
    bitmap[config.num_vars] = '\0';
    to_bitmap(f, bitmap);
}

void to_cardinality(ZBDD f) {
    CtoI ct(f);
    char buf[1024];
    ct.CountTerms().StrNum10(buf);
    cout << buf << endl;
}

void to_diagram(ZBDD f) {
    set<Node> nodes;
    scan(f, nodes);
    nodes = renumber(nodes); // XXX avoid coyping nodes
    for (auto& i: nodes)
        printf("%d: (~%d?%d:%d)\n", i.n, i.v, i.l, i.h);
}

void to_enum(ZBDD f, vector<int>& stack) {
    if (is_terminal(f)) {
        if (is_top(f))
            cout << join(stack) << endl;
        return;
    }
    int v = f.Top();
    stack.push_back(var(v));
    to_enum(f.OnSet0(v), stack);
    stack.pop_back();
    to_enum(f.OffSet(v), stack);
}

void to_enum(ZBDD f) {
    vector<int> stack;
    to_enum(f, stack);
}

void to_enum_by_top_k(ZBDD f) {
    for (int i = 0; i < config.output_size && ! is_bot(f); i++) {
        // XXX avoid copying nodes
        set<Node> nodes;
        scan(f, nodes);
        nodes = renumber(nodes, true);
        Node ns[nodes.size() + 3];
        ns[0] = Node(0, BDD_MaxVar, 0, 0);
        ns[1] = Node(1, BDD_MaxVar, 1, 1);
        for (auto& n: nodes)
            ns[n.n] = n;

        int x[config.num_vars + 1];
        algorithm_b(config.num_vars, nodes.size() + 2, ns, config.weights, x);

        vector<int> e;
        ZBDD h(1);
        for (int j = 1; j <= config.num_vars; j++)
            if (x[j]) {
                e.push_back(j);
                h *= node(j);
            }

        cout << join(e) << endl;
        f -= h;
    }
}

void output(ZBDD f) {
    if (config.weights.size() > 0 && config.output_type == 'e') {
        to_enum_by_top_k(f);
    }
    else {
        f = config.weights.size() > 0 ? choose_top_k(f)
          : config.output_size    > 0 ? choose_randomly(f)
          :                             f;
        if (config.output_type == 'b')
            to_bitmap(f);
        else if (config.output_type == 'c')
            to_cardinality(f);
        else if (config.output_type == 'd')
            to_diagram(f);
        else
            to_enum(f);
    }
}

#pragma once

#include <cstring>
#include <sstream>
#include <string>
#include <vector>

#include <ZBDD.h>

using namespace std;

inline bool is_bot(ZBDD f) {
    return f == ZBDD(0);
}

inline bool is_top(ZBDD f) {
    return f == ZBDD(1);
}

inline bool is_terminal(ZBDD f) {
    return f.Top() == 0;
}

inline int var(int v) {
    return v - BDDV_SysVarTop;
}

inline ZBDD node(int v) {
    return ZBDD(1).Change(v + BDDV_SysVarTop);
}

inline bool is_digit(string s) {
    return s.find_first_not_of("0123456789") == string::npos;
}

template <class T>
inline string join(const vector<T>& v, string sep = " ") {
    stringstream ss;
    for (int i = 0; i < v.size(); i++) {
        ss << v[i];
        if (i < v.size() - 1) ss << sep;
    }
    return ss.str();
}

//template <class T>
inline vector<string> split(char* str, const char* sep = " ") {
    char buf[strlen(str) + 1];
    strcpy(buf, str);
    vector<string> v;
    char* p = strtok(buf, sep);
    while (p != NULL) {
        v.push_back(p);
        p = strtok(NULL, sep);
    }
    return v;
}

double ran3(int& idum);

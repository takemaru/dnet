#pragma once

#include <string>
#include <vector>

using namespace std;

class ZBDD;

class Config {
public:
    int num_vars = 0;
    char output_type = 0;
    int output_size = 0;
    vector<int> weights;
    vector<string> args;

    Config();
    Config(int argc, char** argv);
};

#include <cassert>
#include <cstdlib>
#include <map>
#include <string>

#include <ZBDD.h>

#include "init.h"
#include "input.h"
#include "operation.h"
#include "util.h"

extern Config config;

inline bool is_unitary_operator(string s) {
    return s == "~" || s == "#" || s == "<" || s == ">" || is_digit(s);
}

inline bool is_binary_operator(string s) {
    return s == "&" || s == "+" || s == "|" || s == "-" || s == "\\" || s == "/" || s == "%";
}

ZBDD _not(ZBDD f) {
    assert(! "'not' not supported");
}

ZBDD minimal(ZBDD f) {
    assert(! "minimal not supported");
}

ZBDD maximal(ZBDD f) {
    assert(! "maximal not supported");
}

inline ZBDD l(ZBDD f) {
    return f.OffSet(f.Top());
}

inline ZBDD h(ZBDD f) {
    return f.OnSet0(f.Top());
}

inline int v(ZBDD f) { // gets the top varible
    return is_terminal(f) ? BDD_MaxVar : var(f.Top());
}

pair<bddword, bddword> key(ZBDD f, ZBDD g) {
    return make_pair(f.GetID(), g.GetID());
}

ZBDD zuniq(int v, ZBDD l, ZBDD h) {
    return l + node(v) * h;
}

ZBDD zuniq(int v, pair<bddword, bddword> k) {
    return zuniq(v, ZBDD_ID(k.first), ZBDD_ID(k.second));
}

map< pair<bddword, bddword>, ZBDD> nonsup_cache;

ZBDD nonsup(ZBDD f, ZBDD g) {
    int fv = v(f);
    int gv = v(g);

    if (g == ZBDD(0)) {
        return f;
    }
    else if (f == ZBDD(0) || g == ZBDD(1) || f == g) {
        return ZBDD(0);
    }
    else if (fv > gv) {
        return nonsup(f, l(g));
    }

    auto i = nonsup_cache.find(key(f, g));
    if (i != nonsup_cache.end()) {
        return i->second;
    }
    else if (fv < gv) {
        pair<bddword, bddword> k = key(nonsup(l(f), g), nonsup(h(f), g));
        return nonsup_cache[k] = zuniq(fv, k);
    }
    else if (fv == gv) {
        pair<bddword, bddword> k
            = key(nonsup(l(f), l(g)), nonsup(h(f), h(g)) & nonsup(h(f), l(g)));
        return nonsup_cache[k] = zuniq(fv, k);
    }

    assert(false);
    return ZBDD(-1);
}

map<bddword, ZBDD> minhit_cache;

// XXX Knuth's MINHIT, which will be replaced by Toda's algorithm
ZBDD hit(ZBDD f) {
    if (f == ZBDD(0)) {
        return ZBDD(1);
    }
    else if (f == ZBDD(1)) {
        return ZBDD(0);
    }

    auto i = minhit_cache.find(f.GetID());
    if (i != minhit_cache.end()) {
        return i->second;
    }
    else {
        return minhit_cache[f.GetID()]
            = zuniq(v(f), hit(l(f) + h(f)), nonsup(hit(l(f)), hit(l(f) + h(f))));
    }
}

ZBDD set_size(ZBDD f, string op) {
    return f.PermitSym(atoi(op.c_str()));
}

ZBDD unitary_operation(string op, ZBDD f) {
    return op == "~" ? _not(f)
         : op == "<" ? minimal(f)
         : op == ">" ? maximal(f)
         : op == "#" ? hit(f)
         :             set_size(f, op);
}

ZBDD binary_operation(string op, ZBDD f, ZBDD g) {
    if (op == "&")
        return f & g;
    else if (op == "+" || op == "|")
        return f + g;
    else if (op == "-" || op == "\\")
        return f - g;
    else if (op == "/")
        return f / g;
    else if (op == "%")
        return f % g;
    else
        assert((op + " not supported").size() == 0);
}

ZBDD calc() {
    ZBDD f;
    string b_op = "";
    for (int i = 0; i < config.args.size(); i++) {
        if (is_binary_operator(config.args[i]))
            b_op = config.args[i++];
        assert(! is_binary_operator(config.args[i]));
        int j = i;
        while (j < config.args.size() && ! is_binary_operator(config.args[j]))
            j++;
        int k = i;
        i = --j;
        assert(! is_unitary_operator(config.args[j]));
        ZBDD g = input(config.args[j]);
        while (k < j)
            g = unitary_operation(config.args[--j], g);
        f = b_op != "" ? binary_operation(b_op, f, g) : g;
    }
    return f;
}
